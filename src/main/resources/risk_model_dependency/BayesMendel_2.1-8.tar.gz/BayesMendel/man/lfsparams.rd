\name{lfsparams}
\alias{lfsparams}
\title{
Set the parameters in LFSpro
}
\description{
Allow the user to set some parameters used by LFSpro.
}
\usage{
lfsparams(penetrance = LFSpenet.2010, allef = list(ALL=list(c(0.9999,0.0001))), 
age.by = 5, age.to = 85, mRate = 5e-4)
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{penetrance}{
A numeric data frame of penetrance information. A default input \link{LFSpenet.2010} is provided. User-specified input penetrance objects should closely follow the format described in \link{LFSpenet.2010}.
}
  \item{allef}{
List of list. Allele frequency for each locus/gene. The first level of list is population. Now we don't consider the ethnic in the model. THere is only one population ALL. In the second level of list, we only consider TP53 mutation by now, we suggeste to use list(ALL=list(c(1-maf,maf))). maf = 0.0001. 
}
  \item{age.by}{
The number of years between each risk prediction calculation for the counselee, default=5. For example, if age.by = 5 and the counselee's current age is 30, risk predictions will be calculated at ages 35, 40, 45, etc. up to the value of 'age.to' 
}
  \item{age.to}{
The maximum age up to which risk predictions should be calculated for the counselee.  
}
  \item{mRate}{
De Novo mutation rate. We suggest to use 5e-4.  
}
}

\value{
A list including all the parameters need fo LFSpro.
}
\author{
Gang Peng, Wenyi Wang
}

\seealso{
\code{\link{LFSpro}}
}
\examples{
data(LFSpenet.2010)
myparams = lfsparams()
}
\keyword{model}
