calc.future.risk <- function(haz.can, haz.death){
  ll <- length(haz.can)
  if(length(haz.death)<ll) ll <- length(haz.death)
  risk <- rep(0,ll)
  risk[1] <- haz.can[1]
  surv.all <- (1-haz.can[1]-haz.death[1])
  if (ll > 1) {
    for(i in 2:ll){
      risk[i] <- risk[i-1] + surv.all*haz.can[i]
      surv.all <- surv.all*(1-haz.can[i]-haz.death[i])
    }
  }
  return(risk)
}
