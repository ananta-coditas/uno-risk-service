
cum2haz <- function(F, delta=1,cause.spec=F,Fall=0){
  if(!cause.spec){
    Fall <- F
  }
  h <- cum2dens(F)/delta/(1-c(0,Fall[-length(Fall)]))
  return(h)
}
