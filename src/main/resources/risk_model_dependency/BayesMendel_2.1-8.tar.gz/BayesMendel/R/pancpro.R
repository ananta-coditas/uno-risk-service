pancpro <- function(family, counselee.id=1, race = "Unknown", germline.testing=NULL, marker.testing=NULL,
                    params=pancparams(), predict=TRUE, 
                    imputeAges=TRUE, imputeRelatives=FALSE, net = FALSE, bounds = FALSE){
  
  ##updated on 05/28/2006, keep other places up to date!
  ## Last updated: April 13, 2020
  
  # probability of inherited genetic susceptibility 
  
  # family: fam hist in pancpro format. 
  #         to enter pancpro files use readfamfilter
  # penetrance: penetrance functions, by gene, disease and sex
  #        output of makerates or make.marginal
  # allef: allele freq
  
  # output: joint probabiilty of genotypes:
  #               PANC gene
  #             0   1   2
  
  ## version 2.1-7
  
  age.max <- 94
  
  pro.agemax <- 0
  ## if proband is older than the maximum age - 1, then only return carrier probabilities
  if(max(family[which(family$ID == counselee.id), "AgePancreas"], na.rm = TRUE) > age.max - 1){
    pro.agemax <- 1
  }
  
  warnmsg = ""
  if (imputeRelatives==TRUE & imputeAges==FALSE) {
    imputeAges=TRUE
    warnmsg = paste(warnmsg, "Warning: imputeAges was input as false, but has been set to TRUE.  If imputeRelatives=TRUE then by default imputeAges must also be TRUE.")
  }
  if (nchar(warnmsg) > 0) {print(warnmsg)}
  
  # Set up allele frequencies to work with new peelingR
  allef <- list()
  allef["Panc"] <- list(params$allef)
  family$ethnic <- rep("Panc", nrow(family))
  
  
  family <- CheckFamStructure(model="pancpro",fff=family, counselee.id=counselee.id, 
                              germline.testing=germline.testing, marker.testing=marker.testing,
                              imputeAges=imputeAges, 
                              imputeRelatives=imputeRelatives,
                              params=params, bounds = bounds)
  if(is.character(family)) {return(family)}
  
  if("AgePancreas" %in% colnames(family)){
    family$AgePancreas[family$AgePancreas > age.max] <- age.max
  }
  
  if("AgePancreasLower" %in% colnames(family)){
    family$AgePancreasLower[family$AgePancreasLower > age.max] <- age.max
    family$AgePancreasLower[family$AgePancreasLower < 1] <- 1
  }
  if("AgePancreasUpper" %in% colnames(family)){
    family$AgePancreasUpper[family$AgePancreasUpper > age.max] <- age.max
    family$AgePancreasUpper[family$AgePancreasUpper < 1] <- 1
  }
  
  # if the counselee has an identical twin, make sure the ID used in the calculation is that of the counselee and not his/her twin so peeling does not error out
  originalcounselee.id <- counselee.id
  if (family$Twins[family$ID==counselee.id]>0) {
    twins <- family[family$Twins==family$Twins[family$ID==counselee.id],]
    counselee.id <- twins$ID[1]
  }
  
  proband.current.age <- family$AgePancreas[family$ID == counselee.id]
  
  
  if (race=="Unknown") {
    haz.d <- haz.death.crude
  }else{
    if (race=="Asian") {
      params$penetrance.net$fFX[,"P0"] <- baseline.race.panc.net$fFX[,"Asian"]
      params$penetrance.net$fMX[,"P0"] <- baseline.race.panc.net$fMX[,"Asian"]
      
      params$penetrance.crude$fFX[,"P0"] <- baseline.race.panc.crude$fFX[,"Asian"]
      params$penetrance.crude$fMX[,"P0"] <- baseline.race.panc.crude$fMX[,"Asian"]
      
      haz.d <- haz.death.race.crude$Asian
    }else{
      if (race=="Black") {
        params$penetrance.net$fFX[,"P0"] <- baseline.race.panc.net$fFX[,"Black"]
        params$penetrance.net$fMX[,"P0"] <- baseline.race.panc.net$fMX[,"Black"]
        
        params$penetrance.crude$fFX[,"P0"] <- baseline.race.panc.crude$fFX[,"Black"]
        params$penetrance.crude$fMX[,"P0"] <- baseline.race.panc.crude$fMX[,"Black"]
        
        haz.d <- haz.death.race.crude$Black
      }else{
        if (race=="Hispanic") {
          params$penetrance.net$fFX[,"P0"] <- baseline.race.panc.net$fFX[,"Hispanic"]
          params$penetrance.net$fMX[,"P0"] <- baseline.race.panc.net$fMX[,"Hispanic"]
          
          params$penetrance.crude$fFX[,"P0"] <- baseline.race.panc.crude$fFX[,"Hispanic"]
          params$penetrance.crude$fMX[,"P0"] <- baseline.race.panc.crude$fMX[,"Hispanic"]
          
          haz.d <- haz.death.race.crude$Hispanic
        }else{
          if (race=="NativeAmerican") {
            params$penetrance.net$fFX[,"P0"] <- baseline.race.panc.net$fFX[,"NativeAmerican"]
            params$penetrance.net$fMX[,"P0"] <- baseline.race.panc.net$fMX[,"NativeAmerican"]
            
            params$penetrance.crude$fFX[,"P0"] <- baseline.race.panc.crude$fFX[,"NativeAmerican"]
            params$penetrance.crude$fMX[,"P0"] <- baseline.race.panc.crude$fMX[,"NativeAmerican"]
            
            haz.d <- haz.death.race.crude$NativeAmerican
          }else{
            if (race=="White") {
              params$penetrance.net$fFX[,"P0"] <- baseline.race.panc.net$fFX[,"White"]
              params$penetrance.net$fMX[,"P0"] <- baseline.race.panc.net$fMX[,"White"]
              
              params$penetrance.crude$fFX[,"P0"] <- baseline.race.panc.crude$fFX[,"White"]
              params$penetrance.crude$fMX[,"P0"] <- baseline.race.panc.crude$fMX[,"White"]
              
              haz.d <- haz.death.race.crude$White
            }
          }}}}}
  
  psize <- dim(family)[1]
  ndis <- 1 # pancreas
  nloci <- 1
  ngen <- 3^nloci
  horizon <- length(params$penetrance.net$fFX[,1])
  pancrease <- 1
  
  #-------------------------------------------------------------------------------------------#
  # Set up matrices for disease status (DIS), age (AGE), and penetrances (PPf, PPm, FFf, FFm) #
  
  
  DIS <- matrix(0,psize,ndis)   # disease status
  DIS[,pancrease][family[,"AffectedPancreas"]>0] <- 1    # pancreatic cancer
  # AGE <- matrix(0,psize,ndis)
  # AGE[,pancrease] <- round(family[,"AgePancreas"])
  males <- (1:psize)[family[,"Gender"]==1]
  females <- (1:psize)[family[,"Gender"]==0]
  PPf <- FFf <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, females
  PPm <- FFm <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, males
  
  PPf[,pancrease,] <- params$penetrance.net$fFX
  PPm[,pancrease,] <- params$penetrance.net$fMX
  FFf[,pancrease,] <- apply(PPf[,pancrease,],2,cumsum)
  FFm[,pancrease,] <- apply(PPm[,pancrease,],2,cumsum)
  
  ## Make a within-*pro function that computes needed components
  ## for capturing the LIK and ped objects required by peeling
  
  runPeelingpancpro = function(family, params, ngen,
                               psize, counselee.id, allef)
  {
    
    ## first getting ages
    AGE <- matrix(0,psize,ndis)
    AGE[,pancrease] <- round(family[,"AgePancreas"])
    
    AFF <- array(0,c(psize,ndis,ngen)) # likelihood if affected
    for ( gg in 1:ngen){
      for ( dd in 1:ndis) {
        AFF[females,dd,gg] <- PPf[AGE[females,dd],dd,gg]
        AFF[males,dd,gg] <- PPm[AGE[males,dd],dd,gg]
      }
    }
    UNA <- array(0,c(psize,ndis,ngen)) # likelihood if UNAffeected
    for ( gg in 1:ngen) { for ( dd in 1:ndis ){
      UNA[females,dd,gg] <- 1-FFf[AGE[females,dd],dd,gg] 
      UNA[males,dd,gg] <- 1-FFm[AGE[males,dd],dd,gg]
    }}
    
    
    LIK <- matrix(1,psize,ngen)
    for (gg in 1:ngen) {
      LIK[,gg] <- apply(DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg],1,prod)
    }
    
    # If there are twins in the family, collapse them here #
    if (sum(family$Twins)>0) {
      if (length(unique(family$Twins))>=1 & !any(family$Twins==0)) {loopID <- length(unique(family$Twins))}
      if (length(unique(family$Twins))>1 & any(family$Twins==0)) {loopID <- length(unique(family$Twins))-1}
      family$NewMotherIndex = family$NewFatherIndex = 0
      
      # Because we are collapsing twins, need to replace any offspring's mid and fid
      for (iiiii in 1:loopID) {
        temp <- family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],]
        if (temp$Gender[1]==0) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewMotherIndex"] = temp$ID[1]}
        if (temp$Gender[1]==1) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewFatherIndex"] = temp$ID[1]}
      }
      
      twins = family$ID[family$Twins>0]
      offspring = family$ID[is.element(family$MotherID, twins) | is.element(family$FatherID, twins)]
      if (length(offspring)>0) {
        for (ooo in 1:length(offspring)){
          motherIsTwin = family$Twins[family$ID==family$MotherID[family$ID==offspring[ooo]]]
          fatherIsTwin = family$Twins[family$ID==family$FatherID[family$ID==offspring[ooo]]]
          if (length(motherIsTwin)!=0) {
            if (motherIsTwin!=0) {
              family$MotherID[family$ID==offspring[ooo]] = family$NewMotherIndex[family$ID==family$MotherID[family$ID==offspring[ooo]]]}
          }
          if (length(fatherIsTwin)!=0) {
            if (fatherIsTwin!=0) {
              family$FatherID[family$ID==offspring[ooo]] = family$NewFatherIndex[family$ID==family$FatherID[family$ID==offspring[ooo]]]}
          }
        }
      }
      # get the first twin's ped info for peeling
      firsttwin = which(family$Twins>0)
      firsttwin = firsttwin[match(unique(family$Twins[family$Twins!=0]), family$Twins[family$Twins!=0])]
      nottwins = which(family$Twins==0)
      collapsedtwins = sort(c(firsttwin,nottwins)) 
      ped = family[collapsedtwins,c("ID", "Gender", "FatherID", "MotherID", "ethnic")]
      # set up new LIK
      newLIK = LIK
      twinIDs = unique(family$Twins[family$Twins!=0])
      for (ttt in 1:length(twinIDs)) {
        twinrows = which(family$Twins==twinIDs[ttt])
        newLIK[twinrows[1],] = LIK[twinrows[1],] * LIK[twinrows[2],]
        newLIK[twinrows[2],] = rep(NA,ngen)
      }
      # Now take out empty rows
      LIK = newLIK[apply(newLIK,1,function(x){return(!any(is.na(x)))}),]
    }
    
    if (sum(family$Twins)==0) {
      ped = family[,c("ID", "Gender", "FatherID", "MotherID", "ethnic")]
    }
    
    #LIK <- cbind(LIK, LIK[,2])  # Assumes that the LIK contribution of homozygotes is the same as heterozygotes.
    
    
    #--------------------------------------------------------------------------------------------#
    # Run likelihood contributions through peeling functions to get posterior probability matrix #
    
    post <- peelingRC(allef,LIK,ped=ped,counselee.id=counselee.id,nloci=nloci)
    
    return(post) 
  }
  
  
  ## --------------
  ## Calculation for LIK start here.  This is where we start the multiple age imputation process ---------------###
  
  missingage = any(family$AgePancreas==1)
  
  if (missingage & imputeAges==FALSE) {
    agewarning = "Warning: Age imputation has been turned off, but there are unknown ages of some unaffected family members. You may want to get more information about family member ages and re-run the calculation, or set imputeAges=TRUE."
    post = runPeelingpancpro(family=family, 
                             params=params, ngen=ngen,
                             psize=psize, 
                             counselee.id=counselee.id, allef=allef)
    
  }
  if (missingage & imputeAges==TRUE){
    agewarning = "Warning: Unknown ages of some unaffected and affected family members have been imputed.  You may want to get more information about family member ages and re-run the calculation."
    ifamily = ImputeAge(fff=family, params=params, model='pancpro', bounds = bounds) #ImputeAge is run only once and returns a matrix of nIter possible affection ages
    postList = NULL
    nIter = params$nIter
    
    # Run each imputed age through runPeeling if there are affected relatives
    # who had age imputed
    
    if (length(ifamily$mem_bc)>0) {
      for (iIter in 1:nIter){
        # creating imputed fff
        nf = ifamily$fff
        
        if (length(ifamily$mem_bc)>0) {
          nf$AgePancreas[ifamily$mem_bc] = ifamily$age_bc[iIter,ifamily$mem_bc]  
        }
        
        postList = rbind(postList,
                         runPeelingpancpro(family=nf, 
                                           params=params, ngen=ngen,
                                           psize=psize, 
                                           counselee.id=counselee.id, allef=allef)
        )
      }
      
      post = apply(postList, 2, mean)
    }
    
    if (length(ifamily$mem_bc)==0) {
      post = runPeelingpancpro(family=ifamily$fff, 
                               params=params, ngen=ngen,
                               psize=psize, 
                               counselee.id=counselee.id, allef=allef)
    }
    
  }
  
  if (!missingage | imputeAges==FALSE) { # No missing ages or impute flag is turned off, run peeling once with observed input data.
    agewarning=""
    post = runPeelingpancpro(family=family, 
                             params=params, ngen=ngen,
                             psize=psize, 
                             counselee.id=counselee.id, allef=allef)
    
  }
  
  # save family object to be output
  if (!missingage | imputeAges==FALSE) {family= family}
  if (missingage & imputeAges==TRUE) { family = ifamily$fff}
  
  #### Age imputation loop would stop here, output results
  #### ---------------------------------------------------####
  
  ll   <- NULL
  
  post <- matrix(post, byrow=T, nrow=1)
  colnames(post) <- c("PANC0","PANC1","PANC2")
  
  if (predict) {
    cat("The probability of being a carrier is",1-post[1],"\n")
  }
  
  self <- which(family[,"ID"]==originalcounselee.id)
  # current.age <- AGE[self]
  if(proband.current.age + params$age.by > age.max){
    ages <- age.max
  } else{
    ages <- seq(proband.current.age+params$age.by, ifelse(params$age.to>=proband.current.age+params$age.by, params$age.to, age.max), by=params$age.by)
  }
  
  if(pro.agemax == 1){
    predictions <- future.risk <- data.frame()
    warning(paste("Proband is older than ", age.max - 1, ". Future risk prediction is not calculated.", sep = ""))
  } else{
    predictions <- NULL
    ages.by1 <- (proband.current.age+1):max(ages)
    
    if(family[self,"Gender"]==0){#female
      hFX0 <- hFX1 <- rep(0,max(ages))
      future.risk <- data.frame(hFX0,hFX1)
      
      if(net == FALSE){
        ## crude risk
        future.risk$hFX0[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fFX[,"P0"],haz.d$femalePanc)[ages.by1],haz.d$femalePanc[ages.by1])
        future.risk$hFX1[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fFX[,"P1"],haz.d$femalePanc)[ages.by1],haz.d$femalePanc[ages.by1])
      } else{
        ## net risk
        future.risk$hFX0[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fFX[,"P0"], proband.current.age, ages.by1)
        future.risk$hFX1[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fFX[,"P1"], proband.current.age, ages.by1)
      }
      
      X.risk <- future.risk$hFX1[ages]*(post[2]+post[3]) + future.risk$hFX0[ages]*post[1]
      
    }else{#male
      hMX1 <- hMX0 <- rep(0,max(ages))
      future.risk <- data.frame(hMX1,hMX0)
      
      if(net == FALSE){
        ## crude risk
        future.risk$hMX0[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fMX[,"P0"],haz.d$malePanc)[ages.by1],haz.d$malePanc[ages.by1])
        future.risk$hMX1[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fMX[,"P1"],haz.d$malePanc)[ages.by1],haz.d$malePanc[ages.by1])
      } else{
        ## net risk
        future.risk$hMX0[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fMX[,"P0"], proband.current.age, ages.by1)
        future.risk$hMX1[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fMX[,"P1"], proband.current.age, ages.by1)
        
      }
      
      X.risk <- future.risk$hMX1[ages]*(post[2]+post[3]) + future.risk$hMX0[ages]*post[1] 
    }
    
    # if proband already has pancreas cancer, set future risk to NA
    
    if (family$AffectedPancreas[which(family$ID==originalcounselee.id)]==1) {X.risk <- rep(NA, length(ages))}
    
    predictions <- data.frame(ages, pancreatic.risk=X.risk)
    colnames(predictions) <- c("By age", "Pancreatic Ca Risk")
    
    if (predict) {
      cat("The risks of developing cancers are", "\n")
      print(predictions)
    }
  }
  
  probs <- data.frame(1-post[1])
  names(probs) <- "Pr(Being a carrier)"
  rownames(probs) <- ""
  
  return(new(Class = "BayesMendel", family = family, posterior = post, 
             probs = probs, predictions = predictions, counselee.id = originalcounselee.id, loglik = ll, future.risk=future.risk))
}
