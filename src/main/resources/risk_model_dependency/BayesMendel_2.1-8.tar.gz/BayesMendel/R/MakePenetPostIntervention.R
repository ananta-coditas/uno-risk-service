MakePenetPostIntervention <- function(penet,oophhr, mashr,contralateral=FALSE, model = "brcapro")
{
  ## Purpose: Take usual matrix of pre-intervention penetrance densities, concatenate to
  ##          it the post-intervention penetrances densities by reducing the hazard from
  ##          pre-intervention
  ## ----------------------------------------------------------------------
  ## Arguments: penet: Penetrance matrix, one penetrance per column, in the usual order:
  ##                   "fFX0"  "fFX1"  "fFX2"  "fFX12" "fFY0"  "fFY1"  "fFY2"  "fFY12"
  ##                   "fMX0"  "fMX1"  "fMX2"  "fMX12" "fMY0"  "fMY1"  "fMY2"  "fMY12"
  ##                   f=density,F/M=female/male,X/Y=breast/ovary,0/1/2/12=mutation status
  ##               hr: vector composed of the hazard ratio for each column of penet.
  ##                   If have a mutation in both genes, could just multiply the 2
  ##                   appropriate hazard ratios (assumes no interaction of the 2 genes).
  ## ----------------------------------------------------------------------
  ## Author: Hormuzd Katki, Date: 31 Aug 2005, 17:25
  
  ## Original function written by HK to be edited so that it can accomodate the new format of the 
  ## penetrance object BRCApenet.metaDSL.2008 (and others) in version 2.0+ of BayesMendel
  ## Output penetrance object will be a list of 4 items: fFX, fFY, fMX, fMY
  ## Each item will be a matrix of age.max x 9 genotypes x pre/post intervention = age.max x 18 matrix
  ## A Blackford; March 2008
  
  # Get density and survival
  # For discrete event times, remember that density(t)=hazard(t)*survival(t-1)
  # So when computing survival, compute it from ages 0 to nages-1, not 1 to nages
  
  ## Updated in Aug 2012, v2.0-8, to accommodate mastectomy and contralateral BC
  
  
  ## version 2.1-7 -- adding brcapancpro (adding pancreas columns to be carried over with no adjustments for interventions)
  
  
  age.max <- 94
  
  # Use a mini-function to apply to each item in penetrance list (fFX, fFY, fMX, fMY)
  mppi <- function(penettemp, hazr, breast=TRUE, ooph=TRUE) {
    density <- penettemp
    nages <- nrow(density)
    npenets <- ncol(density)
    survival <- rbind(rep(1,npenets), 1-apply(density[1:nages-1,],2,cumsum) )
    
    hrmat <- matrix(hazr,nrow=dim(density)[1],ncol=dim(density)[2],byrow=TRUE)
    if (breast & ooph) {hrmat[60:age.max,c(1,2,4,5)] <- 1} # Take away effect of oophorectomy after age 60
    hazards <- hrmat * density / survival
    survivals <- rbind(rep(1,npenets), exp(-cumsum(hazards[1:nages-1,])))
    
    # Compute post-intervention penetrance density
    densities <- hazards * survivals
    
    # Put into the penetrance matrix, give new column names for post-intervention
    if (ooph) {INTnames <- paste("OOPH", colnames(penettemp),sep="")}
    if (!ooph) {INTnames <- paste("MAS", colnames(penettemp),sep="")}
    
    colnames(densities) <- c(INTnames)
    
    return(densities)
  }
  
  postpenet <- list()
  
  # Set up penetrance matrices to have the following format:
  # 1st set of 9 columns are input penetrances
  # 2nd set of 9 columns are reduced for oophorectomy
  # 3rd set of 9 columns are reduced for mastectomy
  
  
  if (!contralateral) {
    
    if(model == "brcapancpro"){
      # Female breast
      postpenet$fFX <- cbind(as.data.frame(penet$fFX), #original penet
                             mppi(as.data.frame(penet$fFX), oophhr$femaleBreast, breast=TRUE, ooph=TRUE),
                             mppi(as.data.frame(penet$fFX), mashr, breast=TRUE, ooph=FALSE)
      )
      # Female ovary
      postpenet$fFY <- cbind(as.data.frame(penet$fFY),
                             mppi(as.data.frame(penet$fFY), oophhr$femaleOvary, breast=FALSE, ooph=TRUE),
                             mppi(as.data.frame(penet$fFY), hazr=rep(1,27), breast=FALSE, ooph=FALSE)
      )
    } else{
      
      # Female breast
      postpenet$fFX <- cbind(as.data.frame(penet$fFX), #original penet
                             mppi(as.data.frame(penet$fFX), oophhr[1:9], breast=TRUE, ooph=TRUE),
                             mppi(as.data.frame(penet$fFX), mashr, breast=TRUE, ooph=FALSE)
      )
      # Female ovary
      postpenet$fFY <- cbind(as.data.frame(penet$fFY),
                             mppi(as.data.frame(penet$fFY), oophhr[10:18], breast=FALSE, ooph=TRUE),
                             mppi(as.data.frame(penet$fFY), hazr=rep(1,9), breast=FALSE, ooph=FALSE)
      )
    }
    
    if (model=="brcapancpro") { # Female pancreas, carry over pancreas penet, no adjustments 
      fFZ_orig = fFZ_ooph = fFZ_mas = penet$fFZ
      colnames(fFZ_ooph) = paste("OOPH", colnames(penet$fFZ),sep="")
      colnames(fFZ_mas) = paste("MAS", colnames(penet$fFZ),sep="")
      postpenet$fFZ = cbind(fFZ_orig,fFZ_ooph,fFZ_mas)
      
    }
    
    if(model == "brcapancpro"){
      # Male breast
      postpenet$fMX <- cbind(as.data.frame(penet$fMX),
                             mppi(as.data.frame(penet$fMX), rep(1,27), breast=TRUE, ooph=TRUE),
                             mppi(as.data.frame(penet$fMX), rep(1,27), breast=TRUE, ooph=FALSE)
      )
      
      # Male ovary
      postpenet$fMY <- cbind(as.data.frame(penet$fMY),
                             mppi(as.data.frame(penet$fMY), rep(1,27), breast=FALSE, ooph=TRUE),
                             mppi(as.data.frame(penet$fMY), rep(1,27), breast=FALSE, ooph=FALSE)
      )
    } else{
      # Male breast
      postpenet$fMX <- cbind(as.data.frame(penet$fMX),
                             mppi(as.data.frame(penet$fMX), oophhr[19:27], breast=TRUE, ooph=TRUE),
                             mppi(as.data.frame(penet$fMX), rep(1,9), breast=TRUE, ooph=FALSE)
      )
      
      # Male ovary
      postpenet$fMY <- cbind(as.data.frame(penet$fMY),
                             mppi(as.data.frame(penet$fMY), oophhr[28:36], breast=FALSE, ooph=TRUE),
                             mppi(as.data.frame(penet$fMY), rep(1,9), breast=FALSE, ooph=FALSE)
      )
    }
    
    if (model=="brcapancpro") { # Male pancreas, carry over pancreas penet, no adjustments 
      fMZ_orig = fMZ_ooph = fMZ_mas = penet$fMZ
      colnames(fMZ_ooph) = paste("OOPH", colnames(penet$fMZ),sep="")
      colnames(fMZ_mas) = paste("MAS", colnames(penet$fMZ),sep="")
      postpenet$fMZ = cbind(fMZ_orig,fMZ_ooph,fMZ_mas)  
    }
    
  }  
  
  if (contralateral) {
    if(model == "brcapancpro"){
      postpenet$fFX.Under40 <- cbind(as.data.frame(penet$fFX.Under40),
                                     mppi(as.data.frame(penet$fFX.Under40), oophhr$femaleBreast, breast=FALSE, ooph=TRUE),# not taking away oophorectomy effect after age 60, so use breast=FALSE here
                                     mppi(as.data.frame(penet$fFX.Under40), mashr, breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fFX.Over40 <- cbind(as.data.frame(penet$fFX.Over40),
                                    mppi(as.data.frame(penet$fFX.Over40), oophhr$femaleBreast, breast=FALSE, ooph=TRUE),
                                    mppi(as.data.frame(penet$fFX.Over40), mashr, breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fMX.Under40 <- cbind(as.data.frame(penet$fMX.Under40),
                                     mppi(as.data.frame(penet$fMX.Under40), rep(1,27), breast=FALSE, ooph=TRUE),
                                     mppi(as.data.frame(penet$fMX.Under40), rep(1,27), breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fMX.Over40 <- cbind(as.data.frame(penet$fMX.Over40),
                                    mppi(as.data.frame(penet$fMX.Over40), rep(1,27), breast=FALSE, ooph=TRUE),
                                    mppi(as.data.frame(penet$fMX.Over40), rep(1,27), breast=TRUE, ooph=FALSE)
      )
    } else{
      postpenet$fFX.Under40 <- cbind(as.data.frame(penet$fFX.Under40),
                                     mppi(as.data.frame(penet$fFX.Under40), oophhr[1:9], breast=FALSE, ooph=TRUE),# not taking away oophorectomy effect after age 60, so use breast=FALSE here
                                     mppi(as.data.frame(penet$fFX.Under40), mashr, breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fFX.Over40 <- cbind(as.data.frame(penet$fFX.Over40),
                                    mppi(as.data.frame(penet$fFX.Over40), oophhr[1:9], breast=FALSE, ooph=TRUE),
                                    mppi(as.data.frame(penet$fFX.Over40), mashr, breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fMX.Under40 <- cbind(as.data.frame(penet$fMX.Under40),
                                     mppi(as.data.frame(penet$fMX.Under40), oophhr[19:27], breast=FALSE, ooph=TRUE),
                                     mppi(as.data.frame(penet$fMX.Under40), rep(1,9), breast=TRUE, ooph=FALSE)
      )
      
      postpenet$fMX.Over40 <- cbind(as.data.frame(penet$fMX.Over40),
                                    mppi(as.data.frame(penet$fMX.Over40), oophhr[19:27], breast=FALSE, ooph=TRUE),
                                    mppi(as.data.frame(penet$fMX.Over40), rep(1,9), breast=TRUE, ooph=FALSE)
      )
    }
  } 
  
  return(postpenet)
  
}
