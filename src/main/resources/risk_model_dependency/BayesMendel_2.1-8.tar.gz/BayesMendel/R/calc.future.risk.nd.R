calc.future.risk.nd <- function(penet, agecur, agesfuture){
  risk <- rep(0, length(agesfuture))
  for(i in 1:length(agesfuture)){
    risk[i] <- sum(penet[(agecur + 1):agesfuture[i]]) / (1 - sum(penet[1:agecur]))
  }
  return(risk)
}