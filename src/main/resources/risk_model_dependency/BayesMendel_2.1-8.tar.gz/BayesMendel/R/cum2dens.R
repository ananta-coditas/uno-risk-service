cum2dens <- function(x){
  n <- length(x)
  d <- c(x[1],x[-1]-x[-n])
  return(d)
}