dens2haz.cs <- function(dens, haz.death){
  ll <- min(length(dens), length(haz.death))
  haz.can <- rep(0, ll)
  haz.can[1] <- dens[1]
  surv.all <- 1 - dens[1] - haz.death[1]
  for(i in 2:ll){
    haz.can[i] <- dens[i] / surv.all
    surv.all <- surv.all * (1 - haz.can[i] - haz.death[i])
  }
  return(haz.can)
}