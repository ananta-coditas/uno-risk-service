# Function that calculates the contribution of BRCA marker testing and germline testing results for BRCAPRO
# A Blackford 2008 edits:
# Removed MMRpro component:  MMRpro.R calculates MSI and germline testing contribution on its own.
# Updated to accomodate the nine genotypes considered by BRCAPRO in v2.0+

## v2.1-7 -- adding brcapancpro

TestContributions <- function(family, psize, ngen, sensitivity1, specificity1, sensitivity2,
                              specificity2, marker.prob, allef,counselee.id, model) {
  
  if ("ER" %in% colnames(family)) {
    er <- family[, "ER"]
    ck14 <- family[, "CK14"]
    ck5.6 <- family[, "CK5.6"]
    pr <- family[, "PR"]
    her2 <- family[,"HER2"]                          
  }
  else {
    er <- ck14 <- ck5.6 <- pr <- her2 <- rep(0, nrow(family))
  }
  
  if ("BRCA1" %in% colnames(family)) {
    brca1test <- family[, "BRCA1"]
    brca2test <- family[, "BRCA2"]
  }
  else {
    brca1test <- brca2test <- rep(0, nrow(family))
  }
  
  
  ###########################################################	 
  # Contribution of germline testing results. Pr(Test|gene) #
  
  
  TES1 <- TES2 <- matrix(1,psize,ngen)
  
  if (sum(brca1test) + sum(brca2test) > 0) {
    
    # Create a vector indicating which columns of the penetrance are informative of that gene's carrier status
    if (model=='brcapancpro') {
      brca1cols <- c(2,3,5,6,8,9,11,12,14,15,17,18,20,21,23,24,26,27)
      brca2cols <- c(4,5,6,7,8,9,13,14,15,16,17,18,22,23,24,25,26,27)
    }
    if (model=='brcapro'){
      brca1cols <- c(2,3,5,6,8,9)
      brca2cols <- c(4,5,6,7,8,9)
    }
    
    # if (sum(family$TestOrder)==0) { # Unknown test order
    #   whogottested <- which(family$BRCA1>0 | family$BRCA2>0)
    #   ntested <- length(whogottested)
    #   if (is.element(counselee.id, whogottested)) {
    #     family$TestOrder[which(family$ID==counselee.id)] <- ntested # make the proband as the last person who got tested
    #     family$TestOrder[setdiff(whogottested, counselee.id)] <- sample(1:(ntested-1),size=ntested-1)
    #   }
    #   if (!is.element(counselee.id, whogottested)) {
    #     family$TestOrder[whogottested] <- sample(1:ntested, size=ntested)
    #   }
    #   print("Warning: Testing order has been imputed (see help(brcapro) for details).")
    #   
    # }
    
    # Need to group members with test results as follows:
    # 'pre.pos.neg': those who test negative before anyone tests positive
    # 'first.pos': first person to test positive
    # 'after.pos' and 'after.neg': anyone tested after the first positive
    
    # BRCA1 #
    positives.brca1 <- which(family$BRCA1==1)
    negatives.brca1 <- which(family$BRCA1==2)
    
    # if (length(positives.brca1)>0) {
    #   first.pos.brca1 <- which(family$BRCA1==1 & family$TestOrder==min(family$TestOrder[positives.brca1]))
    #   pre.pos.neg.brca1 <- which(family$BRCA1==2 & family$TestOrder<family$TestOrder[first.pos.brca1])
    #   after.pos.brca1 <- setdiff(positives.brca1, first.pos.brca1)
    #   after.neg.brca1 <- setdiff(negatives.brca1, pre.pos.neg.brca1)
    # }
    # if (length(positives.brca1)==0) {
    #   pre.pos.neg.brca1 <- negatives.brca1
    #   first.pos.brca1 <- after.pos.brca1 <- after.neg.brca1 <- NULL
    # }
    
    # BRCA2 #
    positives.brca2 <- which(family$BRCA2==1)
    negatives.brca2 <- which(family$BRCA2==2)
    
    # if (length(positives.brca2)>0) {
    #   first.pos.brca2 <- which(family$BRCA2==1 & family$TestOrder==min(family$TestOrder[positives.brca2]))
    #   pre.pos.neg.brca2 <- which(family$BRCA2==2 & family$TestOrder<family$TestOrder[first.pos.brca2])
    #   after.pos.brca2 <- setdiff(positives.brca2, first.pos.brca2)
    #   after.neg.brca2 <- setdiff(negatives.brca2, pre.pos.neg.brca2)
    # }
    # if (length(positives.brca2)==0) {
    #   pre.pos.neg.brca2 <- negatives.brca2
    #   first.pos.brca2 <- after.pos.brca2 <- after.neg.brca2 <- NULL
    # }
    
    if (length(positives.brca1)>0) TES1[positives.brca1,brca1cols] <- sensitivity1
    if (length(negatives.brca1)>0) TES1[negatives.brca1,brca1cols] <- 1 - sensitivity1
    if (length(negatives.brca1)>0) TES1[negatives.brca1,-brca1cols] <- specificity1
    if (length(positives.brca1)>0) TES1[positives.brca1,-brca1cols] <- 1 - specificity1
    
    if (length(positives.brca2)>0) TES2[positives.brca2,brca2cols] <- sensitivity2
    if (length(negatives.brca2)>0) TES2[negatives.brca2,brca2cols] <- 1 - sensitivity2
    if (length(negatives.brca2)>0) TES2[negatives.brca2,-brca2cols] <- specificity2
    if (length(positives.brca2)>0) TES2[positives.brca2,-brca2cols] <- 1 - specificity2
    
    
    # if (length(first.pos.brca1)>0) TES1[first.pos.brca1,brca1cols] <-  sensitivity1
    # if (length(pre.pos.neg.brca1)>0) TES1[pre.pos.neg.brca1,brca1cols] <- 1- sensitivity1  
    # if (length(pre.pos.neg.brca1)>0) TES1[pre.pos.neg.brca1,-brca1cols] <-  specificity1
    # if (length(first.pos.brca1)>0) TES1[first.pos.brca1,-brca1cols] <- 1- specificity1
    # 
    # if (length(after.pos.brca1)>0) TES1[after.pos.brca1,brca1cols] <- 1 - 2* allef[[family$ethnic[after.pos.brca1[1]]]][[1]][2]
    # if (length(after.neg.brca1)>0) TES1[after.neg.brca1,brca1cols] <- 2* allef[[family$ethnic[after.neg.brca1[1]]]][[1]][2] 
    # if (length(after.neg.brca1)>0) TES1[after.neg.brca1,-brca1cols] <-  specificity1
    # if (length(after.pos.brca1)>0) TES1[after.pos.brca1,-brca1cols] <- 1- specificity1      
    # 
    # if (length(first.pos.brca2)>0) TES2[first.pos.brca2,brca2cols] <-  sensitivity2
    # if (length(pre.pos.neg.brca2)>0) TES2[pre.pos.neg.brca2,brca2cols] <- 1- sensitivity2  
    # if (length(pre.pos.neg.brca2)>0) TES2[pre.pos.neg.brca2,-brca2cols] <-  specificity2
    # if (length(first.pos.brca2)>0) TES2[first.pos.brca2,-brca2cols] <- 1- specificity2
    # 
    # if (length(after.pos.brca2)>0) TES2[after.pos.brca2,brca2cols] <- 1 - 2* allef[[family$ethnic[after.pos.brca2[1]]]][[2]][2]
    # if (length(after.neg.brca2)>0) TES2[after.neg.brca2,brca2cols] <- 2* allef[[family$ethnic[after.neg.brca2[1]]]][[2]][2] 
    # if (length(after.neg.brca2)>0) TES2[after.neg.brca2,-brca2cols] <-  specificity2
    # if (length(after.pos.brca2)>0) TES2[after.pos.brca2,-brca2cols] <- 1- specificity2      
    
  }
  
  TES <- TES1*TES2
  
  # -------------------------------------- #
  # Contribution of Marker Testing Results #
  
  ER <- ER.CK <- PR <- HER2 <- matrix(1, psize, ngen)
  if (model=='brcapancpro') {
    colnames(ER) <- colnames(ER.CK) <- colnames(PR) <- colnames(HER2) <-  c("G000", "G100", "G200", "G010", "G110", "G210", "G020", "G120",
                                                                            "G220", "G001", "G101", "G201", "G011", "G111", "G211", "G021",
                                                                            "G121", "G221", "G002", "G102", "G202", "G012", "G112", "G212",
                                                                            "G022", "G122", "G222")   
  }
  if (model=='brcapro'){
    colnames(ER) <- colnames(ER.CK) <- colnames(PR) <- colnames(HER2) <- 
      c("B00", "B10", "B20", "B01", "B11", "B21", "B02", "B12", "B22")
  }        
  # There are 42 marker probabilities from Swati
  # Give them some intuitive name to help put them in the right place
  # example: er.pos.g0 = P(ER+ | noncarrier)
  # g0=noncarrier; g1=BRCA+, g2=BRCA2+, assuming estimate for BRCA3 to be the same as BRCA2
  er.pos.g0 <- marker.prob[1]
  er.pos.g1 <- marker.prob[2]
  er.pos.g2 <- marker.prob[3]
  
  er.ck.neg.pos.pos.g0 <- marker.prob[4]
  er.ck.neg.pos.neg.g0 <- marker.prob[5]
  er.ck.neg.neg.pos.g0 <- marker.prob[6]
  er.ck.neg.neg.neg.g0 <- marker.prob[7]
  er.ck.neg.pos.pos.g1 <- marker.prob[8]
  er.ck.neg.pos.neg.g1 <- marker.prob[9]
  er.ck.neg.neg.pos.g1 <- marker.prob[10]
  er.ck.neg.neg.neg.g1 <- marker.prob[11]
  er.ck.neg.pos.pos.g2 <- marker.prob[12]
  er.ck.neg.pos.neg.g2 <- marker.prob[13]
  er.ck.neg.neg.pos.g2 <- marker.prob[14]
  er.ck.neg.neg.neg.g2 <- marker.prob[15]
  
  pr.pos.g0 <- marker.prob[16]
  pr.pos.g1 <- marker.prob[17]
  pr.pos.g2 <- marker.prob[18]
  
  er.her2.pos.neg.g0 <- marker.prob[19]
  er.her2.pos.neg.g1 <- marker.prob[20]
  er.her2.pos.neg.g2 <- marker.prob[21]
  er.her2.pos.pos.g0 <- marker.prob[22]
  er.her2.pos.pos.g1 <- marker.prob[23]
  er.her2.pos.pos.g2 <- marker.prob[24]
  er.her2.neg.neg.g0 <- marker.prob[25]
  er.her2.neg.neg.g1 <- marker.prob[26]
  er.her2.neg.neg.g2 <- marker.prob[27]
  er.her2.neg.pos.g0 <- marker.prob[28]
  er.her2.neg.pos.g1 <- marker.prob[29]
  er.her2.neg.pos.g2 <- marker.prob[30]
  
  pr.her2.pos.neg.g0 <- marker.prob[31]
  pr.her2.pos.neg.g1 <- marker.prob[32]
  pr.her2.pos.neg.g2 <- marker.prob[33]
  pr.her2.pos.pos.g0 <- marker.prob[34]
  pr.her2.pos.pos.g1 <- marker.prob[35]
  pr.her2.pos.pos.g2 <- marker.prob[36]
  pr.her2.neg.neg.g0 <- marker.prob[37]
  pr.her2.neg.neg.g1 <- marker.prob[38]
  pr.her2.neg.neg.g2 <- marker.prob[39]
  pr.her2.neg.pos.g0 <- marker.prob[40]
  pr.her2.neg.pos.g1 <- marker.prob[41]
  pr.her2.neg.pos.g2 <- marker.prob[42]
  
  her2.pos.g0 <- marker.prob[43]
  her2.pos.g1 <- marker.prob[44]
  her2.pos.g2 <- marker.prob[45]
  
  # There are 3 sets of assignments to be done:
  # B000: non-carriers
  # BRCA1-related columns
  # BRCA2 ONLY related columns, as BRCA1 trumps 2 and 3
  if (model=='brcapancpro') {
    allcols <- 1:27
    noncarrier <- c(1,10)
    brca2only <- c(4,7,13,16,22,25) # column numbers corrsponding to column names for marker matrices, assigned above
    brca1 <- allcols[-c(noncarrier,brca2only)]
  }
  if (model=='brcapro') {
    allcols <- 1:9
    noncarrier <- 1
    brca2only <- c(4,7) # column numbers corrsponding to column names for marker matrices, assigned above
    brca1 <- allcols[-c(noncarrier,brca2only)]
  }
  
  # ER positive, no Her2 results       
  ER[er == 1 & her2==0, noncarrier] <- er.pos.g0
  ER[er == 1 & her2==0, brca1] <- er.pos.g1
  ER[er == 1 & her2==0, brca2only] <- er.pos.g2
  
  # ER, Her2 results       
  ER[er == 1 & her2==2, noncarrier] <- er.her2.pos.neg.g0
  ER[er == 1 & her2==2, brca1] <- er.her2.pos.neg.g1
  ER[er == 1 & her2==2, brca2only] <- er.her2.pos.neg.g2
  
  ER[er == 1 & her2==1, noncarrier] <- er.her2.pos.pos.g0
  ER[er == 1 & her2==1, brca1] <- er.her2.pos.pos.g1
  ER[er == 1 & her2==1, brca2only] <- er.her2.pos.pos.g2
  
  # ER, Her2 results, no CK results       
  ER[er == 2 & her2==2 & (ck14 == 0 | ck5.6 == 0), noncarrier] <- er.her2.neg.neg.g0
  ER[er == 2 & her2==2 & (ck14 == 0 | ck5.6 == 0), brca1] <- er.her2.neg.neg.g1
  ER[er == 2 & her2==2 & (ck14 == 0 | ck5.6 == 0), brca2only] <- er.her2.neg.neg.g2
  
  ER[er == 2 & her2==1 & (ck14 == 0 | ck5.6 == 0), noncarrier] <- er.her2.neg.pos.g0
  ER[er == 2 & her2==1 & (ck14 == 0 | ck5.6 == 0), brca1] <- er.her2.neg.pos.g1
  ER[er == 2 & her2==1 & (ck14 == 0 | ck5.6 == 0), brca2only] <- er.her2.neg.pos.g2
  
  # ER negative, no CK or Her2 results
  ER[er == 2 & (ck14 == 0 | ck5.6 == 0) & her2==0, noncarrier] <- 1 - er.pos.g0
  ER[er == 2 & (ck14 == 0 | ck5.6 == 0) & her2==0, brca1] <- 1 - er.pos.g1
  ER[er == 2 & (ck14 == 0 | ck5.6 == 0) & her2==0, brca2only] <- 1 - er.pos.g2
  
  # ER negative, by CK results
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 1, noncarrier] <- er.ck.neg.pos.pos.g0
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 2, noncarrier] <- er.ck.neg.pos.neg.g0
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 1, noncarrier] <- er.ck.neg.neg.pos.g0
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 2, noncarrier] <- er.ck.neg.neg.neg.g0
  
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 1, brca1] <- er.ck.neg.pos.pos.g1
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 2, brca1] <- er.ck.neg.pos.neg.g1
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 1, brca1] <- er.ck.neg.neg.pos.g1
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 2, brca1] <- er.ck.neg.neg.neg.g1
  
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 1, brca2only] <- er.ck.neg.pos.pos.g2
  ER.CK[er == 2 & ck14 == 1 & ck5.6 == 2, brca2only] <- er.ck.neg.pos.neg.g2
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 1, brca2only] <- er.ck.neg.neg.pos.g2
  ER.CK[er == 2 & ck14 == 2 & ck5.6 == 2, brca2only] <- er.ck.neg.neg.neg.g2
  
  # PR results, no Her 2
  PR[pr == 1 & her2==0 & er==0, noncarrier] <- pr.pos.g0
  PR[pr == 2 & her2==0 & er==0, noncarrier] <- 1 - pr.pos.g0
  PR[pr == 1 & her2==0 & er==0, brca1] <- pr.pos.g1
  PR[pr == 2 & her2==0 & er==0, brca1] <- 1 - pr.pos.g1
  PR[pr == 1 & her2==0 & er==0, brca2only] <- pr.pos.g2
  PR[pr == 2 & her2==0 & er==0, brca2only] <- 1 - pr.pos.g2
  
  # PR and Her2 results, use only if no ER
  PR[pr == 1 & her2==2 & (er == 0), noncarrier] <- pr.her2.pos.neg.g0
  PR[pr == 1 & her2==2 & (er == 0), brca1] <- pr.her2.pos.neg.g1
  PR[pr == 1 & her2==2 & (er == 0), brca2only] <- pr.her2.pos.neg.g2
  
  PR[pr == 1 & her2==1 & (er == 0), noncarrier] <- pr.her2.pos.pos.g0
  PR[pr == 1 & her2==1 & (er == 0), brca1] <- pr.her2.pos.pos.g1
  PR[pr == 1 & her2==1 & (er == 0), brca2only] <- pr.her2.pos.pos.g2
  
  PR[pr == 2 & her2==2 & (er == 0), noncarrier] <- pr.her2.neg.neg.g0
  PR[pr == 2 & her2==2 & (er == 0), brca1] <- pr.her2.neg.neg.g1
  PR[pr == 2 & her2==2 & (er == 0), brca2only] <- pr.her2.neg.neg.g2
  
  PR[pr == 2 & her2==1 & (er == 0), noncarrier] <- pr.her2.neg.pos.g0
  PR[pr == 2 & her2==1 & (er == 0), brca1] <- pr.her2.neg.pos.g1
  PR[pr == 2 & her2==1 & (er == 0), brca2only] <- pr.her2.neg.pos.g2
  
  # HER2 results, no other marker results
  HER2[her2 == 1 & pr==0 & er==0, noncarrier] <- her2.pos.g0
  HER2[her2 == 2 & pr==0 & er==0, noncarrier] <- 1 - her2.pos.g0
  HER2[her2 == 1 & pr==0 & er==0, brca1] <- her2.pos.g1
  HER2[her2 == 2 & pr==0 & er==0, brca1] <- 1 - her2.pos.g1
  HER2[her2 == 1 & pr==0 & er==0, brca2only] <- her2.pos.g2
  HER2[her2 == 2 & pr==0 & er==0, brca2only] <- 1 - her2.pos.g2
  
  output <- list()
  output$TES <- TES
  output$ER <- ER
  output$ER.CK <- ER.CK
  output$PR <- PR
  output$HER2 <- HER2
  
  return(output)
}
