### last updated: Octo 21, 2006, use Hazard function to calculate future risk
### last updated: Sept 12, 2006, use Ngene instead of Margene. -SC
### last Updated: March 23, 2006
### Last updated: January 15, 2019
### update the allele freq for nonAJ population using the estimates from Antoniou et al. BJC2002, 
### the segregation study with major
### gene model BRCA1 and BRCA2 only: 0.0005829 and 0.0006760. 

## version 2.1-6
## mastectomies now affect males too

## version 2.1-7
## adding lower and upper bounds for imputing cancer ages
## adding option to run brcaproPlusBCRAT

brcapro <- function(family, counselee.id = 1, #allef.type = "nonAJ", replacing with family$ethnic
                    race = "Unknown", germline.testing=NULL,
                    marker.testing=NULL,oophorectomy=NULL,mastectomy=NULL,
                    params = brcaparams(), print=TRUE,
                    imputeAges=TRUE, imputeRelatives=FALSE,
                    MEadj=FALSE, net = FALSE, bounds = FALSE, plusBCRAT = FALSE,
                    rr.bcrat=NULL, 
                    bcrat.vars=NULL,
                    rr.pop=rr.ref){
  
  if(plusBCRAT == TRUE){
    if(net == TRUE){
      warning("Reporting crude future risk because brcaproPlusBCRAT only modifies brcparo risk for crude future risk")
    }
    return(brcaproPlusBCRAT(family=family, counselee.id = counselee.id,
                            race = race, germline.testing=germline.testing,
                            marker.testing=marker.testing,oophorectomy=oophorectomy,mastectomy=mastectomy,
                            params = params, print=print,
                            imputeAges=imputeAges, imputeRelatives=imputeRelatives,
                            MEadj=MEadj, net = FALSE, bounds = bounds,
                            rr.bcrat=rr.bcrat, 
                            bcrat.vars=bcrat.vars,
                            rr.pop=rr.ref))
  }
  
  warnmsg = ""
  if (imputeRelatives==TRUE & imputeAges==FALSE) {
    imputeAges=TRUE
    warnmsg = paste(warnmsg, "Warning: imputeAges was input as false, but has been set to TRUE.  If imputeRelatives=TRUE then by default imputeAges must also be TRUE.")
  }
  if (nchar(warnmsg) > 0) {print(warnmsg)}
  
  age.max <- 94 ## maximum age that BRCAPRO takes
  
  pro.agemax <- 0
  ## if proband is older than the maximum age - 1, then we only return carrier probabilities
  if(max(family[which(family$ID == counselee.id), c("AgeBreast", "AgeOvary", "AgeBreastContralateral")], na.rm = TRUE) > age.max - 1){
    pro.agemax <- 1
  }
  
  family <- CheckFamStructure("brcapro",family,counselee.id,
                              germline.testing,marker.testing,
                              oophorectomy,mastectomy,
                              imputeAges, imputeRelatives,
                              params, bounds)
  
  
  ## truncating ages past age.max to age.max, since we don't have data past age age.max
  if("AgeBreast" %in% colnames(family)){
    family$AgeBreast[family$AgeBreast > age.max] <- age.max
  }
  if("AgeBreastContralateral" %in% colnames(family)){
    family$AgeBreastContralateral[family$AgeBreastContralateral > age.max] <- age.max
  }
  if("AgeOvary" %in% colnames(family)){
    family$AgeOvary[family$AgeOvary > age.max] <- age.max
  }
  if("AgeMastectomy" %in% colnames(family)){
    family$AgeMastectomy[family$AgeMastectomy > age.max] <- age.max
  }
  if("AgeOophorectomy" %in% colnames(family)){
    family$AgeOophorectomy[family$AgeOophorectomy > age.max] <- age.max
  }
  
  if("AgeBreastLower" %in% colnames(family)){
    family$AgeBreastLower[family$AgeBreastLower > age.max] <- age.max
    family$AgeBreastLower[family$AgeBreastLower < 1] <- 1
  }
  if("AgeBreastUpper" %in% colnames(family)){
    family$AgeBreastUpper[family$AgeBreastUpper > age.max] <- age.max
    family$AgeBreastUpper[family$AgeBreastUpper < 1] <- 1
  }
  if("AgeOvaryLower" %in% colnames(family)){
    family$AgeOvaryLower[family$AgeOvaryLower > age.max] <- age.max
    family$AgeOvaryLower[family$AgeOvaryLower < 1] <- 1
  }
  if("AgeOvaryUpper" %in% colnames(family)){
    family$AgeOvaryUpper[family$AgeOvaryUpper > age.max] <- age.max
    family$AgeOvaryUpper[family$AgeOvaryUpper < 1] <- 1
  }
  if("AgeBreastContralateralLower" %in% colnames(family)){
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower > age.max] <- age.max
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower < 1] <- 1
  }
  if("AgeBreastContralateralUpper" %in% colnames(family)){
    family$AgeBreastContralateralUpper[family$AgeBreastContralateralUpper > age.max] <- age.max
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower < 1] <- 1
  }
  
  
  if(is.character(family)) {return(family)}
  
  # probability of inherited genetic susceptibility 
  
  # Keep a copy of the family as entered if any twins are input
  if (sum(family$Twins)>0) {
    inputfamily <- family
    if (!is.null(germline.testing)) {
      inputfamily <- data.frame(inputfamily, germline.testing)
    }
    if (!is.null(marker.testing)) {
      inputfamily <- data.frame(inputfamily, marker.testing)
    }
    if (!is.null(oophorectomy)) {
      inputfamily <- data.frame(inputfamily, oophorectomy)
    }
    if (!is.null(mastectomy)) {
      inputfamily <- data.frame(inputfamily, mastectomy)
    }
  }
  
  # if the counselee has an identical twin, make sure the ID used in the calculation is that of the counselee and not his/her twin so peeling does not error out
  originalcounselee.id <- counselee.id
  if (family$Twins[family$ID==counselee.id]>0) {
    twins <- family[family$Twins==family$Twins[family$ID==counselee.id],]
    counselee.id <- twins$ID[1]
  }
  
  
  proband.current.age <- max(family[which(family$ID==counselee.id),c("AgeBreast", "AgeOvary", "AgeBreastContralateral")])
  
  #------------------------#
  # Decide allele frequency
  
  nonAJ <- list(c(1-0.0005829,0.0005829),c(1-0.0006760,0.0006760))
  AJ <- list(c(1-0.01366243,0.01366243),
             c(1-0.01168798,0.01168798))
  Italian <- list(c(1-0.001673779,0.001673779),
                  c(1-0.00132622,0.00132622))
  Other <- params$allef
  
  
  allef <- list()
  if (any(family$ethnic=="AJ" & !is.na(family$ethnic))) allef["AJ"] <- list(AJ)
  if (any(family$ethnic=="nonAJ" & !is.na(family$ethnic))) allef["nonAJ"] <- list(nonAJ)
  if (any(family$ethnic=="Italian" & !is.na(family$ethnic))) allef["Italian"] <- list(Italian)
  if (any(family$ethnic=="Other" & !is.na(family$ethnic))) allef["Other"] <- list(Other)        
  
  #------------------------------------------#
  # Get the race-specific baseline estimates #
  
  
  if (race=="Unknown") {
    haz.d <- haz.death.crude
  }else{
    if (race=="Asian") {
      params$penetrance.net$fFX[,"B00"] <- baseline.race.brca.net$fFX[,"Asian"]
      params$penetrance.net$fFY[,"B00"] <- baseline.race.brca.net$fFY[,"Asian"]
      params$penetrance.net$fMX[,"B00"] <- baseline.race.brca.net$fMX[,"Asian"]
      params$penetrance.net$fMY[,"B00"] <- baseline.race.brca.net$fMY[,"Asian"]
      
      params$penetrance.crude$fFX[,"B00"] <- baseline.race.brca.crude$fFX[,"Asian"]
      params$penetrance.crude$fFY[,"B00"] <- baseline.race.brca.crude$fFY[,"Asian"]
      params$penetrance.crude$fMX[,"B00"] <- baseline.race.brca.crude$fMX[,"Asian"]
      params$penetrance.crude$fMY[,"B00"] <- baseline.race.brca.crude$fMY[,"Asian"]
      
      haz.d <- haz.death.race.crude$Asian
    }else{
      if (race=="Black") {
        params$penetrance.net$fFX[,"B00"] <- baseline.race.brca.net$fFX[,"Black"]
        params$penetrance.net$fFY[,"B00"] <- baseline.race.brca.net$fFY[,"Black"]
        params$penetrance.net$fMX[,"B00"] <- baseline.race.brca.net$fMX[,"Black"]
        params$penetrance.net$fMY[,"B00"] <- baseline.race.brca.net$fMY[,"Black"]
        
        params$penetrance.crude$fFX[,"B00"] <- baseline.race.brca.crude$fFX[,"Black"]
        params$penetrance.crude$fFY[,"B00"] <- baseline.race.brca.crude$fFY[,"Black"]
        params$penetrance.crude$fMX[,"B00"] <- baseline.race.brca.crude$fMX[,"Black"]
        params$penetrance.crude$fMY[,"B00"] <- baseline.race.brca.crude$fMY[,"Black"]
        
        haz.d <- haz.death.race.crude$Black
      }else{
        if (race=="Hispanic") {
          params$penetrance.net$fFX[,"B00"] <- baseline.race.brca.net$fFX[,"Hispanic"]
          params$penetrance.net$fFY[,"B00"] <- baseline.race.brca.net$fFY[,"Hispanic"]
          params$penetrance.net$fMX[,"B00"] <- baseline.race.brca.net$fMX[,"Hispanic"]
          params$penetrance.net$fMY[,"B00"] <- baseline.race.brca.net$fMY[,"Hispanic"]
          
          params$penetrance.crude$fFX[,"B00"] <- baseline.race.brca.crude$fFX[,"Hispanic"]
          params$penetrance.crude$fFY[,"B00"] <- baseline.race.brca.crude$fFY[,"Hispanic"]
          params$penetrance.crude$fMX[,"B00"] <- baseline.race.brca.crude$fMX[,"Hispanic"]
          params$penetrance.crude$fMY[,"B00"] <- baseline.race.brca.crude$fMY[,"Hispanic"]
          
          haz.d <- haz.death.race.crude$Hispanic
        }else{
          if (race=="NativeAmerican") {
            params$penetrance.net$fFX[,"B00"] <- baseline.race.brca.net$fFX[,"NativeAmerican"]
            params$penetrance.net$fFY[,"B00"] <- baseline.race.brca.net$fFY[,"NativeAmerican"]
            params$penetrance.net$fMX[,"B00"] <- baseline.race.brca.net$fMX[,"NativeAmerican"]
            params$penetrance.net$fMY[,"B00"] <- baseline.race.brca.net$fMY[,"NativeAmerican"]
            
            params$penetrance.crude$fFX[,"B00"] <- baseline.race.brca.crude$fFX[,"NativeAmerican"]
            params$penetrance.crude$fFY[,"B00"] <- baseline.race.brca.crude$fFY[,"NativeAmerican"]
            params$penetrance.crude$fMX[,"B00"] <- baseline.race.brca.crude$fMX[,"NativeAmerican"]
            params$penetrance.crude$fMY[,"B00"] <- baseline.race.brca.crude$fMY[,"NativeAmerican"]
            
            haz.d <- haz.death.race.crude$NativeAmerican
          }else{
            if (race=="White") {
              params$penetrance.net$fFX[,"B00"] <- baseline.race.brca.net$fFX[,"White"]
              params$penetrance.net$fFY[,"B00"] <- baseline.race.brca.net$fFY[,"White"]
              params$penetrance.net$fMX[,"B00"] <- baseline.race.brca.net$fMX[,"White"]
              params$penetrance.net$fMY[,"B00"] <- baseline.race.brca.net$fMY[,"White"]
              
              params$penetrance.crude$fFX[,"B00"] <- baseline.race.brca.crude$fFX[,"White"]
              params$penetrance.crude$fFY[,"B00"] <- baseline.race.brca.crude$fFY[,"White"]
              params$penetrance.crude$fMX[,"B00"] <- baseline.race.brca.crude$fMX[,"White"]
              params$penetrance.crude$fMY[,"B00"] <- baseline.race.brca.crude$fMY[,"White"]
              
              haz.d <- haz.death.race.crude$White
            }
          }}}}}
  
  
  # Needed constants
  psize <- dim(family)[1]
  nloci <- 2 # Number of genes: BRCA1 and BRCA2
  ngen <- 3^nloci
  
  # Get the max ages to use as the censoring times for the competing risk
  maxages <- apply(family[,c("AgeBreast", "AgeOvary", "AgeBreastContralateral")],1,max)
  
  # Get the sex (0=female, 1=male) to know which penetrance to use
  sex <- family$Gender
  
  # Keep a copy of the family before any intervention age censoring
  currfamily <- family
  if (sum(family$Twins)>0) {currfamily <- inputfamily}
  
  #---------------------------------------------------------#
  # If proband has a 1st breast cancer diagnosis,           #
  # compute personalized contralateral BC penetrance matrix #
  
  femaleproband <- ifelse(family$Gender[family$ID==counselee.id]==0, 1, 0)
  
  ## future risk penetrance depends on whether we want crude or net
  if(net == TRUE){
    params$penetrance <- params$penetrance.net
    params$CBCpenetrance <- cbc.net
  } else{
    params$penetrance <- params$penetrance.crude
    params$CBCpenetrance <- cbc.crude
  }
  
  if (family$AffectedBreast[family$ID==counselee.id]>0) { # 1st BC dx
    
    firstdx.under40 <- ifelse(family$AgeBreast[family$ID==counselee.id]<40, 1, 0)
    agedx <- family$AgeBreast[family$ID==counselee.id]
    
    if (femaleproband==1 & firstdx.under40==1) {
      Breast <- params$CBCpenetrance$fFX.Under40
      Ovarian <- params$penetrance$fFY
    }
    if (femaleproband==1 & firstdx.under40==0) {
      Breast <- params$CBCpenetrance$fFX.Over40
      Ovarian <- params$penetrance$fFY
    }
    if (femaleproband==0 & firstdx.under40==1) {
      Breast <- params$CBCpenetrance$fMX.Under40
      Ovarian <- params$penetrance$fMY
    }
    if (femaleproband==0 & firstdx.under40==0) {
      Breast <- params$CBCpenetrance$fMX.Over40
      Ovarian <- params$penetrance$fMY
    }
    CBC <- matrix(0, nrow=age.max, ncol=9)
    for (cccc in 1:ncol(Breast)) {
      CBC[agedx:age.max,cccc] <- Breast[1:length(agedx:age.max),cccc]
    }
  }else { # no 1st BC
    if (femaleproband==1) {
      CBC <- params$penetrance$fFX
      Ovarian <- params$penetrance$fFY
    }
    if (femaleproband==0) {
      CBC <- params$penetrance$fMX
      Ovarian <- params$penetrance$fMY
    }
  }
  CBRCApenet <- list(CBC, Ovarian)
  names(CBRCApenet) <- c("fX","fY") # this works as the penetrance matrix for future risk calculations.
  colnames(CBRCApenet$fX) <- colnames(CBRCApenet$fY) <- colnames(params$penetrance$fFX)
  
  
  #---------------------------------------------------------------------------------#
  # If penetrance matrix doesn't have post-intervention penetrances, put them there #
  ## for version 2.1-4-1, changing the net penetrance as well since we need those for
  ## the carrier probabilities
  
  # 1st breast cancer
  if(ncol(params$penetrance[[1]]) == 9){ 
    params$penetrance <- MakePenetPostIntervention(params$penetrance,params$PostOophorectomyHR,params$PostMastectomyHR, contralateral=FALSE)
    params$penetrance.net <- MakePenetPostIntervention(params$penetrance.net,params$PostOophorectomyHR,params$PostMastectomyHR, contralateral=FALSE)
  }else{
    if( ncol(params$penetrance[[1]]) != 27 ){
      stop("Penetrance matrices must have 9 columns, or 27 if they include interventions")
    }
  }
  
  # contralateral
  if(ncol(params$CBCpenetrance[[1]]) == 9){ 
    params$CBCpenetrance <- MakePenetPostIntervention(params$CBCpenetrance,params$PostOophorectomyHR,params$PostMastectomyHR, contralateral=TRUE)
    params$CBCpenetrance.net <- MakePenetPostIntervention(params$CBCpenetrance.net,params$PostOophorectomyHR,params$PostMastectomyHR, contralateral=TRUE)
  }else{
    if( ncol(params$CBCpenetrance[[1]]) != 27 ){
      stop("Penetrance matrices must have 9 columns, or 18 if they include interventions")
    }
  }
  
  ## Make a within-brcapro function that computes needed components
  ## for capturing the LIK and ped objects required by peeling
  ## This is essentially what comes next in brcapro anyway, we are just
  ## selecting it out so it can be run in multiple iterations.
  
  runPeeling = function(family, params, ngen,
                        oophorectomy, mastectomy, psize, counselee.id, allef)
  {
    
    #------------------------------------------------------------#
    # Compute post-intervention part of likelihood contributions #
    
    # These people got interventions
    if(is.null(oophorectomy) & is.null(mastectomy)){
      interventions <- family[,"ID"]==0
      oophonly <- mastonly <- mastbeforeooph <- oophbeforemast <- family[,"ID"]==0
    }else{
      if(!is.null(oophorectomy) & !is.null(mastectomy)) {
        interventions <- family$Oophorectomy==1 | family$Mastectomy==1
        mastonly <- family$Mastectomy==1 & family$Oophorectomy==0
        oophonly <- family$Mastectomy==0 & family$Oophorectomy==1
        mastbeforeooph <- family$Oophorectomy==1 & family$Mastectomy==1 & family$AgeMastectomy <= family$AgeOophorectomy
        oophbeforemast <- family$Oophorectomy==1 & family$Mastectomy==1 & family$AgeMastectomy > family$AgeOophorectomy
      }else{
        if(!is.null(oophorectomy) & is.null(mastectomy)) {
          interventions <- family$Oophorectomy==1
          mastonly <- family[,"ID"]==0
          oophonly <- family$Oophorectomy==1
          mastbeforeooph <- family[,"ID"]==0
          oophbeforemast <- family[,"ID"]==0
        }else{
          if(is.null(oophorectomy) & !is.null(mastectomy)) {
            interventions <- family$Mastectomy==1
            mastonly <- family$Mastectomy==1
            oophonly <- family[,"ID"]==0
            mastbeforeooph <- family[,"ID"]==0
            oophbeforemast <- family[,"ID"]==0
          }
        }
      }
    }
    
    if( sum(interventions)>0 ) {
      
      # Subset out those with intervention, note the age of intervention
      # drop=F means do not squeeze out any singleton indices, i.e. don't coerce row
      # matrices to vectors
      # Use inputfamily since family censors post-intervention outcomes
      # Start with those who had oophorectomy only.
      
      ## using net penetrance for peeling (carrier probabilities)
      if (sum(oophonly)>0) {
        oophfamily <- family[oophonly,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(oophfamily, whichintervention="Oophorectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="Oophorectomy",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        PostIntOophOnlyDIS <- output$DIS
        PostIntOophOnlyAFF <- output$AFF
        PostIntOophOnlyUNA <- output$UNA
      }
      
      # Now those who had mastectomy only.
      if (sum(mastonly)>0) {
        mastfamily <- family[mastonly,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Mastectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="Mastectomy",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        PostIntMastOnlyDIS <- output$DIS
        PostIntMastOnlyAFF <- output$AFF
        PostIntMastOnlyUNA <- output$UNA
      }
      
      # Those who had mastectomy first, then oophorectomy
      # Mastectomy doesn't affect ovarian cancer penetrance
      if (sum(mastbeforeooph)>0) {
        mastfamily <- family[mastbeforeooph,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Mastectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="MastectomyFirst",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        
        PostIntMastFirstDIS <- output$DIS
        PostIntMastFirstAFF <- output$AFF
        PostIntMastFirstUNA <- output$UNA
        
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Oophorectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="Oophorectomy",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        PostIntOophAfterDIS <- output$DIS
        PostIntOophAfterAFF <- output$AFF
        PostIntOophAfterUNA <- output$UNA
      }
      
      
      # Those who had oophorectomy first, then mastectomy.
      if (sum(oophbeforemast)>0) {
        oophfamily <- family[oophbeforemast,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(oophfamily,whichintervention="Oophorectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="OophorectomyFirst",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        PostIntOophFirstDIS <- output$DIS
        PostIntOophFirstAFF <- output$AFF
        PostIntOophFirstUNA <- output$UNA
        
        output <- FamilyHistoryContributions(PostIntervention(oophfamily, whichintervention="Mastectomy"),
                                             params$penetrance.net,ngen,type="PostIntervention",
                                             whichintervention="Mastectomy",
                                             CBCpenetrance=params$CBCpenetrance.net,
                                             model = "brcapro")
        PostIntMastAfterDIS <- output$DIS
        PostIntMastAfterAFF <- output$AFF
        PostIntMastAfterUNA <- output$UNA
      }
    }
    
    #-----------------------------------------------------------#
    # Compute pre-intervention part of likelihood contributions #
    
    if( sum(interventions)>0 ) {
      # To do pre-intervention parts, remember to censor family to pre-intervention times
      PreInterventionFamily <- CensorAtIntervention(family,interventions)
    } else{
      PreInterventionFamily <- family
    }
    
    output <- FamilyHistoryContributions(PreInterventionFamily,penetrance=params$penetrance.net,ngen,
                                         type="PreIntervention",CBCpenetrance=params$CBCpenetrance.net,
                                         model = "brcapro")
    DIS <- output$DIS
    AFF <- output$AFF
    UNA <- output$UNA
    
    
    #-------------------------------------------------------------------------#
    # Compute likelihood contribution due to BRCA test and breast tumor tests #
    
    output <- TestContributions(family,psize,ngen,params$sensitivity1,params$specificity1,
                                params$sensitivity2,params$specificity2,params$marker.prob,
                                allef,counselee.id, model = "brcapro")
    
    TES <- output$TES
    ER <- output$ER 
    ER.CK <- output$ER.CK 
    HER2 <- output$HER2 
    PR <- output$PR
    
    #-----------------------------------------------#
    # Compute each person's likelihood contribution #
    
    # Genotypes are ordered like this: "B00"  "B10"  "B20"  "B01" "B11" "B21"  "B02"  "B12" "B22"
    # NOTE:  this order cannot be changed - it is dependent on the order of the HW frequencies
    
    LIK <- matrix(1,psize,ngen)
    for (gg in 1:ngen) {
      if (gg==1 | gg==2 | gg==4 | gg==5) { # heterozygous genotypes
        ggcr <- ifelse(gg==1, 1, ifelse(gg==2, 2, ifelse(gg==4, 3, 4)))
        
        if (is.matrix(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])) {
          LIK[,gg] <- apply( DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg], 1, prod )*TES[,gg]*ER[,gg]*ER.CK[,gg]*PR[,gg]*HER2[,gg]*
            diag(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])
        } 
        if (!is.matrix(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])) {
          LIK[,gg] <- apply( DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg], 1, prod )*TES[,gg]*ER[,gg]*ER.CK[,gg]*PR[,gg]*HER2[,gg]*
            diag(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)], nrow = 1)
        } 
      } else{
        LIK[,gg] <- rep(0,psize)
      }
    }
    
    # Include post-intervention contributions only on those who had intervention
    # Separate these out further into the specific interventions, a loop for each type.
    if ( sum(interventions)>0) {
      if ( sum(oophonly)>0 ) {
        for (gg in 1:ngen) {
          LIK[oophonly,gg] <- LIK[oophonly,gg]*apply( PostIntOophOnlyDIS*PostIntOophOnlyAFF[,,gg] + (1-PostIntOophOnlyDIS) * 
                                                        PostIntOophOnlyUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(mastonly)>0 ) {
        for (gg in 1:ngen) {
          LIK[mastonly,gg] <- LIK[mastonly,gg]*apply( PostIntMastOnlyDIS*PostIntMastOnlyAFF[,,gg] + (1-PostIntMastOnlyDIS) *
                                                        PostIntMastOnlyUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(mastbeforeooph)>0 ) {
        for (gg in 1:ngen) {
          LIK[mastbeforeooph,gg] <- LIK[mastbeforeooph,gg]*apply( PostIntMastFirstDIS*PostIntMastFirstAFF[,,gg] + (1-PostIntMastFirstDIS) * 
                                                                    PostIntMastFirstUNA[,,gg], 1, prod)*apply( PostIntOophAfterDIS*PostIntOophAfterAFF[,,gg] + (1-PostIntOophAfterDIS) * 
                                                                                                                 PostIntOophAfterUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(oophbeforemast)>0 ) {
        for (gg in 1:ngen) {
          LIK[oophbeforemast,gg] <- LIK[oophbeforemast,gg]*apply( PostIntOophFirstDIS*PostIntOophFirstAFF[,,gg] + (1-PostIntOophFirstDIS) * 
                                                                    PostIntOophFirstUNA[,,gg], 1, prod)*apply( PostIntMastAfterDIS*PostIntMastAfterAFF[,,gg] + (1-PostIntMastAfterDIS) * 
                                                                                                                 PostIntMastAfterUNA[,,gg], 1, prod)
        }
      }
      
    }
    
    # If there are twins in the family, collapse them here #
    if (sum(family$Twins)>0) {
      if (length(unique(family$Twins))>=1 & !any(family$Twins==0)) {loopID <- length(unique(family$Twins))}
      if (length(unique(family$Twins))>1 & any(family$Twins==0)) {loopID <- length(unique(family$Twins))-1}
      family$NewMotherIndex = family$NewFatherIndex = 0
      
      # Because we are collapsing twins, need to replace any offspring's mid and fid
      for (iiiii in 1:loopID) {
        temp <- family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],]
        if (temp$Gender[1]==0) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewMotherIndex"] = temp$ID[1]}
        if (temp$Gender[1]==1) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewFatherIndex"] = temp$ID[1]}
      }
      
      twins = family$ID[family$Twins>0]
      offspring = family$ID[is.element(family$MotherID, twins) | is.element(family$FatherID, twins)]
      if (length(offspring)>0) {
        for (ooo in 1:length(offspring)){
          motherIsTwin = family$Twins[family$ID==family$MotherID[family$ID==offspring[ooo]]]
          fatherIsTwin = family$Twins[family$ID==family$FatherID[family$ID==offspring[ooo]]]
          if (length(motherIsTwin)!=0) {
            if (motherIsTwin!=0) {
              family$MotherID[family$ID==offspring[ooo]] = family$NewMotherIndex[family$ID==family$MotherID[family$ID==offspring[ooo]]]}
          }
          if (length(fatherIsTwin)!=0) {
            if (fatherIsTwin!=0) {
              family$FatherID[family$ID==offspring[ooo]] = family$NewFatherIndex[family$ID==family$FatherID[family$ID==offspring[ooo]]]}
          }
        }
      }
      # get the first twin's ped info for peeling
      firsttwin = which(family$Twins>0)
      firsttwin = firsttwin[match(unique(family$Twins[family$Twins!=0]), family$Twins[family$Twins!=0])]
      nottwins = which(family$Twins==0)
      collapsedtwins = sort(c(firsttwin,nottwins)) 
      ped = family[collapsedtwins,c("ID", "Gender", "FatherID", "MotherID","ethnic")]
      # set up new LIK
      newLIK = LIK
      twinIDs = unique(family$Twins[family$Twins!=0])
      for (ttt in 1:length(twinIDs)) {
        twinrows = which(family$Twins==twinIDs[ttt])
        newLIK[twinrows[1],] = LIK[twinrows[1],] * LIK[twinrows[2],]
        newLIK[twinrows[2],] = rep(NA,ngen)
      }
      # Now take out empty rows
      LIK = newLIK[apply(newLIK,1,function(x){return(!any(is.na(x)))}),]
    }
    
    if (sum(family$Twins)==0) {
      ped = family[,c("ID", "Gender", "FatherID", "MotherID","ethnic")]
    }
    
    #-------------------------------------------------# 
    # Compute posterior probability of carrier status #
    # peelingR  (peeling in R)
    #  outputs: numerator of BayesThereom calculation
    #           weight used for likelihood
    #  logp <- peelingR(allef,LIK,ped=family[,c("ID", "Gender", "FatherID", "MotherID","ethnic")],counselee.id=counselee.id,nloci=nloci)
    #  post <- rescale(logp$num)
    #  ll <- log(sum(logp$num))+logp$weight
    #
    # peelingRC (peeling in C)
    #  outputs: posterior probability
    #
    # When moving to peelingRC, decided to leave ll slot but set to NULL
    # dyn.load('peelingC')
    post <- peelingRC(allef=allef,LIK,ped=ped,counselee.id=counselee.id,nloci=nloci)
    
    return(post)
  }
  
  ## --------------
  ## Calculation for LIK start here.  This is where we start the multiple age imputation process ---------------###
  
  missingage = any(family$AgeBreast==1 | family$AgeOvary==1 | 
                     (family$AgeBreastContralateral==1 & family$AffectedBreast==2))
  
  ## If mis-reporting family history adjustment is turned on, set needed parameters and samples here
  if (MEadj == TRUE) {
    family$Relation<-MakeRelationship(family, counselee.id=counselee.id)
    #store reported age for t0 breast, t00 ovarian
    tO=tOO=matrix(0,1,psize)
    #store reported disease status for d0 breast, d00 ovarian
    dO=dOO=matrix(0,1,psize)
    #store sampled disease status for d1 breast, d11 ovarian 
    d1=d11=matrix(0,n,psize)
    
    #adjusting all female relatives
    femaleRelatives<-which(family$ID !=originalcounselee.id & family$Gender==0)
    seed = ifelse(is.null(params$myseed), .Random.seed[1], params$myseed)
    set.seed(seed)
    for (i in femaleRelatives) {
      tO[1,i]<-ifelse(family$AgeBreast[i]==0, 1, family$AgeBreast[i])
      dO[1,i]<-ifelse(family$AffectedBreast[i]==2, 1, family$AffectedBreast[i])
      
      tOO[1,i]<-ifelse(family$AgeOvary[i]==0, 1, family$AgeOvary[i])
      dOO[1,i]<-family$AffectedOvary[i]
      
      #first degree relatives
      if(family$Relation[i]==2|family$Relation[i]==3|family$Relation[i]==4) {
        ppv=params$ppv.fbc[1]
        npv=params$npv.fbc[1]
        ppv2=params$ppv.foc[1]
        npv2=params$npv.foc[1]
      } else {
        ppv=params$ppv.fbc[2]
        npv=params$npv.fbc[2]
        ppv2=params$ppv.foc[2]
        npv2=params$npv.foc[2]
      }
      
      #adjusting 
      a1<-ifelse(dO[1,i]==1, 1-ppv, npv) 
      d1[,i]=sample(c(0:1),params$nIter, prob=c(a1,1-a1), replace=TRUE)
      
      a1<-ifelse(dOO[1,i]==1, 1-ppv2, npv2) 
      d11[,i]=sample(c(0:1),params$nIter, prob=c(a1,1-a1), replace=TRUE)
    }
  }
  
  
  # Scenario 1: missing age but age imputation turned off, no MEadj  
  if (missingage & imputeAges==FALSE & MEadj==FALSE) {
    agewarning = "Warning: Age imputation has been turned off, but there are unknown ages of some unaffected family members. You may want to get more information about family member ages and re-run the calculation, or set imputeAges=TRUE."
    post = runPeeling(family=family, 
                      params=params, ngen=ngen,
                      oophorectomy=oophorectomy, mastectomy=mastectomy, 
                      psize=psize, 
                      counselee.id=counselee.id, allef=allef)
  }
  
  # Scenario 2: missing age but age imputation turned off, MEadj == TRUE  
  if (missingage & imputeAges==FALSE & MEadj==TRUE) {
    agewarning = "Warning: Age imputation has been turned off, but there are unknown ages of some unaffected family members. You may want to get more information about family member ages and re-run the calculation, or set imputeAges=TRUE."
    postList = NULL
    nIter = params$nIter
    for (iIter in 1:nIter){
      nf = family
      for (i in femaleRelatives){
        nf$AffectedBreast[i]<-ifelse(family$AffectedBreast[i]==2 & d1[iIter,i]==1,2, d1[iIter,i])
        nf$AffectedOvary[i]<-d11[iIter,i]
      }
      postList = rbind(postList,
                       runPeeling(family=nf,  
                                  params=params, ngen=ngen,
                                  oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                  psize=psize, 
                                  counselee.id=counselee.id, allef=allef)
      )
    }
    post = apply(postList, 2, mean)
  }
  
  # Scenario 3: Impute missing ages but ME adjustment turned off
  if (missingage & imputeAges==TRUE & MEadj==FALSE){
    agewarning = "Warning: Unknown ages of some unaffected and affected family members have been imputed. You may want to get more information about family member ages and re-run the calculation."
    ifamily = ImputeAge(fff=family, params=params, model='brcapro', bounds = bounds)
    postList = NULL
    nIter = params$nIter
    
    # Run each imputed age through runPeeling if there are affected relatives
    # who had age imputed
    if (length(ifamily$mem_bc)>0 | length(ifamily$mem_oc)>0 | length(ifamily$mem_bcc)>0 | length(ifamily$mem_mast)>0 | length(ifamily$mem_ooph)>0) {
      for (iIter in 1:nIter){
        # creating imputed fff
        nf = ifamily$fff
        noophorectomy = oophorectomy
        nmastectomy = mastectomy
        
        if (length(ifamily$mem_bc)>0) {
          nf$AgeBreast[ifamily$mem_bc] = ifamily$age_bc[iIter,ifamily$mem_bc]  
        }
        
        if (length(ifamily$mem_oc)>0) {
          nf$AgeOvary[ifamily$mem_oc]<-ifamily$age_oc[iIter,ifamily$mem_oc]	
        }
        
        if (length(ifamily$mem_bcc)>0) {
          nf$AgeBreastContralateral[ifamily$mem_bcc]<-ifamily$age_bcc[iIter,ifamily$mem_bcc]	
        }
        
        if (length(ifamily$mem_mast)>0){
          nf$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
          nmastectomy$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
        }
        
        if (length(ifamily$mem_ooph)>0) {
          nf$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
          noophorectomy$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
        }
        
        postList = rbind(postList,
                         runPeeling(family=nf,  
                                    params=params, ngen=ngen,
                                    oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                    psize=psize, 
                                    counselee.id=counselee.id, allef=allef)
        )
      }
      
      post = apply(postList, 2, mean)
    }
    
    if (length(ifamily$mem_bc)==0 & length(ifamily$mem_oc)==0 & length(ifamily$mem_bcc)==0 & length(ifamily$mem_mast)==0 & length(ifamily$mem_ooph)==0) {
      post = runPeeling(family=ifamily$fff, 
                        params=params, ngen=ngen,
                        oophorectomy=oophorectomy, mastectomy=mastectomy, 
                        psize=psize, 
                        counselee.id=counselee.id, allef=allef)
    }
    
  }
  
  # Scenario 4: Impute missing ages and do the ME adjustment
  if (missingage & imputeAges==TRUE & MEadj==TRUE){
    agewarning = "Warning: Unknown ages of some unaffected and affected family members have been imputed. You may want to get more information about family member ages and re-run the calculation."
    ifamily = ImputeAge(fff=family, params=params, model='brcapro', bounds = bounds)
    postList = NULL
    nIter = params$nIter
    
    # Run each imputed age through runPeeling if there are affected relatives
    # who had age imputed
    if (length(ifamily$mem_bc)>0 | length(ifamily$mem_oc)>0 | length(ifamily$mem_bcc)>0 | 
        length(ifamily$mem_mast)>0 | length(ifamily$mem_ooph)>0) {
      for (iIter in 1:nIter){
        # creating imputed fff
        nf = ifamily$fff
        noophorectomy = oophorectomy
        nmastectomy = mastectomy
        
        for (i in femaleRelatives){
          nf$AffectedBreast[i]<-ifelse(family$AffectedBreast[i]==2 & d1[iIter,i]==1,2, d1[iIter,i])
          nf$AffectedOvary[i]<-d11[iIter,i]
        }
        
        if (length(ifamily$mem_bc)>0) {
          nf$AgeBreast[ifamily$mem_bc] = ifamily$age_bc[iIter,ifamily$mem_bc]  
        }
        
        if (length(ifamily$mem_oc)>0) {
          nf$AgeOvary[ifamily$mem_oc]<-ifamily$age_oc[iIter,ifamily$mem_oc]	
        }
        
        if (length(ifamily$mem_bcc)>0) {
          nf$AgeBreastContralateral[ifamily$mem_bcc]<-ifamily$age_bcc[iIter,ifamily$mem_bcc]	
        }
        
        if (length(ifamily$mem_mast)>0){
          nf$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
          nmastectomy$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
        }
        
        if (length(ifamily$mem_ooph)>0) {
          nf$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
          noophorectomy$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
        }
        
        postList = rbind(postList,
                         runPeeling(family=nf,  
                                    params=params, ngen=ngen,
                                    oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                    psize=psize, 
                                    counselee.id=counselee.id, allef=allef)
        )
      }
      
      post = apply(postList, 2, mean)
    }
    
    # No unknown disease ages.
    if (length(ifamily$mem_bc)==0 & length(ifamily$mem_oc)==0 & length(ifamily$mem_bcc)==0 & 
        length(ifamily$mem_mast)==0 & length(ifamily$mem_ooph)==0) {
      postList = NULL
      nIter = params$nIter
      for (iIter in 1:nIter){
        nf = ifamily$fff
        for (i in femaleRelatives){
          nf$AffectedBreast[i]<-ifelse(family$AffectedBreast[i]==2 & d1[iIter,i]==1,2, d1[iIter,i])
          nf$AffectedOvary[i]<-d11[iIter,i]
        }
        postList = rbind(postList,
                         runPeeling(family=nf,  
                                    params=params, ngen=ngen,
                                    oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                    psize=psize, 
                                    counselee.id=counselee.id, allef=allef)
        )
      }
      post = apply(postList, 2, mean)
    }
  }
  
  # Scenario 5: No missing ages but do the MEadjustment
  if (!missingage & MEadj==TRUE) { 
    agewarning=""
    postList = NULL
    nIter = params$nIter
    for (iIter in 1:nIter){
      nf = family
      for (i in femaleRelatives){
        nf$AffectedBreast[i]<-ifelse(family$AffectedBreast[i]==2 & d1[iIter,i]==1,2, d1[iIter,i])
        nf$AffectedOvary[i]<-d11[iIter,i]
      }
      postList = rbind(postList,
                       runPeeling(family=nf,  
                                  params=params, ngen=ngen,
                                  oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                  psize=psize, 
                                  counselee.id=counselee.id, allef=allef)
      )
    }
    post = apply(postList, 2, mean)
  }
  
  # Scenario 6: No missing ages, no MEadjustment, run peeling once with observed input data.
  if (!missingage & MEadj==FALSE) { 
    agewarning=""
    post = runPeeling(family=family, 
                      params=params, ngen=ngen,
                      oophorectomy=oophorectomy, mastectomy=mastectomy, 
                      psize=psize, 
                      counselee.id=counselee.id, allef=allef)
  }
  
  # save family object to be output
  if (!missingage | imputeAges==FALSE) {family= family}
  if (missingage & imputeAges==TRUE) { family = ifamily$fff}
  
  #### Age imputation loop would stop here, output results
  #### ---------------------------------------------------####
  
  ll <- NULL
  
  post <- matrix(post, nrow=3, ncol=3, byrow=FALSE)
  post <- post[-3,-3]
  rownames(post) <- c("BRCA10","BRCA11")
  colnames(post) <- c("BRCA20","BRCA21") 
  
  ages.cancer <- c(family[which(family$ID==counselee.id),"AgeBreast"],family[which(family$ID==counselee.id),"AgeOvary"],family[which(family$ID==counselee.id),"AgeBreastContralateral"])
  
  current.age <- max(ages.cancer)
  if(proband.current.age + params$age.by > age.max){
    ages <- age.max
  } else{
    ages <- seq(proband.current.age+params$age.by, ifelse(params$age.to>=proband.current.age+params$age.by, params$age.to, age.max), by=params$age.by)
  }
  
  p0 <- post["BRCA10","BRCA20"]
  p2 <- sum(post["BRCA10",])-p0
  p1 <- sum(post[,"BRCA20"])-p0
  p12 <- 1-p1-p2-p0
  
  if (nchar(agewarning)>0) {print(agewarning)}
  
  if (print==TRUE) {
    cat("The probability of being a carrier is",1-p0, "\n an BRCA1 carrier", p1, "\n an BRCA2 carrier", p2, "\n")
  }
  
  if(any(c(p0, p2, p1, p12) == 0) & !is.null(germline.testing) &
     any(c(params$sensitivity1, params$specificity1, params$sensitivity2, params$specificity2) == 1)){
    warning("Some of the estimated probabilities are 0 or 1, most likely due to the
            incorporation of reported germline testing results (by default, we assume
            that the sensitivity and specificity for all germline tests is 1).
            However, this does not guarantee that the person is a noncarrier or
            mutation carrier; a more accurate estimate may be achieved with
            user-specified sensitivities and specificities.")
  }
  
  if(pro.agemax == 1){
    predictions <- future.risk <- data.frame()
    warning(paste("Proband is older than ", age.max - 1, ". Future risk prediction is not calculated.", sep = ""))
  } else{
    # Now calculate future risk predictions.
    # Use original counselee id (if an identical twin) to capture the correct current disease status
    predictions <- NULL
    
    ages.by1 <- (proband.current.age+1):max(ages)
    
    
    #  if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]>0) {future.risk.penet <- CBRCApenet.metaDSL.2009}
    #  if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==0) {future.risk.penet <- params$penetrance}
    
    future.risk.penet <- CBRCApenet
    
    ## start here with incorporating mastectomy...
    
    if(currfamily[which(currfamily$ID==originalcounselee.id),"Gender"]==0){#female
      
      if(!is.null(oophorectomy)) prob.ooph = oophorectomy$Oophorectomy[currfamily$ID==originalcounselee.id] else prob.ooph = 0
      if(!is.null(mastectomy))   prob.mast = mastectomy$Mastectomy[currfamily$ID==originalcounselee.id]     else prob.mast = 0
      
      if(prob.ooph==1 | prob.mast==1) {
        
        # Set up HR so that first 9 HR are for breast, second 9 are for ovary
        # Values depend on intervention done
        if (prob.ooph==1 & prob.mast==0) { # proband had ooph only
          HR <- params$PostOophorectomyHR
        }
        if (prob.ooph==0 & prob.mast==1) { # proband had mastectomy only
          HR <- c(params$PostMastectomyHR, rep(1,9))
        }
        if (prob.ooph==1 & prob.mast==1) { # proband had both mast and ooph, use mast for BC and ooph for OC
          HR <- c(params$PostMastectomyHR, params$PostOophorectomyHR[10:18])
        }
      }else {HR <- rep(1, length(params$PostOophorectomyHR))}
      
      # HR[1]=B00; HR[2]=B10; HR[4]=B01; HR[5]=B11; add 9 to get for ovary
      if (prob.ooph==1 & prob.mast==0) { # Apply benefit of ooph to all ages for ovarian cancer risk, ages 1-44 for br ca risk
        future.risk.penet$fX[1:44,'B00'] <- future.risk.penet$fX[1:44,'B00']*HR[1]
        future.risk.penet$fY[1:age.max,'B00'] <- future.risk.penet$fY[1:age.max,'B00']*HR[1+9]
        future.risk.penet$fX[1:44,'B10'] <- future.risk.penet$fX[1:44,'B10']*HR[2]
        future.risk.penet$fY[1:age.max,'B10'] <- future.risk.penet$fY[1:age.max,'B10']*HR[2+9]
        future.risk.penet$fX[1:44,'B01'] <- future.risk.penet$fX[1:44,'B01']*HR[4]
        future.risk.penet$fY[1:age.max,'B01'] <- future.risk.penet$fY[1:age.max,'B01']*HR[4+9]
        future.risk.penet$fX[1:44,'B11'] <- future.risk.penet$fX[1:44,'B11']*HR[5]
        future.risk.penet$fY[1:age.max,'B11'] <- future.risk.penet$fY[1:age.max,'B11']*HR[5+9]
      }else { # benefit of mastectomy for future BrCa overrules ooph here
        future.risk.penet$fX[1:age.max,'B00'] <- future.risk.penet$fX[1:age.max,'B00']*HR[1]
        future.risk.penet$fY[1:age.max,'B00'] <- future.risk.penet$fY[1:age.max,'B00']*HR[1+9]
        future.risk.penet$fX[1:age.max,'B10'] <- future.risk.penet$fX[1:age.max,'B10']*HR[2]
        future.risk.penet$fY[1:age.max,'B10'] <- future.risk.penet$fY[1:age.max,'B10']*HR[2+9]
        future.risk.penet$fX[1:age.max,'B01'] <- future.risk.penet$fX[1:age.max,'B01']*HR[4]
        future.risk.penet$fY[1:age.max,'B01'] <- future.risk.penet$fY[1:age.max,'B01']*HR[4+9]
        future.risk.penet$fX[1:age.max,'B11'] <- future.risk.penet$fX[1:age.max,'B11']*HR[5]
        future.risk.penet$fY[1:age.max,'B11'] <- future.risk.penet$fY[1:age.max,'B11']*HR[5+9]
      }
      
      hFX1 <- hFX2 <- hFY1 <- hFY2 <- hFX0 <- hFX12 <- hFY0 <- hFY12 <- rep(0,max(ages))
      future.risk <- data.frame(hFX0, hFY0, hFX1,hFY1,hFX2,hFY2,hFX12,hFY12)
      
      if(net == FALSE){
        ## crude risk
        future.risk$hFX0[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,'B00'], haz.d$femaleBC)[ages.by1],
          haz.d$femaleBC[ages.by1]
        )
        future.risk$hFY0[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fY[,'B00'], haz.d$ovary)[ages.by1],
          haz.d$ovary[ages.by1]
        )
        future.risk$hFX1[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B10"], haz.d$femaleBC)[ages.by1],
          haz.d$femaleBC[ages.by1]
        )
        future.risk$hFY1[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fY[,"B10"], haz.d$ovary)[ages.by1],
          haz.d$ovary[ages.by1]
        )
        future.risk$hFX2[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B01"], haz.d$femaleBC)[ages.by1],
          haz.d$femaleBC[ages.by1]
        )
        future.risk$hFY2[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fY[,"B01"], haz.d$ovary)[ages.by1],
          haz.d$ovary[ages.by1]
        )
        future.risk$hFX12[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B11"], haz.d$femaleBC)[ages.by1],
          haz.d$femaleBC[ages.by1]
        )
        future.risk$hFY12[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fY[,"B11"], haz.d$ovary)[ages.by1],
          haz.d$ovary[ages.by1]
        )
      } else{
        ## net risk
        future.risk$hFX0[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B00'],
                                                          proband.current.age, ages.by1)
        future.risk$hFY0[ages.by1] <- calc.future.risk.nd(future.risk.penet$fY[, 'B00'],
                                                          proband.current.age, ages.by1)
        future.risk$hFX1[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B10'],
                                                          proband.current.age, ages.by1)
        future.risk$hFY1[ages.by1] <- calc.future.risk.nd(future.risk.penet$fY[, 'B10'],
                                                          proband.current.age, ages.by1)
        future.risk$hFX2[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B01'],
                                                          proband.current.age, ages.by1)
        future.risk$hFY2[ages.by1] <- calc.future.risk.nd(future.risk.penet$fY[, 'B01'],
                                                          proband.current.age, ages.by1)
        future.risk$hFX12[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B11'],
                                                           proband.current.age, ages.by1)
        future.risk$hFY12[ages.by1] <- calc.future.risk.nd(future.risk.penet$fY[, 'B11'],
                                                           proband.current.age, ages.by1)
      }
      X.risk <- future.risk$hFX1[ages]*p1 + future.risk$hFX2[ages]*p2 + future.risk$hFX0[ages]*p0 + future.risk$hFX12[ages]*p12
      Y.risk <- future.risk$hFY1[ages]*p1 + future.risk$hFY2[ages]*p2 + future.risk$hFY0[ages]*p0 + future.risk$hFY12[ages]*p12
      if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==2) {X.risk <- rep(NA, length(ages))}
      if (currfamily$AffectedOvary[which(currfamily$ID==originalcounselee.id)]==1) {Y.risk <- rep(NA, length(ages))}
      
      
    }else{#male
      
      if(!is.null(mastectomy))   prob.mast = mastectomy$Mastectomy[currfamily$ID==originalcounselee.id]     else prob.mast = 0
      
      if(prob.mast==1) {
        
        # Set up HR so that first 9 HR are for breast, second 9 are for ovary
        # Values depend on intervention done
        HR <- c(params$PostMastectomyHR, rep(1,9))
        
      }else {HR <- rep(1, length(params$PostOophorectomyHR))}
      
      # HR[1]=B00; HR[2]=B10; HR[4]=B01; HR[5]=B11; add 9 to get for ovary
      # benefit of mastectomy for future BrCa overrules ooph here
      future.risk.penet$fX[1:age.max,'B00'] <- future.risk.penet$fX[1:age.max,'B00']*HR[1]
      future.risk.penet$fX[1:age.max,'B10'] <- future.risk.penet$fX[1:age.max,'B10']*HR[2]
      future.risk.penet$fX[1:age.max,'B01'] <- future.risk.penet$fX[1:age.max,'B01']*HR[4]
      future.risk.penet$fX[1:age.max,'B11'] <- future.risk.penet$fX[1:age.max,'B11']*HR[5]
      
      
      hFX1 <- hFX2 <- hFX0 <- hFX12 <- rep(0,max(ages))
      future.risk <- data.frame(hFX0,hFX1,hFX2,hFX12)  
      
      hMX1 <- hMX2 <- hMX0 <- hMX12 <- rep(0,max(ages))
      future.risk <- data.frame(hMX0,hMX1,hMX2,hMX12)
      if(net == FALSE){
        ## crude risk
        future.risk$hMX0[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,'B00'], haz.d$maleBC)[ages.by1],
          haz.d$maleBC[ages.by1]
        )
        future.risk$hMX1[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B10"], haz.d$maleBC)[ages.by1],
          haz.d$maleBC[ages.by1]
        )
        future.risk$hMX2[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B01"], haz.d$maleBC)[ages.by1],
          haz.d$maleBC[ages.by1]
        )
        future.risk$hMX12[ages.by1] <- calc.future.risk(
          dens2haz.cs(future.risk.penet$fX[,"B11"], haz.d$maleBC)[ages.by1],
          haz.d$maleBC[ages.by1]
        )
      } else{
        ## net risk
        future.risk$hMX0[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B00'],
                                                          proband.current.age, ages.by1)
        future.risk$hMX1[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B10'],
                                                          proband.current.age, ages.by1)
        future.risk$hMX2[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B01'],
                                                          proband.current.age, ages.by1)
        future.risk$hMX12[ages.by1] <- calc.future.risk.nd(future.risk.penet$fX[, 'B11'],
                                                           proband.current.age, ages.by1)
      }
      
      X.risk <- future.risk$hMX1[ages]*p1 + future.risk$hMX2[ages]*p2 + future.risk$hMX0[ages]*p0 + future.risk$hMX12[ages]*p12
      Y.risk <- rep(0, length(ages))
      
      if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==2) {X.risk <- rep(NA, length(ages))}
      
    }
    
    ## Special case if the proband already breast cancer and we're calculating future risk of CBC
    ## (overwriting previously calculated CBC future risk "X.risk")
    if(family$AffectedBreast[family$ID==counselee.id] == 1){
      if(net == FALSE){
        if(family$AgeBreast[family$ID == counselee.id] > 40){
          if(family$Gender[family$ID == counselee.id] == 0){
            risk <- calc.future.risk.cbc(cbc.net$fFX.Over40,
                                         penet.death.bc.net$Female[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = FALSE)
          } else{
            risk <- calc.future.risk.cbc(cbc.net$fMX.Over40,
                                         penet.death.bc.net$Male[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = FALSE)
          }
        } else{
          if(family$Gender[family$ID == counselee.id] == 0){
            risk <- calc.future.risk.cbc(cbc.net$fFX.Under40,
                                         penet.death.bc.net$Female[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = FALSE)
          } else{
            risk <- calc.future.risk.cbc(cbc.net$fMX.Under40,
                                         penet.death.bc.net$Male[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = FALSE)
          }
        }
      } else{
        if(family$AgeBreast[family$ID == counselee.id] > 40){
          if(family$Gender[family$ID == counselee.id] == 0){
            risk <- calc.future.risk.cbc(cbc.net$fFX.Over40,
                                         penet.death.bc.net$Female[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = TRUE)
          } else{
            risk <- calc.future.risk.cbc(cbc.net$fMX.Over40,
                                         penet.death.bc.net$Male[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = TRUE)
          }
        } else{
          if(family$Gender[family$ID == counselee.id] == 0){
            risk <- calc.future.risk.cbc(cbc.net$fFX.Under40,
                                         penet.death.bc.net$Female[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = TRUE)
          } else{
            risk <- calc.future.risk.cbc(cbc.net$fMX.Under40,
                                         penet.death.bc.net$Male[, race],
                                         proband.current.age,
                                         family$AgeBreast[family$ID == counselee.id],
                                         ages - proband.current.age,
                                         net = TRUE)
          }
        }
      }
      X.risk <- risk[, 1] * p0 + risk[, 2] * p1 + risk[, 3] * p2 + risk[, 4] * p12
    }
    
    
    predictions <- data.frame(ages, breast.risk=X.risk, ovarian.risk=Y.risk)
    if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]!=1)
    {colnames(predictions) <- c("By age", "Breast Ca Risk", "Ovarian Ca Risk")}
    if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==1)
    {colnames(predictions) <- c("By age", "Contralateral Breast Ca Risk", "Ovarian Ca Risk")}
    
    
    if(print==TRUE) {
      cat("The risks of developing cancers are\n")   
      print(predictions)
    }
    
  }
  
  post <- array(post, c(nrow(post), ncol(post), 1))
  
  dn <- list(0)
  dn[[1]] <- c("BRCA10", "BRCA11")
  dn[[2]] <- c("BRCA20", "BRCA21")
  dn[[3]] <- c("BRCA")
  dimnames(post) <- dn
  
  probs <- data.frame(1-p0,p1,p2,p12)
  names(probs) <- c("Pr(Being a carrier)", "Pr(BRCA1 mutation)", "Pr(BRCA2 mutation)", "Pr(Both genes mutated)")
  
  # if (sum(family$Twins)>0) {family <- inputfamily}
  
  return(new(Class="BayesMendel", family=family, posterior=post, probs=probs, predictions=predictions, 
             counselee.id=originalcounselee.id, loglik=ll, future.risk=future.risk))
  
} # End of brcapro()








