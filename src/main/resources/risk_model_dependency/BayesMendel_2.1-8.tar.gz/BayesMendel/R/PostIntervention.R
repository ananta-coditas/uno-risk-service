PostIntervention <- function(intfamily, whichintervention="Oophorectomy")
{
  ## Purpose: Truncate pre-intervention outcomes, Keep only post-intervention outcomes
  ## ----------------------------------------------------------------------
  ## Arguments: intfamily, intage
  ## ----------------------------------------------------------------------
  ## Author: Hormuzd Katki, Date: 20 Mar 2006, 19:01


  # Truncate outcomes before intage
  # Get maximum age for censoring
  psize <- dim(intfamily)[1]
 intage <- ifelse(whichintervention=="Oophorectomy", intfamily[,"AgeOophorectomy"],intfamily[,"AgeMastectomy"])
  ages.cancer <- data.frame(intfamily[,"AgeBreast",drop=FALSE],intfamily[,"AgeOvary",drop=FALSE],intfamily[,"AgeBreastContralateral",drop=FALSE])
#  if (psize==1) intmaxage <- max(intages.cancer)
  intmaxage <- apply(ages.cancer,1,max)
  
  # ovarian cancer
  truncatethese <- intfamily[,"AgeOvary"]<=intage & intfamily[,"AffectedOvary"]==1
  intfamily[truncatethese,"AffectedOvary"] <- 0
  intfamily[truncatethese,"AgeOvary"] <- intmaxage[truncatethese]

  # ovarian cancer slot has censoring time: don't change the ovarian cancer indicator and
  # make sure it has the latest censoring time
  truncatethese <- intfamily[,"AgeOvary"]<=intage & intfamily[,"AffectedOvary"]==0
  intfamily[truncatethese,"AgeOvary"] <- intmaxage[truncatethese]

  # Censor both breast cancers before intervention
  truncatethese <- intfamily[,"AgeBreast"]<=intage & intfamily[,"AgeBreastContralateral"]<=intage & intfamily[,"AffectedBreast"]==2
  intfamily[truncatethese,"AffectedBreast"] <- 0
  intfamily[truncatethese,"AgeBreast"] <- intmaxage[truncatethese]
  intfamily[truncatethese,"AgeBreastContralateral"] <- intmaxage[truncatethese]

  # Censor sole breast cancer before intervention
  truncatethese <- intfamily[,"AgeBreast"]<=intage & intfamily[,"AffectedBreast"]==1
  intfamily[truncatethese,"AffectedBreast"] <- 0
  intfamily[truncatethese,"AgeBreast"] <- intmaxage[truncatethese]

  # 1st breast cancer before intervention, second one after intervention
  # Move second so it is a first breast cancer, censor out the second
  truncatethese <- intfamily[,"AgeBreast"]<=intage & intfamily[,"AgeBreastContralateral"]>intage & intfamily[,"AffectedBreast"]==2
  intfamily[truncatethese,"AffectedBreast"] <- 1
  intfamily[truncatethese,"AgeBreast"] <- intfamily[truncatethese,"AgeBreastContralateral"]
  intfamily[truncatethese,"AgeBreastContralateral"] <- intmaxage[truncatethese]

  # If no interventions anywhere, censor all ages at maxage
  truncatethese <- intfamily[,"AffectedBreast"]==0 & intfamily[,"AffectedOvary"]==0
  intfamily[truncatethese,"AgeBreast"] <- intmaxage[truncatethese]
  intfamily[truncatethese,"AgeOvary"] <- intmaxage[truncatethese]
  intfamily[truncatethese,"AgeBreastContralateral"] <- intmaxage[truncatethese]
  
  # Don't need to do anything if both cancers are after intervention
  
  # Return
  return(intfamily)
}
