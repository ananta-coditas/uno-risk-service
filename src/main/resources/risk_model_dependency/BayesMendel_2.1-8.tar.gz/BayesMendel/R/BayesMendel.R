# Function to create objects of class 'BayesMendel'
# Output from 'brcapro' and 'MMRpro' - family matrix and probabilities - used to plot pedigree structure
# using generic function 'plot'

# Updates, v2.1.  Problem with plotting when there are no affected members
# Need to change affected matrix to 0/1, not 1/2.

require(kinship2)

setClass("BayesMendel", representation(family="data.frame", posterior="array", probs="data.frame", predictions="data.frame", counselee.id="numeric", loglik="NULL",future.risk="data.frame"))

setMethod("plot", signature = "BayesMendel", function(x, y, ...) {

	family <- slot(x, "family")
	posterior <- slot(x, "posterior")
	probs <- slot(x, "probs")
	counselee.id <- slot(x, "counselee.id")
        loglik <- slot(x, "loglik")
        future.risk <- slot(x, "future.risk")

	if (is.null(family$status)) {status=rep(0, nrow(family))}
	if (!is.null(family$status)) {status=family$status}	
	
	id <- family$ID
	dadid <- family$FatherID
	momid <- family$MotherID
	sex <- family$Gender
	sex[sex==0] <- 2

	refs <- 1:length(id)
	get1 <- refs[dadid==0 & momid > 0]
	get2 <- refs[dadid > 0 & momid==0]
	rem <- sort(c(get1, get2))

	num <- length(unique(momid[get1])) + length(unique(dadid[get2]))
	
	if (num > 0) {

	newid <- max(id)+(1:num)
	newid1 <- newid[1:length(unique(momid[get1]))]
	newid2 <- newid[(length(unique(momid[get1]))+1):(length(newid))]

	id <- c(id, newid)
	sex <- c(sex, rep(1, length(unique(momid[get1]))), rep(2, length(unique(dadid[get2]))))

	dadid <- c(dadid, rep(0, num))
	momid <- c(momid, rep(0, num))	
	
	if (length(get1) > 0) {
		for (i in 1:length(get1)) {
			dadid[id==id[get1[i]]] <- newid1[unique(momid[get1])==momid[get1[i]]]
		}
	}

	if (length(get2) > 0) {
		for (i in 1:length(get2)) {
			momid[id==id[get2[i]]] <- newid2[unique(dadid[get2])==dadid[get2[i]]]
		}
	}

	}

	if (!is.null(family$AffectedColon)) {
		affected <- cbind(family$AffectedColon, family$AffectedEndometrium)
		affected[affected >= 1] <- 1

		ages.cc <- c(family$AgeColon, rep(1, num))
		ages.ec <- c(family$AgeEndometrium, rep(1, num))
		cc <- family$AffectedColon
		ec <- family$AffectedEndometrium
		
	}

	if (!is.null(family$AffectedBreast)) {
		bc2 <- family$AffectedBreast
		bc2[bc2<=1] <- 1
		affected <- cbind(family$AffectedBreast, family$AffectedOvary)
		affected[affected >= 1] <- 1
		
		ages.bc1 <- c(family$AgeBreast, rep(1, num))
		ages.oc <- c(family$AgeOvary, rep(1, num))
		ages.bc2 <- c(family$AgeBreastContralateral, rep(1, num))
		bc <- family$AffectedBreast
		oc <- family$AffectedOvary
	}

	if (!is.null(family$AffectedPancreas)) {
		affected <- cbind(family$AffectedPancreas)
		affected[affected >= 1] <- 1
		
		ages.pc <- c(family$AgePancreas, rep(1, num))
		pc <- family$AffectedPancreas
	}

        if (!is.null(family$AffectedSkin)) {
		affected <- cbind(family$AffectedSkin)
		affected[affected >= 1] <- 1
		
		ages.mel <- c(family$AgeSkin, rep(1, num))
		mel <- family$AffectedSkin
	}

	if (!is.null(family$AffectedColon) | !is.null(family$AffectedBreast)) affected <- rbind(affected, matrix(0, nrow=num, ncol=2))
	if (!is.null(family$AffectedPancreas) | !is.null(family$AffectedSkin)) affected <- c(affected, rep(0, num))
	status <- c(status, rep(0, num))

        relations <- NULL
        
        if (!is.null(family$Twins) & sum(family$Twins)>0) {
          howmanytwins <- max(family$Twins)
          id1 <- id2 <- code <- NULL
          for (ttt in 1:howmanytwins) {
            id1 <- c(id1,family$ID[family$Twins==ttt][1])
            id2 <- c(id2,family$ID[family$Twins==ttt][2])
            code <- c(code, 1)
          }
          relations <- matrix(c(id1,id2,code),byrow=F,ncol=3)
          ped.y <- kinship2::pedigree(id, dadid, momid, sex, affected, status, relation=relations)
        }

        if ((!is.null(family$Twins) & sum(family$Twins)==0) | is.null(family$Twins)) {
           ped.y <- kinship2::pedigree(id, dadid, momid, sex, affected, status)
        }
        
	par(xpd=TRUE)
	plt <- kinship2::plot.pedigree(ped.y, id=rep("",length(ped.y$id)), align=FALSE)
	xp <- plt$x
	yp <- plt$y
	
	inc <- (abs(min(yp,na.rm=T)) - abs(max(yp,na.rm=T)))/12
	xp.inc <- (abs(min(xp,na.rm=T)) - abs(max(xp,na.rm=T)))/50

	couns <- counselee.id
	xp.couns <- xp[id==couns]
	yp.couns <- yp[id==couns]
	#points(xp.couns, yp.couns, cex=5)
	arrows(xp.couns-.35, yp.couns-.15, xp.couns-0.1, yp.couns-0.1, length=0.1)

	if (dim(posterior)[1] > 0) {
			
		if (!is.null(family$AffectedColon)) {

		marg <- rep(0,3)
 		marg[1] <- 1-sum(posterior[1,,])
 		marg[2] <- 1-sum(posterior[,1,])
  		marg[3] <- 1-sum(posterior[,,1])

		mtext(paste("Noncarrier probability =", round(posterior[1,1,1], digits=3)), at = 0.05*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		mtext(paste("MLH1 carrier probability =", round(marg[1], digits=3)), at = 0.625*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		mtext(paste("MSH2 carrier probability =", round(marg[2], digits=3)), at = 0.05*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
		mtext(paste("MSH6 carrier probability =", round(marg[3], digits=3)), at = 0.625*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
	
		}
	
		if (!is.null(family$AffectedBreast)) {


		mtext(paste("Noncarrier probability =", round(posterior[1,1,1], digits=3)), at = 0.05*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		mtext(paste("BRCA2 carrier probability =", round(posterior[1,2,1], digits=3)), at = 0.625*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		mtext(paste("BRCA1 carrier probability =", round(posterior[2,1,1], digits=3)), at = 0.05*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
		mtext(paste("BRCA1 & BRCA2 carrier probability =", round(posterior[2,2,1], digits=3)), at = 0.625*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
	
		}

		
		if (!is.null(family$AffectedPancreas)) {

		mtext(paste("Carrier probability =", round(probs[1], digits=3)), at = 0.05*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		#mtext(paste("MLH1 carrier probability =", round(marg[1], digits=3)), at = 0.625*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		#mtext(paste("MSH2 carrier probability =", round(marg[2], digits=3)), at = 0.05*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
		#mtext(paste("MSH6 carrier probability =", round(marg[3], digits=3)), at = 0.625*max(xp,na.rm=T), line=1, cex=0.65, adj=0)
	
		}

                if (!is.null(family$AffectedSkin)) {

		mtext(paste("Carrier probability =", round(probs[1], digits=3)), at = 0.05*max(xp,na.rm=T), line=2.5, cex=0.65, adj=0)
		
	
		}

	}
   
	if (!is.null(family$AffectedBreast)) {

	# Plot ages of non-cancer individuals #
	xph <- xp[bc == 0 & oc == 0]
	yph <- yp[bc == 0 & oc == 0]
	ageh <- ages.bc1[bc == 0 & oc == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of breast cancer individuals #
	xph <- xp[bc >= 1]
	yph <- yp[bc >= 1]
	ageh <- ages.bc1[bc >= 1]
	ageh <- ageh[ageh > 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("BC (1) ", as.character(ageh)), cex = 0.75)}
	
	# Plot ages of contralateral breast cancer individuals #
	xph <- xp[bc == 2]
	yph <- yp[bc == 2]
	ageh <- ages.bc2[bc == 2]
	ageh <- ageh[ageh > 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("BC (2) ", as.character(ageh)), cex = 0.75)}

	# Plot ages of ovarian cancer individuals #

		# Plot OC who do not have BC #
	
		xph <- xp[oc > 0 & bc == 0]
		yph <- yp[oc > 0& bc == 0]
		ageh <- ages.oc[oc > 0 & bc == 0]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("OC ", as.character(ageh)), cex = 0.75)}
	
		# Plot OC who do have BC but not BC contralateral #
		
		xph <- xp[oc > 0 & bc == 1]
		yph <- yp[oc > 0& bc == 1]
		ageh <- ages.oc[oc > 0 & bc == 1]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("OC ", as.character(ageh)), cex = 0.75)}
		
		# Plot OC who do have BC and BC contralateral #
		
		xph <- xp[oc > 0 & bc == 2]
		yph <- yp[oc > 0& bc == 2]
		ageh <- ages.oc[oc > 0 & bc == 2]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - 2*inc, paste("OC ", as.character(ageh)), cex = 0.75)}

	}

	if (!is.null(family$AffectedColon)) {

	
	# Plot ages of non-cancer individuals #
	xph <- xp[cc == 0 & ec == 0]
	yph <- yp[cc == 0 & ec == 0]
	ageh <- ages.cc[cc == 0 & ec == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of colon cancer individuals #
	xph <- xp[cc > 0]
	yph <- yp[cc > 0]
	ageh <- ages.cc[cc > 0]
	ageh <- ageh[ageh > 0]
	yph <- yph[ageh > 1]
	xph <- xph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("CC ", as.character(ageh)), cex = 0.75)}

	# Plot ages of endometrium cancer individuals #
		
		# Plot ec cases who also have CC #
		xph <- xp[ec > 0 & cc > 0]
		yph <- yp[ec > 0 & cc > 0]
		ageh <- ages.ec[ec > 0 & cc > 0]
		ageh <- ageh[ageh > 0]
		xph <- xph[ageh > 1]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]
		if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("EC ", as.character(ageh)), cex = 0.75)}

		# Plot ec cases who do not have cc #
		xph <- xp[ec > 0 & cc == 0]
		yph <- yp[ec > 0 & cc == 0]
		ageh <- ages.ec[ec > 0 & cc == 0]
		ageh <- ageh[ageh > 0]
		xph <- xph[ageh > 1]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]
		if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("EC ", as.character(ageh)), cex = 0.75)}

	}


	if (!is.null(family$AffectedPancreas)) {
	
	# Plot ages of non-cancer individuals #
	xph <- xp[pc == 0]
	yph <- yp[pc == 0]
	ageh <- ages.pc[pc == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of pancreas cancer individuals #
	xph <- xp[pc > 0]
	yph <- yp[pc > 0]
	ageh <- ages.pc[pc > 0]
	ageh <- ageh[ageh > 0]
	yph <- yph[ageh > 1]
	xph <- xph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("PC ", as.character(ageh)), cex = 0.75)}

	}

       if (!is.null(family$AffectedSkin)) {
	
	# Plot ages of non-cancer individuals #
	xph <- xp[mel == 0]
	yph <- yp[mel == 0]
	ageh <- ages.mel[mel == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of pancreas cancer individuals #
	xph <- xp[mel > 0]
	yph <- yp[mel > 0]
	ageh <- ages.mel[mel > 0]
	ageh <- ageh[ageh > 0]
	yph <- yph[ageh > 1]
	xph <- xph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("Mel ", as.character(ageh)), cex = 0.75)}

	}


})




