ReadCaGeneFam <- function(model="brcapro",infile="family.dat"){

  # Extract the number of members
  members <- readLines(con=infile,n=1)
  num.members <- as.numeric(substr(members[1],13,40))

  # Skip the first 13 lines and then return the number of rows equal to the number of members
  corefam <- matrix(scan(infile,skip=13,nlines=num.members),byrow=TRUE,ncol=12)
  corefam <- data.frame(corefam[,c(1,3,4,5)])
  names(corefam) <- c("ID", "Gender", "FatherID", "MotherID")

 
  if(model=="brcapro"){
    dis <- matrix(scan(infile,skip=13,nlines=num.members),byrow=TRUE,ncol=12)
    corefam2 <- data.frame(dis[,c(6,7,8,9,10)])
    names(corefam2) <- c("AffectedBreast","AffectedOvary","AgeBreast","AgeOvary","AgeBreastContralateral")
    family <- data.frame(corefam, corefam2)
    germline.testing <- data.frame(dis[,11:12])
    names(germline.testing) <- c("BRCA1","BRCA2")

    lower <- read.table(infile,skip=13+num.members+6,nrows=num.members,fill=T,sep="",colClasses = "character")
    
    oophorectomy <- data.frame(ifelse(lower$V10>0, 1, 0), lower$V10)
    names(oophorectomy) <- c("Oophorectomy", "AgeOophorectomy")

    markers <- matrix(lower$V11, nrow=num.members)
    markers <- matrix(as.numeric(unlist(strsplit(lower$V11, ""))), nrow=num.members, byrow=T)
    ER <- ifelse(markers[,1]==0 & markers[,2]==0, 0, ifelse(markers[,1]==2 | markers[,2]==2, 2, 1))
    PR <- ifelse(markers[,3]==0 & markers[,4]==0, 0, ifelse(markers[,3]==2 | markers[,4]==2, 2, 1))
    CK14 <- ifelse(markers[,5]==0 & markers[,6]==0, 0, ifelse(markers[,5]==2 | markers[,6]==2, 2, 1))
    CK5.6 <- ifelse(markers[,7]==0 & markers[,8]==0, 0, ifelse(markers[,7]==2 | markers[,8]==2, 2, 1))
    marker.testing <- data.frame(ER, PR, CK14, CK5.6)

    output <- list(family, germline.testing, marker.testing, oophorectomy)
    names(output) <- c("family", "germline.testing", "marker.testing", "oophorectomy")
    return(output)

  }

  if(model=="MMRpro"){

    lower <- read.table(infile,skip=23+num.members+6,nrows=num.members,fill=T,sep="",colClasses = "character")
    MLH1 <- lower$V6
    MSH2 <- lower$V7
    MSH6 <- lower$V8
    germline.testing <- data.frame(MLH1, MSH2, MSH6)  

    MSI <- lower$V9
    marker.testing <- data.frame(MSI)

    AffectedColon <- rep(0, num.members)
    AffectedColon[grep("Col", lower$V12)] <- 1
    AffectedEndometrium <- rep(0, num.members)
    AffectedEndometrium[grep("End", lower$V12)] <- 1

    AgeColon <- AgeEndometrium <- as.numeric(lower$V2)

    AgeColon[grep("Col", lower$V12)] <- as.numeric(unlist(strsplit(as.character(lower$V13[grep("Col", lower$V12)]), split=";")))
    AgeEndometrium[grep("End", lower$V12)] <- as.numeric(unlist(strsplit(as.character(lower$V13[grep("End", lower$V12)]), split=";")))

    family <- data.frame(corefam, AffectedColon, AffectedEndometrium, AgeColon, AgeEndometrium)

    output <- list(family, germline.testing, marker.testing)
    names(output) <- c("family", "germline.testing", "marker.testing")
    return(output)

  }


  if(model=="pancpro"){

  lower <- read.table(infile,skip=23+num.members+6,nrows=num.members,fill=T,sep="",colClasses = "character")
  
  AffectedPancreas <- rep(0, num.members)
  AffectedPancreas[grep("Pan", lower$V12)] <- 1
  AgePancreas <- as.numeric(lower$V2)
  AgePancreas[grep("Pan", lower$V12)] <- as.numeric(unlist(strsplit(as.character(lower$V13[grep("Pan", lower$V12)]), split=";")))

  family <- data.frame(corefam, AffectedPancreas, AgePancreas)
  
    output <- list(family)
    names(output) <- c("family")
    return(output)

  }



}
