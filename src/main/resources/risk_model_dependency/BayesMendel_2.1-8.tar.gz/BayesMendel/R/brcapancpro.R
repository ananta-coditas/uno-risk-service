####testing code of brcapancpro####

## Updated May 2016 by Amanda, incorporating in BayesMendel R package using v2.1-3

brcapancpro <- function(family, counselee.id = 1, params = brcapancparams(), 
                        race = "Unknown",
                        germline.testing=NULL,marker.testing=NULL,
                        oophorectomy=NULL, mastectomy=NULL,
                        predict=TRUE,
                        imputeRelatives=TRUE, imputeAges=TRUE,
                        print = TRUE, bounds = FALSE){

  warnmsg = ""
  if (imputeRelatives==TRUE & imputeAges==FALSE) {
    imputeAges=TRUE
    warnmsg = paste(warnmsg, "Warning: imputeAges was input as false, but has been set to TRUE.  If imputeRelatives=TRUE then by default imputeAges must also be TRUE.")
  }
  if (nchar(warnmsg) > 0) {print(warnmsg)}
  
  age.max <- 94 ## maximum age that BRCAPRO takes
  
  pro.agemax <- 0
  ## if proband is older than the maximum age - 1, then we only return carrier probabilities
  if(max(family[which(family$ID == counselee.id), c("AgeBreast", "AgeOvary", "AgeBreastContralateral")], na.rm = TRUE) > age.max - 1){
    pro.agemax <- 1
  }
  
  family <- CheckFamStructure("brcapancpro",family,counselee.id,
                              germline.testing,marker.testing,
                              oophorectomy,mastectomy,
                              imputeAges, imputeRelatives,
                              params, bounds)
  
  ## truncating ages past age.max to age.max, since we don't have data past age age.max
  if("AgeBreast" %in% colnames(family)){
    family$AgeBreast[family$AgeBreast > age.max] <- age.max
  }
  if("AgePancreas" %in% colnames(family)){
    family$AgePancreas[family$AgePancreas > age.max] <- age.max
  }
  if("AgeBreastContralateral" %in% colnames(family)){
    family$AgeBreastContralateral[family$AgeBreastContralateral > age.max] <- age.max
  }
  if("AgeOvary" %in% colnames(family)){
    family$AgeOvary[family$AgeOvary > age.max] <- age.max
  }
  if("AgeMastectomy" %in% colnames(family)){
    family$AgeMastectomy[family$AgeMastectomy > age.max] <- age.max
  }
  if("AgeOophorectomy" %in% colnames(family)){
    family$AgeOophorectomy[family$AgeOophorectomy > age.max] <- age.max
  }
  
  if("AgeBreastLower" %in% colnames(family)){
    family$AgeBreastLower[family$AgeBreastLower > age.max] <- age.max
    family$AgeBreastLower[family$AgeBreastLower < 1] <- 1
  }
  if("AgeBreastUpper" %in% colnames(family)){
    family$AgeBreastUpper[family$AgeBreastUpper > age.max] <- age.max
    family$AgeBreastUpper[family$AgeBreastUpper < 1] <- 1
  }
  if("AgeOvaryLower" %in% colnames(family)){
    family$AgeOvaryLower[family$AgeOvaryLower > age.max] <- age.max
    family$AgeOvaryLower[family$AgeOvaryLower < 1] <- 1
  }
  if("AgeOvaryUpper" %in% colnames(family)){
    family$AgeOvaryUpper[family$AgeOvaryUpper > age.max] <- age.max
    family$AgeOvaryUpper[family$AgeOvaryUpper < 1] <- 1
  }
  if("AgeBreastContralateralLower" %in% colnames(family)){
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower > age.max] <- age.max
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower < 1] <- 1
  }
  if("AgeBreastContralateralUpper" %in% colnames(family)){
    family$AgeBreastContralateralUpper[family$AgeBreastContralateralUpper > age.max] <- age.max
    family$AgeBreastContralateralLower[family$AgeBreastContralateralLower < 1] <- 1
  }
  if("AgePancreasLower" %in% colnames(family)){
    family$AgePancreasLower[family$AgePancreasLower > age.max] <- age.max
    family$AgePancreasLower[family$AgePancreasLower < 1] <- 1
  }
  if("AgePancreasUpper" %in% colnames(family)){
    family$AgePancreasUpper[family$AgePancreasUpper > age.max] <- age.max
    family$AgePancreasUpper[family$AgePancreasUpper < 1] <- 1
  }
  
  if(is.character(family)) {return(family)}
  
 # Keep a copy of the family as entered if any twins are input
 if (sum(family$Twins)>0) {
   inputfamily <- family
   if (!is.null(germline.testing)) {
     inputfamily <- data.frame(inputfamily, germline.testing)
   }
   if (!is.null(marker.testing)) {
     inputfamily <- data.frame(inputfamily, marker.testing)
   }
   if (!is.null(oophorectomy)) {
     inputfamily <- data.frame(inputfamily, oophorectomy)
   }
   if (!is.null(mastectomy)) {
     inputfamily <- data.frame(inputfamily, mastectomy)
   }
 }
 
 # if the counselee has an identical twin, make sure the ID used in the calculation is that of the counselee and not his/her twin so peeling does not error out
 originalcounselee.id <- counselee.id
 if (family$Twins[family$ID==counselee.id]>0) {
   twins <- family[family$Twins==family$Twins[family$ID==counselee.id],]
   counselee.id <- twins$ID[1]
 }
 
  
  proband.current.age <- max(family[which(family$ID==counselee.id),c("AgeBreast", "AgeOvary", "AgeBreastContralateral", "AgePancreas")])
  maxages <- apply(family[,c("AgeBreast", "AgeOvary", "AgeBreastContralateral", "AgePancreas")],1,max)
  
  #------------------------#
  # Decide allele frequency
  
  nonAJ <- list(c(1-0.0005829,0.0005829),c(1-0.0006760,0.0006760), c(1-0.002724,0.002724)) # Order is BRCA1, BRCA2, PANC
  AJ <- list(c(1-0.00609756097560976,0.00609756097560976),
             c(1-0.00679723502304147,0.00679723502304147),
             c(1-0.002724,0.002724))
  Italian <- list(c(1-0.001673779,0.001673779),
                  c(1-0.00132622,0.00132622), c(1-0.00207378,0.00207378))
  Other <- params$allef
  
  
  allef <- list()
  if (any(family$ethnic=="AJ" & !is.na(family$ethnic))) allef["AJ"] <- list(AJ)
  if (any(family$ethnic=="nonAJ" & !is.na(family$ethnic))) allef["nonAJ"] <- list(nonAJ)
  if (any(family$ethnic=="Italian" & !is.na(family$ethnic))) allef["Italian"] <- list(Italian)
  if (any(family$ethnic=="Other" & !is.na(family$ethnic))) allef["Other"] <- list(Other)        
  
  #------------------------------------------#
  # Get the race-specific baseline estimates #
 
 ## NEED TO PULL ESTIMATES FOR PANCREAS CANCER AND CREATE NEW BRCAPANCbaseline object.
  
  if (race=="Unknown") {
    params$penetrance <- params$penetrance
  }else{
    if (race=="Asian") {
      params$penetrance$fFX[,"G000"] <- BRCAbaseline.race.2008$fFX[,"Asian"]
      params$penetrance$fFY[,"G000"] <- BRCAbaseline.race.2008$fFY[,"Asian"]
      params$penetrance$fMX[,"G000"] <- BRCAbaseline.race.2008$fMX[,"Asian"]
      params$penetrance$fMY[,"G000"] <- BRCAbaseline.race.2008$fMY[,"Asian"]
    }else{
      if (race=="Black") {
        params$penetrance$fFX[,"G000"] <- BRCAbaseline.race.2008$fFX[,"Black"]
        params$penetrance$fFY[,"G000"] <- BRCAbaseline.race.2008$fFY[,"Black"]
        params$penetrance$fMX[,"G000"] <- BRCAbaseline.race.2008$fMX[,"Black"]
        params$penetrance$fMY[,"G000"] <- BRCAbaseline.race.2008$fMY[,"Black"]
      }else{
        if (race=="Hispanic") {
          params$penetrance$fFX[,"G000"] <- BRCAbaseline.race.2008$fFX[,"Hispanic"]
          params$penetrance$fFY[,"G000"] <- BRCAbaseline.race.2008$fFY[,"Hispanic"]
          params$penetrance$fMX[,"G000"] <- BRCAbaseline.race.2008$fMX[,"Hispanic"]
          params$penetrance$fMY[,"G000"] <- BRCAbaseline.race.2008$fMY[,"Hispanic"]
        }else{
          if (race=="NativeAmerican") {
            params$penetrance$fFX[,"G000"] <- BRCAbaseline.race.2008$fFX[,"NativeAmerican"]
            params$penetrance$fFY[,"G000"] <- BRCAbaseline.race.2008$fFY[,"NativeAmerican"]
            params$penetrance$fMX[,"G000"] <- BRCAbaseline.race.2008$fMX[,"NativeAmerican"]
            params$penetrance$fMY[,"G000"] <- BRCAbaseline.race.2008$fMY[,"NativeAmerican"]
          }else{
            if (race=="White") {
              params$penetrance$fFX[,"G000"] <- BRCAbaseline.race.2008$fFX[,"White"]
              params$penetrance$fFY[,"G000"] <- BRCAbaseline.race.2008$fFY[,"White"]
              params$penetrance$fMX[,"G000"] <- BRCAbaseline.race.2008$fMX[,"White"]
              params$penetrance$fMY[,"G000"] <- BRCAbaseline.race.2008$fMY[,"White"]
            }
          }}}}}
  
   # Get the max ages to use as the censoring times for the competing risk
  maxages <- apply(family[,c("AgeBreast", "AgeOvary", "AgeBreastContralateral", "AgePancreas")],1,max)
   
 # Needed constants
 psize <- dim(family)[1]
 nloci <- 3 # Number of genes: BRCA1 and BRCA2 and PANC
 ngen <- 3^nloci
  
 # Get the sex (0=female, 1=male) to know which penetrance to use
 sex <- family$Gender
 
 # Keep a copy of the family before any intervention age censoring
 currfamily <- family
 if (sum(family$Twins)>0) {currfamily <- inputfamily}
 
 
 ## future risk penetrance depends on whether we want crude or net
 ## Using net only for brcapancpro
 # params$penetrance.net = params$penetrance
#  cbc.net = params$CBCpenetrance
  
  #---------------------------------------------------------#
  # If proband has a 1st breast cancer diagnosis,           #
  # compute personalized contralateral BC penetrance matrix #
  
  femaleproband <- ifelse(family$Gender[family$ID==counselee.id]==0, 1, 0)
  if (family$AffectedBreast[family$ID==counselee.id]>0) { # 1st BC dx
    firstdx.under40 <- ifelse(family$AgeBreast[family$ID==counselee.id]<40, 1, 0)
    agedx <- family$AgeBreast[family$ID==counselee.id]
    
    if (femaleproband==1 & firstdx.under40==1) {
      Breast <- params$CBCpenetrance$fFX.Under40
      Ovarian <- params$penetrance$fFY
      Pancreas = params$penetrance$fFZ
    }
    if (femaleproband==1 & firstdx.under40==0) {
      Breast <- params$CBCpenetrance$fFX.Over40
      Ovarian <- params$penetrance$fFY
      Pancreas = params$penetrance$fFZ
    }
    if (femaleproband==0 & firstdx.under40==1) {
      Breast <- params$CBCpenetrance$fMX.Under40
      Ovarian <- params$penetrance$fMY
      Pancreas = params$penetrance$fFZ
    }
    if (femaleproband==0 & firstdx.under40==0) {
      Breast <- params$CBCpenetrance$fMX.Over40
      Ovarian <- params$penetrance$fMY
      Pancreas = params$penetrance$fFZ
    }
    CBC <- matrix(0, nrow=94, ncol=27)
    for (cccc in 1:ncol(Breast)) {
      CBC[agedx:94,cccc] <- Breast[1:length(agedx:94),cccc]
    }
  }else { # no 1st BC
    if (femaleproband==1) {
      CBC <- params$penetrance$fFX
      Ovarian <- params$penetrance$fFY
      Pancreas = params$penetrance$fFZ
    }
    if (femaleproband==0) {
      CBC <- params$penetrance$fMX
      Ovarian <- params$penetrance$fMY
      Pancreas = params$penetrance$fFZ
    }
  }
  CBRCApenet <- list(CBC, Ovarian, Pancreas)
  names(CBRCApenet) <- c("fX","fY","fZ") # this works as the penetrance matrix for future risk calculations.
  colnames(CBRCApenet$fX) = colnames(CBRCApenet$fY) = 
    colnames(CBRCApenet$fZ) = colnames(params$penetrance$fFX)
  
  #---------------------------------------------------------------------------------#
  # If penetrance matrix doesn't have post-intervention penetrances, put them there #

  if(ncol(params$penetrance$fFX) == 27){ 
    params$penetrance <- MakePenetPostIntervention(params$penetrance,
                                                   params$PostOophorectomyHR,
                                                   params$PostMastectomyHR,
                                                   model="brcapancpro")
  }else{
    if( ncol(params$penetrance$fFX) != 81 ){
      stop("Penetrance matrix must have 27 columns, or 81 if it includes interventions")
    }
  }
  
  # contralateral
  if(ncol(params$CBCpenetrance[[1]]) == 27){ 
    params$CBCpenetrance <- MakePenetPostIntervention(params$CBCpenetrance,
                                                      params$PostOophorectomyHR,
                                                      params$PostMastectomyHR, 
                                                      model="brcapancpro", 
                                                      contralateral=TRUE)
  }else{
    if( ncol(params$CBCpenetrance[[1]]) != 81 ){
      stop("Penetrance matrices for contralateral breast cancer must have 9 columns, or 27 if they include interventions")
    }
  }
     
  runPeeling = function(family, params, ngen,
                        oophorectomy, mastectomy, germline.testing, 
                        marker.testing, psize, counselee.id, allef,
                        maxages,sex,nloci)
  {
    
    #------------------------------------------------------------#
    # Compute post-intervention part of likelihood contributions #
    
    # These people got interventions
    if(is.null(oophorectomy) & is.null(mastectomy)){
      interventions <- family[,"ID"]==0
      oophonly <- mastonly <- mastbeforeooph <- oophbeforemast <- family[,"ID"]==0
    }else{
      if(!is.null(oophorectomy) & !is.null(mastectomy)) {
        interventions <- family$Oophorectomy==1 | family$Mastectomy==1
        mastonly <- family$Mastectomy==1 & family$Oophorectomy==0
        oophonly <- family$Mastectomy==0 & family$Oophorectomy==1
        mastbeforeooph <- family$Oophorectomy==1 & family$Mastectomy==1 & family$AgeMastectomy <= family$AgeOophorectomy
        oophbeforemast <- family$Oophorectomy==1 & family$Mastectomy==1 & family$AgeMastectomy > family$AgeOophorectomy
      }else{
        if(!is.null(oophorectomy) & is.null(mastectomy)) {
          interventions <- family$Oophorectomy==1
          mastonly <- family[,"ID"]==0
          oophonly <- family$Oophorectomy==1
          mastbeforeooph <- family[,"ID"]==0
          oophbeforemast <- family[,"ID"]==0
        }else{
          if(is.null(oophorectomy) & !is.null(mastectomy)) {
            interventions <- family$Mastectomy==1
            mastonly <- family$Mastectomy==1
            oophonly <- family[,"ID"]==0
            mastbeforeooph <- family[,"ID"]==0
            oophbeforemast <- family[,"ID"]==0
          }
        }
      }
    }
    
    if( sum(interventions)>0 ) {
      
      # Subset out those with intervention, note the age of intervention
      # drop=F means do not squeeze out any singleton indices, i.e. don't coerce row
      # matrices to vectors
      # Use inputfamily since family censors post-intervention outcomes
      # Start with those who had oophorectomy only.
      if (sum(oophonly)>0) {
        oophfamily <- family[oophonly,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(oophfamily, 
                                                              whichintervention="Oophorectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="Oophorectomy",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntOophOnlyDIS <- output$DIS
        PostIntOophOnlyAFF <- output$AFF
        PostIntOophOnlyUNA <- output$UNA
      }
      
      # Now those who had mastectomy only.
      if (sum(mastonly)>0) {
        mastfamily <- family[mastonly,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Mastectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="Mastectomy",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntMastOnlyDIS <- output$DIS
        PostIntMastOnlyAFF <- output$AFF
        PostIntMastOnlyUNA <- output$UNA
      }
      
      # Those who had mastectomy first, then oophorectomy
      # Mastectomy doesn't affect ovarian cancer penetrance
      if (sum(mastbeforeooph)>0) {
        mastfamily <- family[mastbeforeooph,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Mastectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="MastectomyFirst",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntMastFirstDIS <- output$DIS
        PostIntMastFirstAFF <- output$AFF
        PostIntMastFirstUNA <- output$UNA
        
        output <- FamilyHistoryContributions(PostIntervention(mastfamily, whichintervention="Oophorectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="Oophorectomy",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntOophAfterDIS <- output$DIS
        PostIntOophAfterAFF <- output$AFF
        PostIntOophAfterUNA <- output$UNA
      }
      
      
      # Those who had oophorectomy first, then mastectomy.
      if (sum(oophbeforemast)>0) {
        oophfamily <- family[oophbeforemast,,drop=FALSE]
        output <- FamilyHistoryContributions(PostIntervention(oophfamily,whichintervention="Oophorectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="OophorectomyFirst",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntOophFirstDIS <- output$DIS
        PostIntOophFirstAFF <- output$AFF
        PostIntOophFirstUNA <- output$UNA
        
        output <- FamilyHistoryContributions(PostIntervention(oophfamily, whichintervention="Mastectomy"),
                                             params$penetrance,ngen=ngen,type="PostIntervention",
                                             whichintervention="Mastectomy",
                                             CBCpenetrance=params$CBCpenetrance,
                                             model = "brcapancpro")
        PostIntMastAfterDIS <- output$DIS
        PostIntMastAfterAFF <- output$AFF
        PostIntMastAfterUNA <- output$UNA
      }
    }
    
    #-----------------------------------------------------------#
    # Compute pre-intervention part of likelihood contributions #
    
    if( sum(interventions)>0 ) {
      # To do pre-intervention parts, remember to censor family to pre-intervention times
      PreInterventionFamily <- CensorAtIntervention(family,interventions)
    } else{
      PreInterventionFamily <- family
    }
    
    output <- FamilyHistoryContributions(PreInterventionFamily,
                                         penetrance=params$penetrance,ngen=ngen,
                                         type="PreIntervention",
                                         CBCpenetrance=params$CBCpenetrance,
                                         model = "brcapancpro")
    DIS <- output$DIS
    AFF <- output$AFF
    UNA <- output$UNA
    
    
    #-------------------------------------------------------------------------#
    # Compute likelihood contribution due to BRCA test and breast tumor tests #
    
    output <- TestContributions(family,psize,ngen=ngen,params$sensitivity1,params$specificity1,
                                params$sensitivity2,params$specificity2,params$marker.prob,params$allef,
                                counselee.id,model='brcapancpro')
    
    TES <- output$TES
    ER <- output$ER 
    ER.CK <- output$ER.CK 
    HER2 <- output$HER2 
    PR <- output$PR
    
    #-----------------------------------------------#
    # Compute each person's likelihood contribution #
    
    # Genotypes are ordered like this: 
    # [1] "G000" "G100" "G200" "G010" "G110" "G210" "G020" "G120" "G220" "G001" "G101"
    # [12] "G201" "G011" "G111" "G211" "G021" "G121" "G221" "G002" "G102" "G202" "G012"
    # [23] "G112" "G212" "G022" "G122" "G222"
    
    # NOTE:  this order cannot be changed - it is dependent on the order of the HW frequencies
    nonhomoz <- c(1,2,4,5,10,11,13,14) # These are the columns of the LIK matrix that are genotypes with non-homozygous possibility.  Match to output from the Gprobs() function.
    brcas = c(1,2,4,5)
    nonbrca = c(10,11,13,14)
    
    LIK <- matrix(0,psize,ngen)
    for (gg in 1:ngen) {
      if (is.element(gg, brcas)) { # heterozygous BRCA genotypes
        #ggcr <- ifelse(gg==1, 1, ifelse(gg==2, 2, ifelse(gg==4, 3,  
        #  ifelse(gg==5, 4, ifelse(gg==10, 5, ifelse(gg==11, 6,
        # ifelse(gg==13, 7, 8)))))))
        ggcr <- ifelse(gg==1, 1, ifelse(gg==2, 2, ifelse(gg==4, 3, 4)))  
        if (is.matrix(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])) {
          LIK[,gg] <- apply( DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg], 1, prod )*
            TES[,gg]*ER[,gg]*ER.CK[,gg]*PR[,gg]*HER2[,gg]*
            diag(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])
        } 
        if (!is.matrix(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)])) {
          LIK[,gg] <- apply( DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg], 1, prod )*
            TES[,gg]*ER[,gg]*ER.CK[,gg]*PR[,gg]*HER2[,gg]*
            diag(params$comprisk[maxages,ggcr*(sex==0)+(ggcr+4)*(sex==1)], nrow = 1)
        } 
      }
      if (is.element(gg, nonbrca)) {
        LIK[,gg] <- apply( DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg], 1, prod )*
          TES[,gg]*ER[,gg]*ER.CK[,gg]*PR[,gg]*HER2[,gg]
      } 
    }
    
    # Need to capture columns that are PANC homozygote only, replace with matching heterozygote penetrance
    panchomo = c(19,20,22,23) # "G002" "G102" "G012""G112"
    panchetero = c(10,11,13,14) # "G001" "G101" "G011" "G111"
    LIK[,panchomo] = LIK[,panchetero]
    
    
    # Include post-intervention contributions only on those who had intervention
    # Separate these out further into the specific interventions, a loop for each type.
    if ( sum(interventions)>0) {
      if ( sum(oophonly)>0 ) {
        for (gg in 1:ngen) {
          LIK[oophonly,gg] <- LIK[oophonly,gg]*apply( PostIntOophOnlyDIS*PostIntOophOnlyAFF[,,gg] + (1-PostIntOophOnlyDIS) * 
                                                        PostIntOophOnlyUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(mastonly)>0 ) {
        for (gg in 1:ngen) {
          LIK[mastonly,gg] <- LIK[mastonly,gg]*apply( PostIntMastOnlyDIS*PostIntMastOnlyAFF[,,gg] + (1-PostIntMastOnlyDIS) *
                                                        PostIntMastOnlyUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(mastbeforeooph)>0 ) {
        for (gg in 1:ngen) {
          LIK[mastbeforeooph,gg] <- LIK[mastbeforeooph,gg]*apply( PostIntMastFirstDIS*PostIntMastFirstAFF[,,gg] + (1-PostIntMastFirstDIS) * 
                                                                    PostIntMastFirstUNA[,,gg], 1, prod)*apply( PostIntOophAfterDIS*PostIntOophAfterAFF[,,gg] + (1-PostIntOophAfterDIS) * 
                                                                                                                 PostIntOophAfterUNA[,,gg], 1, prod)
        }
      }
      
      if ( sum(oophbeforemast)>0 ) {
        for (gg in 1:ngen) {
          LIK[oophbeforemast,gg] <- LIK[oophbeforemast,gg]*apply( PostIntOophFirstDIS*PostIntOophFirstAFF[,,gg] + (1-PostIntOophFirstDIS) * 
                                                                    PostIntOophFirstUNA[,,gg], 1, prod)*apply( PostIntMastAfterDIS*PostIntMastAfterAFF[,,gg] + (1-PostIntMastAfterDIS) * 
                                                                                                                 PostIntMastAfterUNA[,,gg], 1, prod)
        }
      }
      
    }
    
    # If there are twins in the family, collapse them here #
    if (sum(family$Twins)>0) {
      if (length(unique(family$Twins))>=1 & !any(family$Twins==0)) {loopID <- length(unique(family$Twins))}
      if (length(unique(family$Twins))>1 & any(family$Twins==0)) {loopID <- length(unique(family$Twins))-1}
      family$NewMotherIndex = family$NewFatherIndex = 0
      
      # Because we are collapsing twins, need to replace any offspring's mid and fid
      for (iiiii in 1:loopID) {
        temp <- family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],]
        if (temp$Gender[1]==0) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewMotherIndex"] = temp$ID[1]}
        if (temp$Gender[1]==1) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewFatherIndex"] = temp$ID[1]}
      }
      
      twins = family$ID[family$Twins>0]
      offspring = family$ID[is.element(family$MotherID, twins) | is.element(family$FatherID, twins)]
      if (length(offspring)>0) {
        for (ooo in 1:length(offspring)){
          motherIsTwin = family$Twins[family$ID==family$MotherID[family$ID==offspring[ooo]]]
          fatherIsTwin = family$Twins[family$ID==family$FatherID[family$ID==offspring[ooo]]]
          if (length(motherIsTwin)!=0) {
            if (motherIsTwin!=0) {
              family$MotherID[family$ID==offspring[ooo]] = family$NewMotherIndex[family$ID==family$MotherID[family$ID==offspring[ooo]]]}
          }
          if (length(fatherIsTwin)!=0) {
            if (fatherIsTwin!=0) {
              family$FatherID[family$ID==offspring[ooo]] = family$NewFatherIndex[family$ID==family$FatherID[family$ID==offspring[ooo]]]}
          }
        }
      }
      # get the first twin's ped info for peeling
      firsttwin = which(family$Twins>0)
      firsttwin = firsttwin[match(unique(family$Twins[family$Twins!=0]), family$Twins[family$Twins!=0])]
      nottwins = which(family$Twins==0)
      collapsedtwins = sort(c(firsttwin,nottwins)) 
      ped = family[collapsedtwins,c("ID", "Gender", "FatherID", "MotherID","ethnic")]
      # set up new LIK
      newLIK = LIK
      twinIDs = unique(family$Twins[family$Twins!=0])
      for (ttt in 1:length(twinIDs)) {
        twinrows = which(family$Twins==twinIDs[ttt])
        newLIK[twinrows[1],] = LIK[twinrows[1],] * LIK[twinrows[2],]
        newLIK[twinrows[2],] = rep(NA,ngen)
      }
      # Now take out empty rows
      LIK = newLIK[apply(newLIK,1,function(x){return(!any(is.na(x)))}),]
    }
    
    if (sum(family$Twins)==0) {
      ped = family[,c("ID", "Gender", "FatherID", "MotherID","ethnic")]
    }
    
    #-------------------------------------------------# 
    # Compute posterior probability of carrier status #
    # peelingR  (peeling in R)
    #  outputs: numerator of BayesThereom calculation
    #           weight used for likelihood
    #  logp <- peelingR(allef,LIK,ped=family[,c("ID", "Gender", "FatherID", "MotherID","ethnic")],counselee.id=counselee.id,nloci=nloci)
    #  post <- rescale(logp$num)
    #  ll <- log(sum(logp$num))+logp$weight
    #
    # peelingRC (peeling in C)
    #  outputs: posterior probability
    #
    # When moving to peelingRC, decided to leave ll slot but set to NULL
    # dyn.load('peelingC')
    post <- peelingRC(allef=allef,LIK,ped=ped,counselee.id=counselee.id,nloci=nloci)
    
    return(post)
    
  }
  
  
  ## --------------
  ## Calculation for LIK start here.  This is where we start the multiple age imputation process ---------------###
  
  missingage = any(family$AgeBreast==1 | family$AgeOvary==1 | 
                     (family$AgeBreastContralateral==1 & family$AffectedBreast==2) | family$AgePancreas==1)
  
  if (missingage & imputeAges==FALSE) {
    agewarning = "Warning: Age imputation has been turned off, but there are unknown ages of some unaffected family members. You may want to get more information about family member ages and re-run the calculation, or set imputeAges=TRUE."
    post = runPeeling(family=family, 
                      params=params, ngen=ngen,
                      oophorectomy=oophorectomy, mastectomy=mastectomy, 
                      germline.testing=germline.testing,
                      marker.testing=marker.testing, psize=psize, 
                      counselee.id=counselee.id, allef=allef,maxages=maxages,sex=sex,nloci=nloci)
  }
  
  if (missingage & imputeAges==TRUE){
    agewarning = "Warning: Unknown ages of some unaffected and affected family members have been imputed.  You may want to get more information about family member ages and re-run the calculation."
    ifamily = ImputeAge(fff=family, params=params, model='brcapancpro', net=TRUE, bounds = bounds)
    postList = NULL
    nIter = params$nIter
    
    # Run each imputed age through runPeeling if there are affected relatives
    # who had age imputed
    if (length(ifamily$mem_bc)>0 | length(ifamily$mem_oc)>0 | length(ifamily$mem_pc)>0 |
        length(ifamily$mem_bcc)>0 | length(ifamily$mem_mast)>0 | 
        length(ifamily$mem_ooph)>0 | length(ifamily$mem_bc_oc)>0 |
        length(ifamily$mem_bc_pc)>0 | length(ifamily$mem_pc_oc)>0 |
        length(ifamily$mem_bc_oc_pc)>0) {
      for (iIter in 1:nIter){
        # creating imputed fff
        nf = ifamily$fff
        noophorectomy = oophorectomy
        nmastectomy = mastectomy
        
        if (length(ifamily$mem_bc)>0) {
          nf$AgeBreast[ifamily$mem_bc] = ifamily$age_bc[iIter,ifamily$mem_bc]  
        }
        
        if (length(ifamily$mem_oc)>0) {
          nf$AgeOvary[ifamily$mem_oc]<-ifamily$age_oc[iIter,ifamily$mem_oc]	
        }
        
        if (length(ifamily$mem_pc)>0) {
          nf$AgePancreas[ifamily$mem_pc]<-ifamily$age_pc[iIter,ifamily$mem_pc]	
        }
        
        if (length(ifamily$mem_bc_pc)>0) {
          nf$AgePancreas[ifamily$mem_bc_pc]<-ifamily$age_pc[iIter,ifamily$mem_bc_pc]	
          nf$AgeBreast[ifamily$mem_bc_pc]<-ifamily$age_bc[iIter,ifamily$mem_bc_pc]	
        }
        
        if (length(ifamily$mem_bc_oc)>0) {
          nf$AgeOvary[ifamily$mem_bc_oc]<-ifamily$age_oc[iIter,ifamily$mem_bc_oc]	
          nf$AgeBreast[ifamily$mem_bc_oc]<-ifamily$age_bc[iIter,ifamily$mem_bc_oc]	
        }
        
        if (length(ifamily$mem_pc_oc)>0) {
          nf$AgePancreas[ifamily$mem_pc_oc]<-ifamily$age_pc[iIter,ifamily$mem_pc_oc]	
          nf$AgeOvary[ifamily$mem_pc_oc]<-ifamily$age_oc[iIter,ifamily$mem_pc_oc]	
        }
        
        if (length(ifamily$mem_bc_oc_pc)>0) {
          nf$AgePancreas[ifamily$mem_bc_oc_pc]<-ifamily$age_pc[iIter,ifamily$mem_bc_oc_pc]	
          nf$AgeOvary[ifamily$mem_bc_oc_pc]<-ifamily$age_oc[iIter,ifamily$mem_bc_oc_pc]	
          nf$AgeBreast[ifamily$mem_bc_oc_pc]<-ifamily$age_bc[iIter,ifamily$mem_bc_oc_pc]	
        }
        
        if (length(ifamily$mem_bcc)>0) {
          nf$AgeBreastContralateral[ifamily$mem_bcc]<-ifamily$age_bcc[iIter,ifamily$mem_bcc]	
        }
        
        if (length(ifamily$mem_mast)>0){
          nf$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
          nmastectomy$AgeMastectomy[ifamily$mem_mast] = ifamily$age_mast[iIter,ifamily$mem_mast]
        }
        
        if (length(ifamily$mem_ooph)>0) {
          nf$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
          noophorectomy$AgeOophorectomy[ifamily$mem_ooph] = ifamily$age_ooph[iIter,ifamily$mem_ooph]
        }
        
        #print(iIter)
        postList = rbind(postList,
                         runPeeling(family=nf,  
                                    params=params, ngen=ngen,
                                    oophorectomy=noophorectomy, mastectomy=nmastectomy, 
                                    germline.testing=germline.testing,
                                    marker.testing=marker.testing, psize=psize, 
                                    counselee.id=counselee.id, allef=allef,maxages=maxages,sex=sex,nloci=nloci)
        )
      }
      
      post = apply(postList, 2, mean)
    }
    
    if (length(ifamily$mem_bc)==0 & length(ifamily$mem_oc)==0 & 
        length(ifamily$mem_pc)==0 &
        length(ifamily$mem_bcc)==0 & length(ifamily$mem_mast)==0 & 
        length(ifamily$mem_ooph)==0 & length(ifamily$mem_bc_oc)==0 &
        length(ifamily$mem_bc_pc)==0 & length(ifamily$mem_pc_oc)==0 &
        length(ifamily$mem_bc_oc_pc)==0) {
      post = runPeeling(family=ifamily$fff, 
                        params=params, ngen=ngen,
                        oophorectomy=oophorectomy, mastectomy=mastectomy, 
                        germline.testing=germline.testing,
                        marker.testing=marker.testing, psize=psize, 
                        counselee.id=counselee.id, allef=allef,maxages=maxages,sex=sex,nloci=nloci)
    }
    
  }
  
  if (!missingage) { 
    # No missing ages, run peeling once with observed input data.
    agewarning=""
    post = runPeeling(family=family, 
                      params=params, ngen=ngen,
                      oophorectomy=oophorectomy, mastectomy=mastectomy, 
                      germline.testing=germline.testing,
                      marker.testing=marker.testing, psize=psize, 
                      counselee.id=counselee.id, allef=allef,maxages=maxages,sex=sex,nloci=nloci)
    
  }
  
  # save family object to be output
  if (!missingage | imputeAges==FALSE) {family= family}
  if (missingage & imputeAges==TRUE) { family = ifamily$fff}
  
  ####
  
  ll <- NULL

  post <- array(post, rep(3,3,3))
 
   dn <- list(0)
   dn[[1]] <- c("BRCA10","BRCA11","BRCA12")
   dn[[2]] <- c("BRCA20","BRCA21","BRCA22")
   dn[[3]] <- c("PANC0", "PANC1", "PANC2")
   dimnames(post) <- dn

  ages.cancer <- c(family[which(family$ID==counselee.id),"AgeBreast"],family[which(family$ID==counselee.id),"AgeOvary"],
                   family[which(family$ID==counselee.id),"AgeBreastContralateral"], family[which(family$ID==counselee.id),"AgePancreas"])
  
  current.age <- max(ages.cancer)
  params$age.by = ifelse(current.age>=90, 1, params$age.by)
  ages <- seq(current.age+params$age.by, ifelse(params$age.to>=current.age+params$age.by, params$age.to, 94), 
              by=ifelse(current.age>=90, 1, params$age.by))
 

  #------------------------------------------------------#
  # Calculate the probabilities for the 8 main genotypes #

  p000 <- post[1,1,1] 
  p001 <- sum(post[1,1,2:3])
  p010 <- sum(post[1,2:3,1])
  p011 <- sum(post[1,2:3,2:3])
  p100 <- sum(post[2:3,1,1])
  p101 <- sum(post[2:3,1,2:3])
  p110 <- sum(post[2:3,2:3,1])
  p111 <- sum(post[2:3,2:3,2:3])

  if (print) {
  cat("The probability of being a carrier is", 1-p000, "\n BRCA1 carrier is",p100,"\n BRCA2 carrier is",p010,"\n PANC carrier", p001,"\n")
  }
  
  probs <- data.frame(1-p000, p100, p010, p001, p101, p110, p011, p111)
  names(probs) <- c("Pr(Being a carrier)", "Pr(BRCA1 mutation)", "Pr(BRCA2 mutation)", 
                    "Pr(PANC mutation)", "Pr(BRCA1 and PANC mutation)", "Pr(BRCA1 and BRCA2 mutation)", 
                    "Pr(BRCA2 and PANC mutation)", "Pr(All three genes mutated)")
  
  if(any(c(p000, p100, p010, p001, p101, p110, p011, p111) == 0) & !is.null(germline.testing) &
     any(c(params$sensitivity1, params$specificity1, params$sensitivity2, params$specificity2) == 1)){
    warning("Some of the estimated probabilities are 0 or 1, most likely due to the
            incorporation of reported germline testing results (by default, we assume
            that the sensitivity and specificity for all germline tests is 1).
            However, this does not guarantee that the person is a noncarrier or
            mutation carrier; a more accurate estimate may be achieved with
            user-specified sensitivities and specificities.")
  }

  if(pro.agemax == 1){
    predictions <- future.risk <- data.frame()
    warning(paste("Proband is older than ", age.max - 1, ". Future risk prediction is not calculated.", sep = ""))
  } else{
    
  predictions <- NULL
  ages.by1 <- (proband.current.age+1):max(ages)
  future.risk.penet <- CBRCApenet
  
  if(currfamily[which(currfamily$ID==originalcounselee.id),"Gender"]==0){#female
    
    if(!is.null(oophorectomy)) prob.ooph = oophorectomy$Oophorectomy[currfamily$ID==originalcounselee.id] else prob.ooph = 0
    if(!is.null(mastectomy))   prob.mast = mastectomy$Mastectomy[currfamily$ID==originalcounselee.id]     else prob.mast = 0
    
    if(prob.ooph==1 | prob.mast==1) {
      # Values depend on intervention done
      if (prob.ooph==1 & prob.mast==0) { # proband had ooph only
        HR.breast <- params$PostOophorectomyHR$femaleBreast
        HR.ovary = params$PostOophorectomyHR$femaleOvary
      }
      if (prob.ooph==0 & prob.mast==1) { # proband had mastectomy only
        HR.breast <- params$PostMastectomyHR
        HR.ovary = rep(1, length(HR.breast))
      }
      if (prob.ooph==1 & prob.mast==1) { # proband had both mast and ooph, use mast for BC and ooph for OC
        HR.breast <- params$PostMastectomyHR
        HR.ovary = params$PostOophorectomyHR$femaleOvary
      }
    }
      if (prob.ooph==1 & prob.mast==0) { # Apply benefit of ooph to all ages for ovarian cancer risk, ages 1-59 for br ca risk
        future.risk.penet$fX[1:44,] <- future.risk.penet$fX[1:44,]*HR.breast
        future.risk.penet$fY[1:94,] <- future.risk.penet$fY[1:94,'G000']*HR.ovary
      }
      if ((prob.ooph==1 & prob.mast==1) | (prob.ooph==0 & prob.mast==1)) {
        # benefit of mastectomy for future BrCa overrules ooph here
        future.risk.penet$fX[1:94,'G000'] <- future.risk.penet$fX[1:94,'G000']*HR.breast
        future.risk.penet$fY[1:94,'G000'] <- future.risk.penet$fY[1:94,'G000']*HR.ovary
      }
    
    hFX0 <- hFX1 <- hFX2 <- hFX3 <- hFX12 <- hFX13 <- hFX23 <- hFX123 <- rep (0,max(ages))
    hFY0 <- hFY1 <- hFY2 <- hFY3 <- hFY12 <- hFY13 <- hFY23 <- hFY123 <- rep (0,max(ages))
    hFZ0 <- hFZ1 <- hFZ2 <- hFZ3 <- hFZ12 <- hFZ13 <- hFZ23 <- hFZ123 <- rep (0,max(ages))
    future.risk <- data.frame(hFX1,hFX2,hFY1,hFY2,hFX0,hFX12,hFY0,hFY12,hFX3,hFX13,hFX23,hFX123,
                              hFY3,hFY13,hFY23,hFY123,hFZ3,hFZ13,hFZ23,hFZ123)
    
    future.risk$hFX0[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G000'],death.othercauses$femaleBC)[ages.by1],
                                                   death.othercauses$femaleBC[ages.by1])
    future.risk$hFY0[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G000'],death.othercauses$ovary)[ages.by1],
                                                   death.othercauses$ovary[ages.by1])
    future.risk$hFZ0[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G000'],death.othercauses$femalePanc)[ages.by1],
                                                   death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX1[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G100'],death.othercauses$femaleBC)[ages.by1],
                                                   death.othercauses$femaleBC[ages.by1])
    future.risk$hFY1[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G100'],death.othercauses$ovary)[ages.by1],
                                                   death.othercauses$ovary[ages.by1])
    future.risk$hFZ1[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G100'],death.othercauses$femalePanc)[ages.by1],
                                                   death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX2[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G010'],death.othercauses$femaleBC)[ages.by1],
                                                   death.othercauses$femaleBC[ages.by1])
    future.risk$hFY2[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G010'],death.othercauses$ovary)[ages.by1],
                                                   death.othercauses$ovary[ages.by1])
    future.risk$hFZ2[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G010'],death.othercauses$femalePanc)[ages.by1],
                                                   death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX3[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G001'],death.othercauses$femaleBC)[ages.by1],
                                                   death.othercauses$femaleBC[ages.by1])
    future.risk$hFY3[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G001'],death.othercauses$ovary)[ages.by1],
                                                   death.othercauses$ovary[ages.by1])
    future.risk$hFZ3[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G001'],death.othercauses$femalePanc)[ages.by1],
                                                   death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX12[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G110'],death.othercauses$femaleBC)[ages.by1],
                                                    death.othercauses$femaleBC[ages.by1])
    future.risk$hFY12[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G110'],death.othercauses$ovary)[ages.by1],
                                                    death.othercauses$ovary[ages.by1])
    future.risk$hFZ12[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G110'],death.othercauses$femalePanc)[ages.by1],
                                                    death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX13[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G101'],death.othercauses$femaleBC)[ages.by1],
                                                    death.othercauses$femaleBC[ages.by1])
    future.risk$hFY13[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G101'],death.othercauses$ovary)[ages.by1],
                                                    death.othercauses$ovary[ages.by1])
    future.risk$hFZ13[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G101'],death.othercauses$femalePanc)[ages.by1],
                                                    death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX23[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G011'],death.othercauses$femaleBC)[ages.by1],
                                                    death.othercauses$femaleBC[ages.by1])
    future.risk$hFY23[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G011'],death.othercauses$ovary)[ages.by1],
                                                    death.othercauses$ovary[ages.by1])
    future.risk$hFZ23[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G011'],death.othercauses$femalePanc)[ages.by1],
                                                    death.othercauses$femalePanc[ages.by1])
    
    future.risk$hFX123[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G111'],death.othercauses$femaleBC)[ages.by1],
                                                     death.othercauses$femaleBC[ages.by1])
    future.risk$hFY123[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fY[,'G111'],death.othercauses$ovary)[ages.by1],
                                                     death.othercauses$ovary[ages.by1])
    future.risk$hFZ123[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G111'],death.othercauses$femalePanc)[ages.by1],
                                                     death.othercauses$femalePanc[ages.by1])
    
     
    X.risk <- future.risk$hFX1[ages]*p100+future.risk$hFX13[ages]*p101 + future.risk$hFX2[ages]*p010+future.risk$hFX23[ages]*p011 +
      future.risk$hFX0[ages]*p000+future.risk$hFX3[ages]*p001 + future.risk$hFX12[ages]*p110+future.risk$hFX123[ages]*p111
    
    Y.risk <- future.risk$hFY1[ages]*p100+future.risk$hFY13[ages]*p101 + future.risk$hFY2[ages]*p010+future.risk$hFY23[ages]*p011 + 
      future.risk$hFY0[ages]*p000+future.risk$hFY3[ages]*p001 + future.risk$hFY12[ages]*p110+future.risk$hFY123[ages]*p111
    
    Z.risk <- future.risk$hFZ2[ages]*p100+future.risk$hFZ12[ages]*p110 + future.risk$hFZ3[ages]*p001+future.risk$hFZ13[ages]*p101 + 
      future.risk$hFZ0[ages]*p000+future.risk$hFZ1[ages]*p100 + future.risk$hFZ23[ages]*p011+future.risk$hFZ123[ages]*p111 
    
    if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==2) {X.risk <- rep(NA, length(ages))}
    if (currfamily$AffectedOvary[which(currfamily$ID==originalcounselee.id)]==1) {Y.risk <- rep(NA, length(ages))}
    if (currfamily$AffectedPancreas[which(currfamily$ID==originalcounselee.id)]==1) {Z.risk <- rep(NA, length(ages))}
    
    
  }else{#male
    hMX0 <- hMX1 <- hMX2 <- hMX3 <- hMX12 <- hMX13 <- hMX23 <- hMX123 <- rep (0,max(ages))
    hMY0 <- hMY1 <- hMY2 <- hMY3 <- hMY12 <- hMY13 <- hMY23 <- hMY123 <- rep (0,max(ages))
    hMZ0 <- hMZ1 <- hMZ2 <- hMZ3 <- hMZ12 <- hMZ13 <- hMZ23 <- hMZ123 <- rep (0,max(ages))
    future.risk <- data.frame(hMX1,hMX2,hMY1,hMY2,hMX0,hMX12,hMY0,hMY12,hMX3,hMX13,hMX23,hMX123,hMY3,hMY13,hMY23,hMY123,hMZ3,hMZ13,hMZ23,hMZ123)
    
    future.risk$hMX0[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G000'],death.othercauses$maleBC)[ages.by1],
                                                   death.othercauses$maleBC[ages.by1])
    future.risk$hMZ0[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G000'],death.othercauses$malePanc)[ages.by1],
                                                   death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX1[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G100'],death.othercauses$maleBC)[ages.by1],
                                                   death.othercauses$maleBC[ages.by1])
    future.risk$hMZ1[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G100'],death.othercauses$malePanc)[ages.by1],
                                                   death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX2[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G010'],death.othercauses$maleBC)[ages.by1],
                                                   death.othercauses$maleBC[ages.by1])
    future.risk$hMZ2[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G010'],death.othercauses$malePanc)[ages.by1],
                                                   death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX3[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G001'],death.othercauses$maleBC)[ages.by1],
                                                   death.othercauses$maleBC[ages.by1])
    future.risk$hMZ3[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G001'],death.othercauses$malePanc)[ages.by1],
                                                   death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX12[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G110'],death.othercauses$maleBC)[ages.by1],
                                                    death.othercauses$maleBC[ages.by1])
    future.risk$hMZ12[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G110'],death.othercauses$malePanc)[ages.by1],
                                                    death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX13[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G101'],death.othercauses$maleBC)[ages.by1],
                                                    death.othercauses$maleBC[ages.by1])
    future.risk$hMZ13[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G101'],death.othercauses$malePanc)[ages.by1],
                                                    death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX23[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G011'],death.othercauses$maleBC)[ages.by1],
                                                    death.othercauses$maleBC[ages.by1])
    future.risk$hMZ23[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G011'],death.othercauses$malePanc)[ages.by1],
                                                    death.othercauses$malePanc[ages.by1])
    
    future.risk$hMX123[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fX[,'G111'],death.othercauses$maleBC)[ages.by1],
                                                     death.othercauses$maleBC[ages.by1])
    future.risk$hMZ123[ages.by1] <- calc.future.risk(dens2haz.cs(future.risk.penet$fZ[,'G111'],death.othercauses$malePanc)[ages.by1],
                                                     death.othercauses$malePanc[ages.by1])

      
    X.risk <- future.risk$hMX1[ages]*p100+future.risk$hMX13[ages]*p101 + future.risk$hMX2[ages]*p010+future.risk$hMX23[ages]*p011 +
      future.risk$hMX0[ages]*p000+future.risk$hMX3[ages]*p001 + future.risk$hMX12[ages]*p110+future.risk$hMX123[ages]*p111
    Y.risk <-  rep(0, length(ages))
    Z.risk <- future.risk$hMZ2[ages]*p010+future.risk$hMZ12[ages]*p110 + future.risk$hMZ3[ages]*p001+future.risk$hMZ13[ages]*p101 + 
      future.risk$hMZ0[ages]*p000+future.risk$hMZ1[ages]*p100 + future.risk$hMZ23[ages]*p011+future.risk$hMZ123[ages]*p111
    
    if (currfamily$AffectedBreast[which(currfamily$ID==originalcounselee.id)]==2) {X.risk <- rep(NA, length(ages))}
    if (currfamily$AffectedPancreas[which(currfamily$ID==originalcounselee.id)]==1) {Z.risk <- rep(NA, length(ages))}
    
  }
  
  
  ####
  
  predictions <- data.frame(ages, breast.risk=X.risk, ovarian.risk=Y.risk, pancreas.risk=Z.risk)
  colnames(predictions) <- c("By age", "Breast Ca Risk", "Ovarian Ca Risk","Pancreas Ca Risk")
  
  if(predict){
    cat("The risks of developing cancers are\n")   
    print(predictions)
  }
  
  }
  
  return(new(Class="BayesMendel", family=family, posterior=post, probs=probs, predictions=predictions))
  
  
}
