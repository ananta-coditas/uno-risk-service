# Output from 'brcapro' and 'MMRpro' - family matrix and probabilities - used to plot pedigree structure
# using generic function 'plot'


plot.BayesMendel <- function(x, ...) {

	family <- slot(x, "family")
	posterior <- slot(x, "posterior")
	probs <- slot(x, "probs")
	counselee.id <- slot(x, "counselee.id")
	predictions <- slot(x, "predictions")

	if (is.null(family$Death)) {status=rep(0, nrow(family))}
	if (!is.null(family$Death)) {status=family$Death}	
	
	## Checking to see which cancer to plot
	## -If the object is the output of a *.pro function, then we can use the predictions slot.
	## -If the object is manually created without a predictions slot, we can look at the
	## columns of the family data frame to see which cancers are included. If multiple cancers
	## are included, first choose breast, then colon, then pancreatic, then melanoma.
	if(length(names(predictions)) > 0){
	  if(names(predictions)[2] %in% c("Breast Ca Risk", "Contralateral Breast Ca Risk")){
	    canc <- "breast"
	  } else if(names(predictions)[2] == "Colorectal Ca Risk"){
	    canc <- "colon"
	  } else if(names(predictions)[2] == "Pancreatic Ca Risk"){
	    canc <- "panc"
	  } else if(names(predictions)[2] == "Melanoma Risk"){
	    canc <- "mela"
	  }
	} else{
	  if(!is.null(family$AffectedBreast)){
	    canc <- "breast"
	  } else if(!is.null(family$AffectedColon)){
	    canc <- "colon"
	  } else if(!is.null(family$AffectedPancreas)){
	    canc <- "panc"
	  } else if(!is.null(family$AffectedSkin)){
	    canc <- "mela"
	  }
	}
	
	id <- family$ID
	dadid <- family$FatherID
	momid <- family$MotherID
	sex <- family$Gender
	sex[sex==0] <- 2

	refs <- 1:length(id)
	get1 <- refs[dadid==0 & momid > 0]
	get2 <- refs[dadid > 0 & momid==0]
	rem <- sort(c(get1, get2))

	num <- length(unique(momid[get1])) + length(unique(dadid[get2]))
	
	if (num > 0) {

	newid <- max(id)+(1:num)
	newid1 <- newid[1:length(unique(momid[get1]))]
	newid2 <- newid[(length(unique(momid[get1]))+1):(length(newid))]

	id <- c(id, newid)
	sex <- c(sex, rep(1, length(unique(momid[get1]))), rep(2, length(unique(dadid[get2]))))

	dadid <- c(dadid, rep(0, num))
	momid <- c(momid, rep(0, num))	
	
	if (length(get1) > 0) {
		for (i in 1:length(get1)) {
			dadid[id==id[get1[i]]] <- newid1[unique(momid[get1])==momid[get1[i]]]
		}
	}

	if (length(get2) > 0) {
		for (i in 1:length(get2)) {
			momid[id==id[get2[i]]] <- newid2[unique(dadid[get2])==dadid[get2[i]]]
		}
	}

	}

	if (canc == "colon"){
		affected <- cbind(family$AffectedColon, family$AffectedEndometrium)
		affected <- affected + 1
		affected[affected == 3] <- 2

		ages.cc <- c(family$AgeColon, rep(1, num))
		ages.ec <- c(family$AgeEndometrium, rep(1, num))
		cc <- family$AffectedColon
		ec <- family$AffectedEndometrium
		
	}

	if (canc == "breast"){
		bc2 <- family$AffectedBreast
		bc2[bc2<=1] <- 1
		affected <- cbind(family$AffectedBreast, family$AffectedOvary)
		affected <- affected + 1
		affected[affected == 3] <- 2

		ages.bc1 <- c(family$AgeBreast, rep(1, num))
		ages.oc <- c(family$AgeOvary, rep(1, num))
		ages.bc2 <- c(family$AgeBreastContralateral, rep(1, num))
		bc <- family$AffectedBreast
		oc <- family$AffectedOvary
	}

	if (canc == "panc"){
		affected <- cbind(family$AffectedPancreas)
		affected <- affected + 1
		affected[affected == 3] <- 2

		ages.pc <- c(family$AgePancreas, rep(1, num))
		pc <- family$AffectedPancreas
	}
	
	if (canc == "mela"){
	  affected <- cbind(family$AffectedSkin)
	  affected <- affected + 1
	  affected[affected == 3] <- 2
	  
	  ages.m <- c(family$AgeSkin, rep(1, num))
	  mela <- family$AffectedSkin
	}

	if (canc %in% c("breast", "colon")) affected <- rbind(affected, matrix(1, nrow=num, ncol=2))
	if (canc %in% c("panc", "mela")) affected <- c(affected, rep(1, num))
	status <- c(status, rep(0, num))
        relations <- NULL
        
        if (!is.null(family$Twins) & sum(family$Twins)>0) {
          # howmanytwins <- max(family$Twins)
          twin.ids <- unique(family$Twins[family$Twins > 0])
          id1 <- id2 <- code <- NULL
          for (ttt in 1:length(twin.ids)) {
            id1 <- c(id1,family$ID[family$Twins==unique(twin.ids)[ttt]][1])
            id2 <- c(id2,family$ID[family$Twins==unique(twin.ids)[ttt]][2])
            code <- c(code, 1)
          }
          relations <- matrix(c(id1,id2,code),byrow=F,ncol=3)
          ped.y <- kinship2::pedigree(id, dadid, momid, sex, affected, status, relation=relations)
        }

        if ((!is.null(family$Twins) & sum(family$Twins)==0) | is.null(family$Twins)) {
           ped.y <- kinship2::pedigree(id, dadid, momid, sex, affected, status)
        }
        	
	par(xpd=TRUE)
	plt <- kinship2::plot.pedigree(ped.y, id=rep("",length(ped.y$id)), align=FALSE)
	xp <- plt$x
	yp <- plt$y
	
	inc <- (abs(min(yp)) - abs(max(yp)))/12
	xp.inc <- (abs(min(xp)) - abs(max(xp)))/50

	couns <- counselee.id
	xp.couns <- xp[id==couns]
	yp.couns <- yp[id==couns]
	arrows(xp.couns-.35, yp.couns-.15, xp.couns-0.1, yp.couns-0.1, length=0.1)
	#points(xp.couns, yp.couns, cex=5)

	if (dim(posterior)[1] > 0) {
			
		if (canc == "colon") {

		marg <- rep(0,3)
 		marg[1] <- 1-sum(posterior[1,,])
 		marg[2] <- 1-sum(posterior[,1,])
  		marg[3] <- 1-sum(posterior[,,1])

		mtext(paste("Noncarrier probability =", round(posterior[1,1,1], digits=3)), at = 0.05*max(xp), line=2.5, cex=0.65, adj=0)
		mtext(paste("MLH1 carrier probability =", round(marg[1], digits=3)), at = 0.625*max(xp), line=2.5, cex=0.65, adj=0)
		mtext(paste("MSH2 carrier probability =", round(marg[2], digits=3)), at = 0.05*max(xp), line=1, cex=0.65, adj=0)
		mtext(paste("MSH6 carrier probability =", round(marg[3], digits=3)), at = 0.625*max(xp), line=1, cex=0.65, adj=0)
	
		}
	
		if (canc == "breast"){


		mtext(paste("Noncarrier probability =", round(posterior[1,1,1], digits=3)), at = 0.05*max(xp), line=2.5, cex=0.65, adj=0)
		mtext(paste("BRCA2 carrier probability =", round(posterior[1,2,1], digits=3)), at = 0.625*max(xp), line=2.5, cex=0.65, adj=0)
		mtext(paste("BRCA1 carrier probability =", round(posterior[2,1,1], digits=3)), at = 0.05*max(xp), line=1, cex=0.65, adj=0)
		mtext(paste("BRCA1 & BRCA2 carrier probability =", round(posterior[2,2,1], digits=3)), at = 0.625*max(xp), line=1, cex=0.65, adj=0)
	
		}

		
		if (canc == "panc") {

		mtext(paste("Carrier probability =", round(probs[1], digits=3)), at = 0.05*max(xp), line=2.5, cex=0.65, adj=0)
		#mtext(paste("MLH1 carrier probability =", round(marg[1], digits=3)), at = 0.625*max(xp), line=2.5, cex=0.65, adj=0)
		#mtext(paste("MSH2 carrier probability =", round(marg[2], digits=3)), at = 0.05*max(xp), line=1, cex=0.65, adj=0)
		#mtext(paste("MSH6 carrier probability =", round(marg[3], digits=3)), at = 0.625*max(xp), line=1, cex=0.65, adj=0)
	
		}
	  
	  if (canc == "mela") {
	    
	    mtext(paste("Carrier probability =", round(probs[1], digits=3)), at = 0.05*max(xp), line=2.5, cex=0.65, adj=0)
	    #mtext(paste("MLH1 carrier probability =", round(marg[1], digits=3)), at = 0.625*max(xp), line=2.5, cex=0.65, adj=0)
	    #mtext(paste("MSH2 carrier probability =", round(marg[2], digits=3)), at = 0.05*max(xp), line=1, cex=0.65, adj=0)
	    #mtext(paste("MSH6 carrier probability =", round(marg[3], digits=3)), at = 0.625*max(xp), line=1, cex=0.65, adj=0)
	    
	  }

	}
   
	if (canc == "breast"){

	# Plot ages of non-cancer individuals #
	xph <- xp[bc == 0 & oc == 0]
	yph <- yp[bc == 0 & oc == 0]
	ageh <- ages.bc1[bc == 0 & oc == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of breast cancer individuals #
	xph <- xp[bc >= 1]
	yph <- yp[bc >= 1]
	ageh <- ages.bc1[bc >= 1]
	ageh <- ageh[ageh > 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("BC (1) ", as.character(ageh)), cex = 0.75,
	                            col = "red", font = 2)}
	
	# Plot ages of contralateral breast cancer individuals #
	xph <- xp[bc == 2]
	yph <- yp[bc == 2]
	ageh <- ages.bc2[bc == 2]
	ageh <- ageh[ageh > 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("BC (2) ", as.character(ageh)), cex = 0.75,
	                            col = "red", font = 2)}

	# Plot ages of ovarian cancer individuals #

		# Plot OC who do not have BC #
	
		xph <- xp[oc > 0 & bc == 0]
		yph <- yp[oc > 0& bc == 0]
		ageh <- ages.oc[oc > 0 & bc == 0]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("OC ", as.character(ageh)), cex = 0.75,
		                            col = "red", font = 2)}
	
		# Plot OC who do have BC but not BC contralateral #
		
		xph <- xp[oc > 0 & bc == 1]
		yph <- yp[oc > 0& bc == 1]
		ageh <- ages.oc[oc > 0 & bc == 1]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("OC ", as.character(ageh)), cex = 0.75,
		                            col = "red", font = 2)}
		
		# Plot OC who do have BC and BC contralateral #
		
		xph <- xp[oc > 0 & bc == 2]
		yph <- yp[oc > 0& bc == 2]
		ageh <- ages.oc[oc > 0 & bc == 2]
		xph <- xph[ageh > 1]
		ageh <- ageh[ageh > 0]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]

		if (length(ageh) > 0) {text(x = xph, y = yph - 2*inc, paste("OC ", as.character(ageh)), cex = 0.75,
		                            col = "red", font = 2)}

	}

	if (canc == "colon"){

	
	# Plot ages of non-cancer individuals #
	xph <- xp[cc == 0 & ec == 0]
	yph <- yp[cc == 0 & ec == 0]
	ageh <- ages.cc[cc == 0 & ec == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of colon cancer individuals #
	xph <- xp[cc > 0]
	yph <- yp[cc > 0]
	ageh <- ages.cc[cc > 0]
	ageh <- ageh[ageh > 0]
	yph <- yph[ageh > 1]
	xph <- xph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("CC ", as.character(ageh)), cex = 0.75,
	                            col = "red", font = 2)}

	# Plot ages of endometrium cancer individuals #
		
		# Plot ec cases who also have CC #
		xph <- xp[ec > 0 & cc > 0]
		yph <- yp[ec > 0 & cc > 0]
		ageh <- ages.ec[ec > 0 & cc > 0]
		ageh <- ageh[ageh > 0]
		xph <- xph[ageh > 1]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]
		if (length(ageh) > 0) {text(x = xph, y = yph - 1.5*inc, paste("EC ", as.character(ageh)), cex = 0.75)}

		# Plot ec cases who do not have cc #
		xph <- xp[ec > 0 & cc == 0]
		yph <- yp[ec > 0 & cc == 0]
		ageh <- ages.ec[ec > 0 & cc == 0]
		ageh <- ageh[ageh > 0]
		xph <- xph[ageh > 1]
		yph <- yph[ageh > 1]
		ageh <- ageh[ageh > 1]
		if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("EC ", as.character(ageh)), cex = 0.75,
		                            col = "red", font = 2)}

	}


	if (canc == "panc"){
	
	# Plot ages of non-cancer individuals #
	xph <- xp[pc == 0]
	yph <- yp[pc == 0]
	ageh <- ages.pc[pc == 0]
	xph <- xph[ageh > 1]
	yph <- yph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}

	# Plot ages of pancreas cancer individuals #
	xph <- xp[pc > 0]
	yph <- yp[pc > 0]
	ageh <- ages.pc[pc > 0]
	ageh <- ageh[ageh > 0]
	yph <- yph[ageh > 1]
	xph <- xph[ageh > 1]
	ageh <- ageh[ageh > 1]
	if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("PC ", as.character(ageh)), cex = 0.75,
	                            col = "red", font = 2)}

	}

	if (canc == "mela"){
	  
	  # Plot ages of non-cancer individuals #
	  xph <- xp[mela == 0]
	  yph <- yp[mela == 0]
	  ageh <- ages.m[mela == 0]
	  xph <- xph[ageh > 1]
	  yph <- yph[ageh > 1]
	  ageh <- ageh[ageh > 1]
	  if (length(ageh) > 0) {text(x = xph, y = yph - inc, as.character(ageh), cex = 0.75)}
	  
	  # Plot ages of pancreas cancer individuals #
	  xph <- xp[mela > 0]
	  yph <- yp[mela > 0]
	  ageh <- ages.m[mela > 0]
	  ageh <- ageh[ageh > 0]
	  yph <- yph[ageh > 1]
	  xph <- xph[ageh > 1]
	  ageh <- ageh[ageh > 1]
	  if (length(ageh) > 0) {text(x = xph, y = yph - inc, paste("Mela ", as.character(ageh)), cex = 0.75,
	                              col = "red", font = 2)}
	  
	}

}




