findids <- function(ped,indid){
  #print("-> findids")
  mid <- fid <- smid <- sfid <- fsibid <- cid <- sid <- NULL
  
  mid <- ped[ped$ID==indid,"MotherID"]
  fid <- ped[ped$ID==indid,"FatherID"]
  if(mid!=0|fid!=0){
    if(mid!=0&fid!=0){
      smid <- ped[ped$MotherID==mid&ped$FatherID!=fid,"FatherID"] #other spouses of the mother
      sfid <- ped[ped$FatherID==fid&ped$MotherID!=mid,"MotherID"] #other spouses of the father
    }else{
      if(mid!=0){
        smid <- ped[ped$MotherID==mid&ped$FatherID!=fid,"FatherID"] #other spouses of the mother
        sfid <- ped[ped$MotherID==-1,"FatherID"]
      }else{
        smid <- ped[ped$MotherID==-1,"FatherID"]
        sfid <- ped[ped$FatherID==fid&ped$MotherID!=mid,"MotherID"]
      }
    }
    fsibid <- ped[ped$FatherID==fid&ped$MotherID==mid&ped$ID!=indid,"ID"] #full sibs of the individual i
  }else{
    smid <- ped[ped$MotherID==-1,"FatherID"]
    sfid <- ped[ped$FatherID==-1,"MotherID"]
    fsibid <- ped[ped$FatherID==-1&ped$MotherID==-1,"ID"]
  }
#  temp1 <- ped$FatherID%in%fsibid&ped$MotherID!=0
#  temp2 <- ped$MotherID%in%fsibid&ped$FatherID!=0
#  fssibid <- ped[temp1|temp2,4:5] #full sibs and their spouses

  if(ped[ped$ID==indid,"Gender"]==1){
    temp <- ped$FatherID==indid
    cid <- ped[temp,"ID"]
    sid <- ped[temp,"MotherID"]
  }else{
    temp <- ped$MotherID==indid
    cid <- ped[temp,"ID"]
    sid <- ped[temp,"FatherID"] # the spouses of individual i
  }
    
  ids <- list(indid,mid,fid,smid,sfid,fsibid,sid,cid)
  names(ids) <- c("indid","mid","fid","smid","sfid","fsibid","sid","cid")
  #print("<- findids")
  return(ids)
}
