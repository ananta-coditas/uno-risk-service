calc.future.risk.cbc <- function(pen.cbc, pen.death, age.cur, age.bc1, age.by, net = FALSE){
  risk <- matrix(0, length(age.by), 4)
  if(net == FALSE){
    for(j in 1:4){
      for(k in 1:length(age.by)){
        for(i in (age.cur + 1):(age.cur + age.by[k])){
          risk[k, j] <- risk[k, j] + pen.cbc[i - age.bc1, c(1, 2, 4, 5)[j]] *
            (1 - sum(pen.death[1:(i - 1)]))
        }
        risk[k, j] <- risk[k, j] / ((1 - sum(pen.cbc[1:(age.cur - age.bc1), c(1, 2, 4, 5)[j]])) *
                                      (1 - sum(pen.death[1:age.cur])))
      }
    }
  } else{
    for(k in 1:length(age.by)){
      risk[k, ] <- colSums(pen.cbc[(age.cur - age.bc1 + 1):(age.cur - age.bc1 + age.by[k]), c(1, 2, 4, 5)]) /
        (1 - colSums(pen.cbc[1:(age.cur - age.bc1), c(1, 2, 4, 5)]))
    }
  }
  return(risk)
}
