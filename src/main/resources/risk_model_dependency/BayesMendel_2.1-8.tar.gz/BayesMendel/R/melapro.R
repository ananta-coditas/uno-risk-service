melapro <- function(family, counselee.id=1, allef.type="HBI", race = "Unknown", germline.testing=NULL,
                    params=melaparams(), print=TRUE, 
                    imputeAges=TRUE, imputeRelatives=FALSE, net = FALSE, bounds = FALSE){
  
  age.max <- 94
  
  pro.agemax <- 0
  ## if proband is older than the maximum age - 1, then only return carrier probabilities
  if(max(family[which(family$ID == counselee.id), "AgeSkin"], na.rm = TRUE) > age.max - 1){
    pro.agemax <- 1
  }
  
  warnmsg = ""
  if (imputeRelatives==TRUE & imputeAges==FALSE) {
    imputeAges=TRUE
    warnmsg = paste(warnmsg, "Warning: imputeAges was input as false, but has been set to TRUE.  If imputeRelatives=TRUE then by default imputeAges must also be TRUE.")
  }
  if (nchar(warnmsg) > 0) {print(warnmsg)}
  
  proband.current.age <- family$AgeSkin[family$ID == counselee.id]
  
  
  
  if (allef.type=="HBI") {
    params$allef <- list(c(1 - 0.0001518094,0.0001518094))
    if (race=="Unknown") {
      haz.d <- haz.death.crude
    }else{
      if (race=="Asian") {
        params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.hbi.net$fFX[,"Asian"]
        params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.hbi.net$fMX[,"Asian"]
        
        params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.hbi.crude$fFX[,"Asian"]
        params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.hbi.crude$fMX[,"Asian"]
        
        haz.d <- haz.death.race.crude$Asian
      }else{
        if (race=="Black") {
          params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.hbi.net$fFX[,"Black"]
          params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.hbi.net$fMX[,"Black"]
          
          params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.hbi.crude$fFX[,"Black"]
          params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.hbi.crude$fMX[,"Black"]
          
          haz.d <- haz.death.race.crude$Black
        }else{
          if (race=="Hispanic") {
            params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.hbi.net$fFX[,"Hispanic"]
            params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.hbi.net$fMX[,"Hispanic"]
            
            params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.hbi.crude$fFX[,"Hispanic"]
            params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.hbi.crude$fMX[,"Hispanic"]
            
            haz.d <- haz.death.race.crude$Hispanic
          }else{
            if (race=="NativeAmerican") {
              params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.hbi.net$fFX[,"NativeAmerican"]
              params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.hbi.net$fMX[,"NativeAmerican"]
              
              params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.hbi.crude$fFX[,"NativeAmerican"]
              params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.hbi.crude$fMX[,"NativeAmerican"]
              
              haz.d <- haz.death.race.crude$NativeAmerican
            }else{
              if (race=="White") {
                params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.hbi.net$fFX[,"White"]
                params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.hbi.net$fMX[,"White"]
                
                params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.hbi.crude$fFX[,"White"]
                params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.hbi.crude$fMX[,"White"]
                
                haz.d <- haz.death.race.crude$White
              }
            }}}}}
  }
  
  if (allef.type=="LBI") {
    params$allef <- list(c(1 - 0.0003091642, 0.0003091642))
    if (race=="Unknown") {
      params$penetrance.net <- penet.mela.lbi.net
      params$penetrance.crude <- penet.mela.lbi.crude
      haz.d <- haz.death.crude
    }else{
      if (race=="Asian") {
        params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.lbi.net$fFX[,"Asian"]
        params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.lbi.net$fMX[,"Asian"]
        
        params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.lbi.crude$fFX[,"Asian"]
        params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.lbi.crude$fMX[,"Asian"]
        
        haz.d <- haz.death.race.crude$Asian
      }else{
        if (race=="Black") {
          params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.lbi.net$fFX[,"Black"]
          params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.lbi.net$fMX[,"Black"]
          
          params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.lbi.crude$fFX[,"Black"]
          params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.lbi.crude$fMX[,"Black"]
          
          haz.d <- haz.death.race.crude$Black
        }else{
          if (race=="Hispanic") {
            params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.lbi.net$fFX[,"Hispanic"]
            params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.lbi.net$fMX[,"Hispanic"]
            
            params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.lbi.crude$fFX[,"Hispanic"]
            params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.lbi.crude$fMX[,"Hispanic"]
            
            haz.d <- haz.death.race.crude$Hispanic
          }else{
            if (race=="NativeAmerican") {
              params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.lbi.net$fFX[,"NativeAmerican"]
              params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.lbi.net$fMX[,"NativeAmerican"]
              
              params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.lbi.crude$fFX[,"NativeAmerican"]
              params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.lbi.crude$fMX[,"NativeAmerican"]
              
              haz.d <- haz.death.race.crude$NativeAmerican
            }else{
              if (race=="White") {
                params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.lbi.net$fFX[,"White"]
                params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.lbi.net$fMX[,"White"]
                
                params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.lbi.crude$fFX[,"White"]
                params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.lbi.crude$fMX[,"White"]
                
                haz.d <- haz.death.race.crude$White
              }
            }}}}}
  }
  
  if (allef.type=="GEM") {
    params$allef <- list(c(1 - 0.0004106908, 0.0004106908))
    if (race=="Unknown") {
      params$penetrance.net <- penet.mela.gem.net
      params$penetrance.crude <- penet.mela.gem.crude
      haz.d <- haz.death.crude
    }else{
      if (race=="Asian") {
        params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.gem.net$fFX[,"Asian"]
        params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.gem.net$fMX[,"Asian"]
        params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.gem.crude$fFX[,"Asian"]
        params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.gem.crude$fMX[,"Asian"]
        
        haz.d <- haz.death.race.crude$Asian
      }else{
        if (race=="Black") {
          params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.gem.net$fFX[,"Black"]
          params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.gem.net$fMX[,"Black"]
          
          params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.gem.crude$fFX[,"Black"]
          params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.gem.crude$fMX[,"Black"]
          
          haz.d <- haz.death.race.crude$Black
        }else{
          if (race=="Hispanic") {
            params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.gem.net$fFX[,"Hispanic"]
            params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.gem.net$fMX[,"Hispanic"]
            
            params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.gem.crude$fFX[,"Hispanic"]
            params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.gem.crude$fMX[,"Hispanic"]
            
            haz.d <- haz.death.race.crude$Hispanic
          }else{
            if (race=="NativeAmerican") {
              params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.gem.net$fFX[,"NativeAmerican"]
              params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.gem.net$fMX[,"NativeAmerican"]
              
              params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.gem.crude$fFX[,"NativeAmerican"]
              params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.gem.crude$fMX[,"NativeAmerican"]
              
              haz.d <- haz.death.race.crude$NativeAmerican
            }else{
              if (race=="White") {
                params$penetrance.net$fFX[,"P160"] <- baseline.race.mela.gem.net$fFX[,"White"]
                params$penetrance.net$fMX[,"P160"] <- baseline.race.mela.gem.net$fMX[,"White"]
                
                params$penetrance.crude$fFX[,"P160"] <- baseline.race.mela.gem.crude$fFX[,"White"]
                params$penetrance.crude$fMX[,"P160"] <- baseline.race.mela.gem.crude$fMX[,"White"]
                
                haz.d <- haz.death.race.crude$White
              }
            }}}}}
  }
  
  if (allef.type=="other") {
    params$allef <- params$allef
    params$penetrance.net <- params$penetrance.net
    params$penetrance.crude <- params$penetrance.crude
  }
  
  # Set up allele frequencies to work with new peelingR
  allef <- list()
  allef[allef.type] <- list(params$allef)
  family$ethnic <- rep(allef.type, nrow(family))
  
  family <- CheckFamStructure(model="melapro",fff=family,counselee.id=counselee.id, 
                              germline.testing=germline.testing, 
                              imputeAges=imputeAges, 
                              imputeRelatives=imputeRelatives, params=params, bounds = bounds)
  if(is.character(family)) {return(family)}
  
  if("AgeSkin" %in% colnames(family)){
    family$AgeSkin[family$AgeSkin > age.max] <- age.max
  }
  
  if("AgeSkinLower" %in% colnames(family)){
    family$AgeSkinLower[family$AgeSkinLower > age.max] <- age.max
    family$AgeSkinLower[family$AgeSkinLower < 1] <- 1
  }
  if("AgeSkinUpper" %in% colnames(family)){
    family$AgeSkinUpper[family$AgeSkinUpper > age.max] <- age.max
    family$AgeSkinUpper[family$AgeSkinUpper < 1] <- 1
  }
  
  # if the counselee has an identical twin, make sure the ID used in the calculation is that of the counselee and not his/her twin so peeling does not error out
  originalcounselee.id <- counselee.id
  if (family$Twins[family$ID==counselee.id]>0) {
    twins <- family[family$Twins==family$Twins[family$ID==counselee.id],]
    counselee.id <- twins$ID[1]
  }
  
  psize <- dim(family)[1]
  ndis <- 1 # melanoma
  nloci <- 1
  ngen <- 3^nloci
  horizon <- length(params$penetrance.net$fFX[,1])
  melanoma <- 1
  
  #-------------------------------------------------------------------------------------------#
  # Set up matrices for disease status (DIS), age (AGE), and penetrances (PPf, PPm, FFf, FFm) #
  
  DIS <- matrix(0,psize,ndis)   # disease status
  DIS[,melanoma][family[,"AffectedSkin"]>0] <- 1    # melanoma
  # AGE <- matrix(0,psize,ndis)
  # AGE[,melanoma] <- round(family[,"AgeSkin"])
  males <- (1:psize)[family[,"Gender"]==1]
  females <- (1:psize)[family[,"Gender"]==0]
  PPf <- FFf <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, females
  PPm <- FFm <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, males
  
  PPf[,melanoma,] <- params$penetrance.net$fFX
  PPm[,melanoma,] <- params$penetrance.net$fMX
  FFf[,melanoma,] <- apply(PPf[,melanoma,],2,cumsum)
  FFm[,melanoma,] <- apply(PPm[,melanoma,],2,cumsum)
  
  
  ## Make a within-*pro function that computes needed components
  ## for capturing the LIK and ped objects required by peeling
  
  runPeelingmelapro = function(family, params, ngen, germline.testing,
                               psize, counselee.id, allef)
  {
    
    ## first getting ages
    AGE <- matrix(0,psize,ndis)
    AGE[,melanoma] <- round(family[,"AgeSkin"])
    
    AFF <- array(0,c(psize,ndis,ngen)) # likelihood if affected
    for ( gg in 1:ngen){
      for ( dd in 1:ndis) {
        AFF[females,dd,gg] <- PPf[AGE[females,dd],dd,gg]
        AFF[males,dd,gg] <- PPm[AGE[males,dd],dd,gg]
      }
    }
    UNA <- array(0,c(psize,ndis,ngen)) # likelihood if UNAffeected
    for ( gg in 1:ngen) { for ( dd in 1:ndis ){
      UNA[females,dd,gg] <- 1-FFf[AGE[females,dd],dd,gg] 
      UNA[males,dd,gg] <- 1-FFm[AGE[males,dd],dd,gg]
    }}
    
    #---------------------------------------------------------#	 
    # Contribution of germline testing results. Pr(Test|gene) #
    
    TES <- matrix(1,psize,ngen)
    p16cols <- 2:3
    
    if(!is.null(germline.testing)){
      
      # if (sum(germline.testing$TestOrder)==0) { # Unknown test order
      #   whogottested <- which(germline.testing$P16>0)
      #   ntested <- length(whogottested)
      #   if (is.element(counselee.id, whogottested)) {
      #     germline.testing$TestOrder[which(family$ID==counselee.id)] <- ntested # make the proband as the last person who got tested
      #     germline.testing$TestOrder[setdiff(whogottested, counselee.id)] <- sample(1:(ntested-1),size=ntested-1)
      #   }
      #   if (!is.element(counselee.id, whogottested)) {
      #     germline.testing$TestOrder[whogottested] <- sample(1:ntested, size=ntested)
      #   }
      #   
      #   print("Warning: Testing order has been imputed (see help(melapro) for details).")
      #   
      # }
      
      # Need to group members with test results as follows:
      # 'pre.pos.neg': those who test negative before anyone tests positive
      # 'first.pos': first person to test positive
      # 'after.pos' and 'after.neg': anyone tested after the first positive
      
      positives <- which(germline.testing$P16==1)
      negatives <- which(germline.testing$P16==2)
      
      # if (length(positives)>0) {
      #   first.pos <- which(germline.testing$P16==1 & germline.testing$TestOrder==min(germline.testing$TestOrder[positives]))
      #   pre.pos.neg <- which(germline.testing$P16==2 & germline.testing$TestOrder<germline.testing$TestOrder[first.pos])
      #   after.pos <- setdiff(positives, first.pos)
      #   after.neg <- setdiff(negatives, pre.pos.neg)
      # }
      # if (length(positives)==0) {
      #   pre.pos.neg <- negatives
      #   first.pos <- after.pos <- after.neg <- NULL
      #   
      # }
      
      if (length(positives)>0) TES[positives,p16cols] <- params$sensitivity
      if (length(negatives)>0) TES[negatives,p16cols] <- 1-params$sensitivity
      if (length(negatives)>0) TES[negatives,-p16cols] <- params$specificity
      if (length(positives)>0) TES[positives,-p16cols] <- 1-params$specificity
      
      # if (length(after.pos)>0) TES[after.pos,p16cols] <- 1 - 2*allef[[family$ethnic[after.pos[1]]]][[1]][2]
      # if (length(after.neg)>0) TES[after.neg,p16cols] <- 2*allef[[family$ethnic[after.neg[1]]]][[1]][2]
      # if (length(after.neg)>0) TES[after.neg,-p16cols] <- params$specificity
      # if (length(after.pos)>0) TES[after.pos,-p16cols] <- 1-params$specificity
      
    }
    
    LIK <- matrix(1,psize,ngen)
    for (gg in 1:ngen) {
      LIK[,gg] <- apply(DIS * AFF[,,gg] + (1-DIS) * UNA[,,gg],1,prod)*TES[,gg]
    }
    
    ##-----------------------------------------------##
    ## Put in a Poisson model for multiple melanomas ##
    
    melcount <- family[,"AffectedSkin"]
    melcount <- ifelse(melcount!=1,ifelse(melcount>1,2,0),1)
    mel1.id <- melcount==1
    old.LIK <- LIK
    if(sum(mel1.id)>0){
      LIK[mel1.id,1] <- old.LIK[mel1.id,1]*params$spm.lr.noncarrier
      LIK[mel1.id,2:3] <- old.LIK[mel1.id,2:3]*params$spm.lr.carrier
    }
    mel2.id <- melcount==2
    if(sum(mel2.id)>0){
      LIK[mel2.id,2:3] <- old.LIK[mel2.id,2:3]*params$mpm.lr.carrier
      LIK[mel2.id,1] <- LIK[mel2.id,2]*params$mpm.lr.noncarrier*old.LIK[mel2.id,1]/old.LIK[mel2.id,2]
    }
    
    
    # If there are twins in the family, collapse them here #
    if (sum(family$Twins)>0) {
      if (length(unique(family$Twins))>=1 & !any(family$Twins==0)) {loopID <- length(unique(family$Twins))}
      if (length(unique(family$Twins))>1 & any(family$Twins==0)) {loopID <- length(unique(family$Twins))-1}
      family$NewMotherIndex = family$NewFatherIndex = 0
      
      # Because we are collapsing twins, need to replace any offspring's mid and fid
      for (iiiii in 1:loopID) {
        temp <- family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],]
        if (temp$Gender[1]==0) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewMotherIndex"] = temp$ID[1]}
        if (temp$Gender[1]==1) {
          family[family$Twins==unique(family$Twins[family$Twins>0])[iiiii],"NewFatherIndex"] = temp$ID[1]}
      }
      
      twins = family$ID[family$Twins>0]
      offspring = family$ID[is.element(family$MotherID, twins) | is.element(family$FatherID, twins)]
      if (length(offspring)>0) {
        for (ooo in 1:length(offspring)){
          motherIsTwin = family$Twins[family$ID==family$MotherID[family$ID==offspring[ooo]]]
          fatherIsTwin = family$Twins[family$ID==family$FatherID[family$ID==offspring[ooo]]]
          if (length(motherIsTwin)!=0) {
            if (motherIsTwin!=0) {
              family$MotherID[family$ID==offspring[ooo]] = family$NewMotherIndex[family$ID==family$MotherID[family$ID==offspring[ooo]]]}
          }
          if (length(fatherIsTwin)!=0) {
            if (fatherIsTwin!=0) {
              family$FatherID[family$ID==offspring[ooo]] = family$NewFatherIndex[family$ID==family$FatherID[family$ID==offspring[ooo]]]}
          }
        }
      }
      # get the first twin's ped info for peeling
      firsttwin = which(family$Twins>0)
      firsttwin = firsttwin[match(unique(family$Twins[family$Twins!=0]), family$Twins[family$Twins!=0])]
      nottwins = which(family$Twins==0)
      collapsedtwins = sort(c(firsttwin,nottwins)) 
      ped = family[collapsedtwins,c("ID", "Gender", "FatherID", "MotherID", "ethnic")]
      # set up new LIK
      newLIK = LIK
      twinIDs = unique(family$Twins[family$Twins!=0])
      for (ttt in 1:length(twinIDs)) {
        twinrows = which(family$Twins==twinIDs[ttt])
        newLIK[twinrows[1],] = LIK[twinrows[1],] * LIK[twinrows[2],]
        newLIK[twinrows[2],] = rep(NA,ngen)
      }
      # Now take out empty rows
      LIK = newLIK[apply(newLIK,1,function(x){return(!any(is.na(x)))}),]
    }
    
    if (sum(family$Twins)==0) {
      ped = family[,c("ID", "Gender", "FatherID", "MotherID", "ethnic")]
    }
    
    # Assume that the LIK contribution of homozygotes is the same as heterozygotes.
    
    #--------------------------------------------------------------------------------------------#
    # Run likelihood contributions through peeling functions to get posterior probability matrix #
    # peelingR  (peeling in R)
    #  outputs: numerator of BayesThereom calculation
    #           weight used for likelihood
    #  logp <- peelingR(allef,LIK,ped=family[,c("ID", "Gender", "FatherID", "MotherID","ethnic")],counselee.id=counselee.id,nloci=nloci)
    #  post <- rescale(logp$num)
    #  ll <- log(sum(logp$num))+logp$weight
    #
    # peelingRC (peeling in C)
    #  outputs: posterior probability
    #
    # When moving to peelingRC, decided to leave ll slot but set to NULL
    
    post <- peelingRC(allef,LIK,ped=ped,counselee.id=counselee.id,nloci=nloci)
    
    return(post)
    
  }
  
  ## --------------
  ## Calculation for LIK start here.  This is where we start the multiple age imputation process ---------------###
  
  missingage = any(family$AgeSkin==1)
  
  if (missingage & imputeAges==FALSE) {
    agewarning = "Warning: Age imputation has been turned off, but there are unknown ages of some unaffected family members. You may want to get more information about family member ages and re-run the calculation, or set imputeAges=TRUE."
    post = runPeelingmelapro(family=family, 
                             params=params, ngen=ngen,
                             psize=psize, germline.testing=germline.testing,
                             counselee.id=counselee.id, allef=allef)
    
  }
  if (missingage & imputeAges==TRUE){
    agewarning = "Warning: Unknown ages of some unaffected and affected family members have been imputed.  You may want to get more information about family member ages and re-run the calculation."
    ifamily = ImputeAge(fff=family, params=params, model='melapro', bounds = bounds) #ImputeAge is run only once and returns a matrix of nIter possible affection ages
    postList = NULL
    nIter = params$nIter
    
    # Run each imputed age through runPeeling if there are affected relatives
    # who had age imputed
    if (length(ifamily$mem_bc)>0) {
      for (iIter in 1:nIter){
        # creating imputed fff
        nf = ifamily$fff
        
        if (length(ifamily$mem_bc)>0) {
          nf$AgeSkin[ifamily$mem_bc] = ifamily$age_bc[iIter,ifamily$mem_bc]  
        }
        
        postList = rbind(postList,
                         runPeelingmelapro(family=nf, 
                                           params=params, ngen=ngen,
                                           psize=psize, germline.testing=germline.testing,
                                           counselee.id=counselee.id, allef=allef)
        )
      }
      
      post = apply(postList, 2, mean)
    }
    
    if (length(ifamily$mem_bc)==0) {
      post = runPeelingmelapro(family=ifamily$fff, 
                               params=params, ngen=ngen,
                               psize=psize, germline.testing=germline.testing,
                               counselee.id=counselee.id, allef=allef)
    }
    
  }
  
  if (!missingage) { # No missing ages or impute flag is turned off, run peeling once with observed input data.
    agewarning=""
    post = runPeelingmelapro(family=family, 
                             params=params, ngen=ngen,
                             psize=psize, germline.testing=germline.testing,
                             counselee.id=counselee.id, allef=allef)
    
  }
  
  # save family object to be output
  if (!missingage | imputeAges==FALSE) {family= family}
  if (missingage & imputeAges==TRUE) { family = ifamily$fff}
  
  #### Age imputation loop would stop here, output results
  #### ---------------------------------------------------####
  
  ll   <- NULL
  
  post = matrix(post, nrow=1)
  colnames(post) <- c("P160","P161","P162")
  
  
  if (print) {
    cat("The probability of being a carrier is",1-post[1],"\n")
  }
  
  if(any(c(post[1], 1 - post[1]) == 0) & !is.null(germline.testing) &
     any(c(params$sensitivity, params$specificity) == 1)){
    warning("Some of the estimated probabilities are 0 or 1, most likely due to the
            incorporation of reported germline testing results (by default, we assume
            that the sensitivity and specificity for all germline tests is 1).
            However, this does not guarantee that the person is a noncarrier or
            mutation carrier; a more accurate estimate may be achieved with
            user-specified sensitivities and specificities.")
  }
  
  self <- which(family[,"ID"]==originalcounselee.id)
  # current.age <- AGE[self]
  if(proband.current.age + params$age.by > age.max){
    ages <- age.max
  } else{
    ages <- seq(proband.current.age+params$age.by, ifelse(params$age.to>=proband.current.age+params$age.by, params$age.to, age.max), by=params$age.by)
  }
  
  if(pro.agemax == 1){
    predictions <- future.risk <- data.frame()
    warning(paste("Proband is older than ", age.max - 1, ". Future risk prediction is not calculated.", sep = ""))
  } else{
    
    predictions <- NULL
    ages.by1 <- (proband.current.age+1):max(ages)
    
    
    if(family[self,"Gender"]==0){#female
      hFX0 <- hFX1 <- rep(0,max(ages))
      future.risk <- data.frame(hFX0,hFX1)
      
      if(net == FALSE){
        ## crude risk
        future.risk$hFX0[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fFX[,"P160"],haz.d$femaleMelanoma)[ages.by1],haz.d$femaleMelanoma[ages.by1])
        future.risk$hFX1[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fFX[,"P161"],haz.d$femaleMelanoma)[ages.by1],haz.d$femaleMelanoma[ages.by1])
      } else{
        ## net risk
        future.risk$hFX0[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fFX[,"P160"], proband.current.age, ages.by1)
        future.risk$hFX1[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fFX[,"P161"], proband.current.age, ages.by1)
      }
      
      X.risk <- future.risk$hFX1[ages]*(post[2]+post[3]) + future.risk$hFX0[ages]*post[1]
      
    }else{#male
      hMX1 <- hMX0 <- rep(0,max(ages))
      future.risk <- data.frame(hMX1,hMX0)
      
      if(net == FALSE){
        ## crude risk
        future.risk$hMX0[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fMX[,"P160"],haz.d$maleMelanoma)[ages.by1],haz.d$maleMelanoma[ages.by1])
        future.risk$hMX1[ages.by1] <- calc.future.risk(dens2haz.cs(params$penetrance.crude$fMX[,"P161"],haz.d$maleMelanoma)[ages.by1],haz.d$maleMelanoma[ages.by1])
      } else{
        ## net risk
        future.risk$hMX0[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fMX[,"P160"], proband.current.age, ages.by1)
        future.risk$hMX1[ages.by1] <- calc.future.risk.nd(params$penetrance.net$fMX[,"P161"], proband.current.age, ages.by1)
      }
      
      X.risk <- future.risk$hMX1[ages]*(post[2]+post[3]) + future.risk$hMX0[ages]*post[1] 
    }
    
    # if proband already has melanomas, set future risk to NA
    
    if (family$AffectedSkin[which(family$ID==originalcounselee.id)]>0) {X.risk <- rep(NA, length(ages))}
    
    predictions <- data.frame(ages, melanoma.risk=X.risk)
    colnames(predictions) <- c("By age", "Melanoma Risk")
    
    if (print) {
      cat("The risk of developing cancer is", "\n")
      print(predictions)
    }
  }
  
  probs <- data.frame(1-post[1])
  names(probs) <- "Pr(Being a carrier)"
  rownames(probs) <- ""
  
  return(new(Class = "BayesMendel", family = family, posterior = post, 
             probs = probs, predictions = predictions, counselee.id = originalcounselee.id, loglik = ll, future.risk=future.risk))
}
