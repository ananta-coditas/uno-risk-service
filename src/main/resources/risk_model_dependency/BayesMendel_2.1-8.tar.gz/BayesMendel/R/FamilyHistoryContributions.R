FamilyHistoryContributions <- function(family,penetrance,ngen,type,whichintervention="Oophorectomy",CBCpenetrance, model)
{
  ## Purpose: Compute Likelihood Contributions, both pre- and post- intervention
  ## ----------------------------------------------------------------------
  ## Arguments: family, psize, ngen
  ## ----------------------------------------------------------------------
  ## Author: Hormuzd Katki, Date: 24 Mar 2006, 11:24
  
  
  ## Update HK's original function from 2006 to consider new penetrance objects in 
  ## version 2.0+ of BayesMendel
  ## A Blackford; March 2008
  
  ## Aug 2012, v2.0-8
  ## Updating to include mastectomy and new penetrance estimates for contralateral BC
  
  ## v2.1-7 -- adding brcapancpro
  
  # Figure out if doing pre- or post- intervention contributions
  if( type =="PostIntervention" ){
    # 7/9/13: Corrected from being an ifelse statement to an if then else:
    #intage <- ifelse(whichintervention=="Oophorectomy" | whichintervention=="OophorectomyFirst", family[,"AgeOophorectomy"],
    # family[,"AgeMastectomy"])
    if (whichintervention=="Oophorectomy" | whichintervention=="OophorectomyFirst") {
      intage <- family[,"AgeOophorectomy"]
    } else{
      intage <- family[,"AgeMastectomy"]
    }
    
  } else{
    if( type!="PreIntervention" ){
      stop("Contributions must be of type: PreIntervention or PostIntervention")
    }
  }
  
  if (model=="brcapro") ndis <- 3 # breast, contralateral breast, ovarian
  if (model=="brcapancpro") ndis <- 4 # breast, contralateral breast, ovarian, pancreas 
  horizon <- nrow(penetrance$fFX)
  psize <- dim(family)[1]
  
  breast1 <- 1
  breast2 <- 2
  ovaries <- 3
  pancreas <- 4
  under40 <- 1
  over40 <- 2
  DIS <- matrix(0,psize,ndis)   # disease status
  DIS[,breast1][family[,"AffectedBreast"]>0] <- 1    # first primary breast
  DIS[,breast2][family[,"AffectedBreast"]==2] <- 1   # contralateral primary breast
  DIS[,ovaries] <- family[,"AffectedOvary"]         # ovaries
  if (model=="brcapancpro") {DIS[,pancreas]<- family[,"AffectedPancreas"]}      # pancreas
  
  ages.cancer <- data.frame(family[,"AgeBreast",drop=FALSE],family[,"AgeOvary",drop=FALSE],family[,"AgeBreastContralateral",drop=FALSE])
  if (model=="brcapancpro") {ages.cancer <- data.frame(family[,"AgeBreast",drop=FALSE],family[,"AgeOvary",drop=FALSE],family[,"AgeBreastContralateral",drop=FALSE],family[,"AgePancreas",drop=FALSE])}
  maxage <- apply(ages.cancer,1,max)
  
  AGE <- matrix(0,psize,ndis)
  AGE[,breast1] <- family[,"AgeBreast"]   
  AGE[,breast2] <- DIS[,2] * family[,"AgeBreastContralateral"] + (1-DIS[,2]) * maxage
  AGE[,ovaries] <- family[,"AgeOvary"]
  if (model=="brcapancpro") {AGE[,pancreas] <- family[,"AgePancreas"]}
  
  if (type=="PostIntervention") {
    if (whichintervention=="MastectomyFirst") { # this ensures we calculate this post-intervention component from mastectomy ONLY up to age of oophorectomy.  
      AGE[,breast1] <- apply(family[,c("AgeOophorectomy","AgeBreast")],1,min)
      AGE[,breast2] <- apply(cbind(family[,"AgeOophorectomy"], DIS[,2] * family[,"AgeBreastContralateral"] + (1-DIS[,2]) * maxage),1,min)
      AGE[,ovaries] <- apply(family[,c("AgeOophorectomy","AgeOvary")],1,min)
      if (model=="brcapancpro") {AGE[,pancreas] <- apply(family[,c("AgeOophorectomy","AgePancreas")],1,min)}
    }
    
    if (whichintervention=="OophorectomyFirst") {
      AGE[,breast1] <- apply(family[,c("AgeMastectomy","AgeBreast")],1,min)
      AGE[,breast2] <- apply(cbind(family[,"AgeMastectomy"], DIS[,2] * family[,"AgeBreastContralateral"] + (1-DIS[,2]) * maxage),1,min)
      AGE[,ovaries] <- apply(family[,c("AgeMastectomy","AgeOvary")],1,min)
      if (model=="brcapancpro") {AGE[,pancreas] <- apply(family[,c("AgeMastectomy","AgePancreas")],1,min)}
    }
    
    if (whichintervention=="Oophorectomy" | whichintervention=="Mastectomy") {
      AGE[,breast1] <- family[,"AgeBreast"]   
      AGE[,breast2] <- DIS[,2] * family[,"AgeBreastContralateral"] + (1-DIS[,2]) * maxage
      AGE[,ovaries] <- family[,"AgeOvary"]
      if (model=="brcapancpro") {AGE[,pancreas] <- family[,"AgePancreas"]}
    }
  }
  
  if (type=="PreIntervention") {
    AGE[,breast1] <- family[,"AgeBreast"]   
    AGE[,breast2] <- DIS[,2] * family[,"AgeBreastContralateral"] + (1-DIS[,2]) * maxage
    AGE[,ovaries] <- family[,"AgeOvary"]
    if (model=="brcapancpro") {AGE[,pancreas] <- family[,"AgePancreas"]}
  }
  
  males <- (1:psize)[family[,"Gender"]==1]
  females <- (1:psize)[family[,"Gender"]==0]
  femalesUnder40 <-  (1:psize)[family[,"Gender"]==0 & family$AgeBreast < 40]
  femalesOver40 <- (1:psize)[family[,"Gender"]==0 & family$AgeBreast >= 40]
  malesUnder40 <- (1:psize)[family[,"Gender"]==1 & family$AgeBreast < 40]
  malesOver40 <- (1:psize)[family[,"Gender"]==1 & family$AgeBreast >= 40]
  
  
  ##
  # Get penetrance densities, depending on pre or post intervention
  ##
  Hazf <- PPf <- FFf <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, females
  Hazm <- PPm <- FFm <- array(0,c(horizon,ndis,ngen))  # penetrances & cumu, males
  HazfCBC <- array(0,c(horizon+1,ndis,ngen)) # extra column in CBC due to interval from 0 to 1
  HazmCBC <- array(0,c(horizon+1,ndis,ngen))
  # HazfCBC <- array(0, c(horizon, ndis, ngen)) # extra column in CBC due to interval from 0 to 1
  # HazmCBC <- array(0, c(horizon, ndis, ngen))
  
  
  if ( type == "PreIntervention" ) {
    PPf[,breast1,] <- matrix(unlist(penetrance$fFX[,1:ngen]), ncol=ngen)
    PPf[,ovaries,] <- matrix(unlist(penetrance$fFY[,1:ngen]), ncol=ngen)
    PPm[,breast1,] <- matrix(unlist(penetrance$fMX[,1:ngen]), ncol=ngen)
    PPm[,ovaries,] <- matrix(unlist(penetrance$fMY[,1:ngen]), ncol=ngen)
    if(model == "brcapancpro"){
      PPf[,pancreas,] <- matrix(unlist(penetrance$fFZ[,1:ngen]), ncol=ngen)
      PPm[,pancreas,] <- matrix(unlist(penetrance$fMZ[,1:ngen]), ncol=ngen)
    }
  }
  else if ( type=="PostIntervention") {
    
    # Post-intervention penetrances are for intervention at age 0.
    # To get it for intervention at age i, use this penetrance hazard h, density f and CDF
    # F at intervention age i and current age y^I:
    #    if survived: survived: 1 - F(y^I) - F(i)
    #    if disease: h(y^I) * survived
    # Thus we need the pure hazard as well:
    # For discrete event times, remember that density(t)=hazard(t)*survival(t-1)
    # So when computing survival, compute it from ages 0 to nages-1, not 1 to nages
    
    gethazards <- function(penettemp) {
      density <- penettemp
      nages <- nrow(density)
      npenets <- ncol(density)
      survival <- rbind(rep(1,npenets), 1-apply(density[1:nages-1,],2,cumsum) )
      haz <- density / survival
      return(haz)
    }
    hazards <- list()
    hazards$fFX <- gethazards(as.data.frame(penetrance$fFX))
    hazards$fFY <- gethazards(as.data.frame(penetrance$fFY))
    hazards$fMX <- gethazards(as.data.frame(penetrance$fMX))
    hazards$fMY <- gethazards(as.data.frame(penetrance$fMY))
    
    hazardsCBC <- list()
    hazardsCBC$fFX.Under40 <- gethazards(as.data.frame(CBCpenetrance$fFX.Under40))
    hazardsCBC$fFX.Over40 <- gethazards(as.data.frame(CBCpenetrance$fFX.Over40))
    hazardsCBC$fMX.Under40 <- gethazards(as.data.frame(CBCpenetrance$fMX.Under40))
    hazardsCBC$fMX.Over40 <- gethazards(as.data.frame(CBCpenetrance$fMX.Over40))
    
    if (whichintervention=="Mastectomy" | whichintervention=="MastectomyFirst") {
      
      # Put hazards in their right places
      Hazf[,breast1,1:ngen] <- matrix(unlist(hazards$fFX[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      Hazf[,ovaries,1:ngen] <- matrix(unlist(hazards$fFY[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      Hazm[,breast1,1:ngen] <- matrix(unlist(hazards$fMX[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      Hazm[,ovaries,1:ngen] <- matrix(unlist(hazards$fMY[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      
      # The input penetrances can be used to estimate the survived contribution
      PPf[,breast1,1:ngen] <- matrix(unlist(penetrance$fFX[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      PPf[,ovaries,1:ngen] <- matrix(unlist(penetrance$fFY[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      PPm[,breast1,1:ngen] <- matrix(unlist(penetrance$fMX[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      PPm[,ovaries,1:ngen] <- matrix(unlist(penetrance$fMY[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      
      HazfCBC[,under40,1:ngen] <- matrix(unlist(hazardsCBC$fFX.Under40[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      HazfCBC[,over40,1:ngen] <- matrix(unlist(hazardsCBC$fFX.Over40[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      HazmCBC[,under40,1:ngen] <- matrix(unlist(hazardsCBC$fMX.Under40[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      HazmCBC[,over40,1:ngen] <- matrix(unlist(hazardsCBC$fMX.Over40[,c("MASB00", "MASB10", "MASB20", "MASB01","MASB11", "MASB21", "MASB02", "MASB12", "MASB22")]), ncol=9)
      
    }
    
    if (whichintervention=="Oophorectomy" | whichintervention=="OophorectomyFirst") {
      # Put hazards in their right places
      Hazf[,breast1,1:ngen] <- matrix(unlist(hazards$fFX[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      Hazf[,ovaries,1:ngen] <- matrix(unlist(hazards$fFY[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      Hazm[,breast1,1:ngen] <- matrix(unlist(hazards$fMX[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      Hazm[,ovaries,1:ngen] <- matrix(unlist(hazards$fMY[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      
      HazfCBC[,under40,1:ngen] <- matrix(unlist(hazardsCBC$fFX.Under40[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      HazfCBC[,over40,1:ngen] <- matrix(unlist(hazardsCBC$fFX.Over40[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      HazmCBC[,under40,1:ngen] <- matrix(unlist(hazardsCBC$fMX.Under40[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      HazmCBC[,over40,1:ngen] <- matrix(unlist(hazardsCBC$fMX.Over40[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      
      # The input penetrances can be used to estimate the survived contribution
      PPf[,breast1,1:ngen] <- matrix(unlist(penetrance$fFX[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      PPf[,ovaries,1:ngen] <- matrix(unlist(penetrance$fFY[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      PPm[,breast1,1:ngen] <- matrix(unlist(penetrance$fMX[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      PPm[,ovaries,1:ngen] <- matrix(unlist(penetrance$fMY[,c("OOPHB00", "OOPHB10", "OOPHB20", "OOPHB01","OOPHB11", "OOPHB21", "OOPHB02", "OOPHB12", "OOPHB22")]), ncol=9)
      
    }
  }
  # end of if postintervention loop
  
  # Penetrance CDFs
  for ( gg in 1:ngen ) { for ( dd in (1:ndis)[-breast2] ) {
    FFf[,dd,gg] <- cumsum(PPf[,dd,gg])
    FFm[,dd,gg] <- cumsum(PPm[,dd,gg])
  }}
  
  
  ##
  # There are 4 scenarios to calculate likelihood contributions for, for each disease and
  # gene:
  # 1.  One disease
  # 2.  Survived disease
  # 3.  Second disease (contralateral breast cancer)
  # 4.  Got first disease, did not get second disease, but current age > age of first
  #     disease (i.e. got first breast cancer, survived to current age so second cancer
  #     is beyond current age)
  
  ##
  # Scenario 1: One disease
  # Contribution is just the density(y) = hazard(y)*Survival(y-1)
  ##
  AFF <- array(0,c(psize,ndis,ngen)) 
  for ( gg in 1:ngen ) { for ( dd in 1:ndis ) {
    
    # Pre-Intervention contribution
    AFF[females,dd,gg] <- PPf[AGE[females,dd],dd,gg]
    AFF[  males,dd,gg] <- PPm[AGE[  males,dd],dd,gg]
    
    # If post-intervention, use post-intervention density
    # Note that the age-1 is needed because of discrete survival to age-1, then disease at
    # age.  There will be no ages=1 here, so it won't crash.
    if ( type=="PostIntervention" ) {
      AFF[females,dd,gg] <- Hazf[AGE[females,dd],dd,gg] *
        (1 - FFf[AGE[females,dd]-1,dd,gg] + FFf[intage[females],dd,gg])
      AFF[ males,dd,gg] <-  Hazm[AGE[ males,dd],dd,gg] *
        (1 - FFm[AGE[  males,dd]-1,dd,gg] + FFm[intage[  males],dd,gg])
    }
  }}
  
  ##
  # Scenario 2: Survived disease
  # Contribution is just surviving disease
  ##
  UNA <- array(0,c(psize,ndis,ngen)) # likelihood if UNAffeected
  for ( gg in 1:ngen ) { for ( dd in 1:ndis ){
    
    # Pre-Intervention contribution
    UNA[females,dd,gg] <- 1-FFf[AGE[females,dd],dd,gg] 
    UNA[  males,dd,gg] <- 1-FFm[AGE[  males,dd],dd,gg]
    
    # If post-intervention, take the pre-intervention form and account for starting at
    # intervention age (unaffected means surviving from intervention to current age) and
    # truncation at age of intervention, i.e., divide by survival probability to intage
    if ( type=="PostIntervention" ) {
      UNA[females,dd,gg] <- 1 - FFf[AGE[females,dd],dd,gg] + FFf[intage[females],dd,gg]
      UNA[  males,dd,gg] <- 1 - FFm[AGE[  males,dd],dd,gg] + FFm[intage[  males],dd,gg]
    }      
    
  }}
  
  ##
  # Scenario 3: 2 diseases (contralateral breast cancer)
  # The penetrance for contralateral breast cancer is calculated as a conditional penetrance, multiplying
  # the penetrance for a 1st breast cancer diagnosis at the age observed by the penetrance for developing
  # a second breast cancer in the years from the first diagnosis
  # Different penetrances are considered depending on whether the first diagnosis occurred before or after age
  # 40.
  
  for ( gg in 1:ngen ) {
    
    # Pre-Intervention Contribution
    FFf[AGE[females,breast1],breast1,gg] <- ifelse(FFf[AGE[females,breast1],breast1,gg]>1, 0.999, FFf[AGE[females,breast1],breast1,gg])
    FFf[AGE[females,breast2],breast1,gg] <- ifelse(FFf[AGE[females,breast2],breast1,gg]>1, 0.999, FFf[AGE[females,breast2],breast1,gg])
    
    AGEBETWEEN <- AGE[,breast2] - AGE[,breast1] + 1 # adding 1 to get the index in the matrix, can't have a 0 index
    
    AFF[femalesUnder40,breast2,gg] <- CBCpenetrance$fFX.Under40[AGEBETWEEN[femalesUnder40],gg]
    AFF[femalesOver40,breast2,gg] <-  CBCpenetrance$fFX.Over40[AGEBETWEEN[femalesOver40],gg]
    AFF[malesUnder40,breast2,gg] <- CBCpenetrance$fMX.Under40[AGEBETWEEN[malesUnder40],gg]
    AFF[malesOver40,breast2,gg] <-  CBCpenetrance$fMX.Over40[AGEBETWEEN[malesOver40],gg]
    
    ## AFF[females,breast2,gg] <-     
    ## .5 * PPf[AGE[females,breast2],breast1,gg] / 
    ##     ( sqrt(1-FFf[AGE[females,breast1],breast1,gg]) *
    ##      sqrt(1-FFf[AGE[females,breast2],breast1,gg]) )
    
    ## AFF[males,breast2,gg] <-
    ##   .5 * PPm[AGE[males,breast2],breast1,gg] / 
    ##     ( sqrt(1-FFm[AGE[males,breast1],breast1,gg]) *
    ##      sqrt(1-FFm[AGE[males,breast2],breast1,gg]) )
    
    # Post-Intervention Contribution
    
    if ( type=="PostIntervention" ) {
      
      AGEBETWEEN <- AGE[,breast2] - AGE[,breast1] + 1 # adding 1 to get the index in the matrix, can't have a 0 index
      
      AFF[femalesUnder40,breast2,gg] <-  HazfCBC[AGEBETWEEN[femalesUnder40],under40,gg] * (1 - FFf[AGE[femalesUnder40,breast2]-1,breast1,gg] + FFf[intage[femalesUnder40],breast1,gg])
      AFF[femalesOver40,breast2,gg] <- HazfCBC[AGEBETWEEN[femalesOver40],over40,gg]    * (1 - FFf[AGE[femalesOver40,breast2]-1,breast1,gg] + FFf[intage[femalesOver40],breast1,gg])   
      AFF[malesUnder40,breast2,gg] <- HazmCBC[AGEBETWEEN[malesUnder40],under40,gg] * (1 - FFm[AGE[malesUnder40,breast2]-1,breast1,gg] + FFm[intage[malesUnder40],breast1,gg])
      AFF[malesOver40,breast2,gg] <-  HazmCBC[AGEBETWEEN[malesOver40],over40,gg] * (1 - FFm[AGE[malesOver40,breast2]-1,breast1,gg] + FFm[intage[malesOver40],breast1,gg])
      
      # AFF[females,breast2,gg] <- 0.5 * Hazf[AGE[females,breast2],breast1,gg] *
      #    (1-FFf[AGE[females,breast2]-1,breast1,gg]+FFf[intage[females],breast1,gg]) / 
      #    ( sqrt(1-FFf[AGE[females,breast1],breast1,gg]+FFf[intage[females],breast1,gg]) *
      #         (1-FFf[AGE[females,breast2],breast1,gg]+FFf[intage[females],breast1,gg]) )
      
      #   AFF[  males,breast2,gg] <- 0.5 * Hazm[AGE[  males,breast2],breast1,gg] *
      #     (1-FFm[AGE[  males,breast2]-1,breast1,gg]+FFm[intage[  males],breast1,gg]) / 
      #      ( sqrt(1-FFm[AGE[  males,breast1],breast1,gg]+FFm[intage[  males],breast1,gg]) *
      #           (1-FFm[AGE[  males,breast2],breast1,gg]+FFm[intage[  males],breast1,gg]) )
      
    }
    
  }
  
  ##
  # Scenario 4: 1 breast cancer, 2nd breast cancer is at age strictly greater than age of
  # first cancer.
  # The contribution here is found the same way as in scenario 3, it's the max given the
  # min, only that the max is greater than maxage.
  # This contribution is sqrt(surv(maxage)/surv(breast1))
  ##
  femalesbc1 <- (1:psize)[family[,"Gender"]==0 & DIS[,breast1]==1]
  malesbc1 <- (1:psize)[family[,"Gender"]==1 & DIS[,breast1]==1]
  femalesnobc1 <- (1:psize)[family[,"Gender"]==0 & DIS[,breast1]==0]
  malesnobc1 <- (1:psize)[family[,"Gender"]==1 & DIS[,breast1]==0]
  
  for ( gg in 1:ngen ) {
    
    # Pre-Intervention Contribution
    UNA[femalesnobc1,breast2,gg] <- rep(1,length(femalesnobc1))
    UNA[  malesnobc1,breast2,gg] <- rep(1,length(malesnobc1))
    
    UNA[femalesbc1,breast2,gg] <- 
      sqrt( 1-FFf[maxage[femalesbc1],breast1,gg] ) /
      sqrt( 1-FFf[AGE[femalesbc1,breast1],breast1,gg] )
    
    UNA[  malesbc1,breast2,gg] <- 
      sqrt( 1-FFm[maxage[  malesbc1],breast1,gg] ) /
      sqrt( 1-FFm[AGE[  malesbc1,breast1],breast1,gg] )
    
    # Post-Intervention Contribution: All survivals are from intervention age
    if ( type=="PostIntervention" ) {
      UNA[femalesbc1,breast2,gg] <-
        sqrt(1 - FFf[maxage[femalesbc1],breast1,gg] + FFf[intage[femalesbc1],breast1,gg]) /
        sqrt(1 - FFf[AGE[femalesbc1,breast1],breast1,gg] + FFf[intage[femalesbc1],breast1,gg]) 
      UNA[  malesbc1,breast2,gg] <-
        sqrt(1 - FFm[maxage[  malesbc1],breast1,gg] + FFm[intage[  malesbc1],breast1,gg]) /
        sqrt(1 - FFm[AGE[  malesbc1,breast1],breast1,gg] + FFm[intage[  malesbc1],breast1,gg]) 
    }
    # if breast2=1 this will multiply a 0, so it;'s ok even if wrong 
  }
  
  # Return output
  output <- list()
  output$DIS <- DIS
  output$AFF <- AFF
  output$UNA <- UNA
  return(output)
}
