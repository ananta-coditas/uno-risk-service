CensorAtIntervention <- function(family,interventions)
{
  ## Purpose: Censor post-intervention outcomes to intervention age
  ## ----------------------------------------------------------------------
  ## Arguments: family, interventions
  ## ----------------------------------------------------------------------
  ## Author: Hormuzd Katki, Date: 20 Mar 2006, 15:19

  ## Updated in v2.0-8 to accommodate Mastectomy intervention

  # Subset out those with intervention, note the age of intervention
  # drop=F means do not squeeze out any singleton indices, i.e. don't coerce row
  # matrices to vectors
  intfamily <- family[interventions,,drop=FALSE]

  # Use the age of the first intervention for censoring.
  oophonly <- !is.null(intfamily$Oophorectomy) & is.null(intfamily$Mastectomy)
  mastonly <- is.null(intfamily$Oophorectomy) & !is.null(intfamily$Mastectomy)
  both <- !is.null(intfamily$Oophorectomy) & !is.null(intfamily$Mastectomy)

  if (oophonly) {
    intage <- intfamily$AgeOophorectomy[intfamily$Oophorectomy==1]
  }

  if (mastonly) {
    intage <- intfamily$AgeMastectomy[intfamily$Mastectomy==1]
  }

  if (both) {
    intage <- rep(NA, nrow(intfamily))
    intage[intfamily$Oophorectomy==0 & intfamily$Mastectomy==1] = intfamily$AgeMastectomy[intfamily$Oophorectomy==0 & intfamily$Mastectomy==1]
    intage[intfamily$Oophorectomy==1 & intfamily$Mastectomy==0] = intfamily$AgeOophorectomy[intfamily$Oophorectomy==1 & intfamily$Mastectomy==0]
    intage[intfamily$Oophorectomy==1 & intfamily$Mastectomy==1] = apply(intfamily[intfamily$Oophorectomy==1 & intfamily$Mastectomy==1,c("AgeOophorectomy", "AgeMastectomy")], 1, min)
}
  
  # Censor each outcome at intage
  # 2nd breast cancer
  censorthese <- intfamily[,"AgeBreastContralateral"]>intage & intfamily[,"AffectedBreast"]==2
  intfamily[censorthese,"AffectedBreast"] <- 1 # 
  intfamily[censorthese,"AgeBreastContralateral"] <- intage[censorthese]
  
  # 2nd breast cancer slot has censoring time: don't change breast cancer indicator
  censorthese <- intfamily[,"AgeBreastContralateral"]>intage & intfamily[,"AffectedBreast"]<2
  intfamily[censorthese,"AgeBreastContralateral"] <- intage[censorthese]
  
  # 1st breast cancer
  censorthese <- intfamily[,"AgeBreast"]>intage & intfamily[,"AffectedBreast"]==1
  intfamily[censorthese,"AffectedBreast"] <- 0
  intfamily[censorthese,"AgeBreast"] <- intage[censorthese]
  
  # 1st breast cancer slot has censoring time: don't change the breast cancer indicator
  censorthese <- intfamily[,"AgeBreast"]>intage & intfamily[,"AffectedBreast"]==0
  intfamily[censorthese,"AgeBreast"] <- intage[censorthese]
  
  # Check to make sure there are no ovarian cancers before oophorectomy
  if ( any(intfamily[,"AgeOvary"]<intage & intfamily[,"AffectedOvary"]==1) )
    print("BRCAPRO only handles oophorectomy occurring before ovarian cancer, not after")
  
  # ovarian cancer
  censorthese <- intfamily[,"AgeOvary"]>intage & intfamily[,"AffectedOvary"]==1
  intfamily[censorthese,"AffectedOvary"] <- 0
  intfamily[censorthese,"AgeOvary"] <- intage[censorthese]
  
  # ovarian cancer slot has censoring time: don't change the breast cancer indicator
  censorthese <- intfamily[,"AgeOvary"]>intage & intfamily[,"AffectedOvary"]==0
  intfamily[censorthese,"AgeOvary"] <- intage[censorthese]

  # Plug into family and return
  family[interventions,] <- intfamily
  return(family)
}
