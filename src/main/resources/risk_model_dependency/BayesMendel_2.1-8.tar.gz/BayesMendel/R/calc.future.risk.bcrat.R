### modified version of calc.future.risk function from BayesMendel package
# rr: vector of relative risks to be used to modify haz.bc (should have the same length as haz.bc)
#--- rr can be a scalar if the relative risk is constant
#<<<<<
calc.future.risk.bcrat = function(haz.bc, haz.death, rr=1)
{
  ll <- length(haz.bc)
  # scale haz.bc by rr based on a discrete-time version of the proportional hazards model
  haz.bc = 1-(1-haz.bc)^rr
  if (length(haz.death) < ll)
    ll <- length(haz.death)
  risk <- rep(0, ll)
  risk[1] <- haz.bc[1]
  surv.all <- (1 - haz.bc[1] - haz.death[1])
  if (ll > 1) {
    for (i in 2:ll) {
      risk[i] <- risk[i - 1] + surv.all * haz.bc[i]
      surv.all <- surv.all * (1 - haz.bc[i] - haz.death[i])
    }
  }
  return(risk)
}