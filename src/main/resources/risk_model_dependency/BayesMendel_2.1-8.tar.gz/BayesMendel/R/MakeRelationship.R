# 2014.02.10 JJC  - Warning occured when multiple spouses in family.
#                   Previous version had if statement requiring spouse ids 
#                   to be %in% other member ids.  (A child could have listed
#                   a father not included in pedigree).
#
#                   This previous fix returned a warning for when multiple
#                   spouses were present.  (A TRUE would return for each spouse
#                   and warning would say only the first TRUE was required to move
#                   on in code).
#
#                   This version does not return the warning when multiple spouses
#                   are present, yet still requires the potential spouses to be in 
#                   the pedigree.


MakeRelationship <- function(ped,counselee.id){
  individ.id <- ped[,"ID"]
  fid <- ped[,"FatherID"]
  mid <- ped[,"MotherID"]
  gender <- ped[,"Gender"]

  relationship <- rep(0,nrow(ped))
  
  current.id <- counselee.id
  indiv <- individ.id==current.id
  relationship[indiv] <- 1
  
  #identify parents,brothers and sisters, nephews and nieces
  sibs <- NULL
  nep <- NULL
  spouse.id <- NULL
  potent.spouse.id <- NULL
  if (sum(indiv)!=0){
    if (fid[indiv]!=0){
      relationship[individ.id==fid[indiv]] <- 4
      sibs <- c(sibs,which(fid==fid[indiv]&!indiv))
    }
    if (mid[indiv]!=0){
      relationship[individ.id==mid[indiv]] <- 4
      sibs <- c(sibs,which(mid==mid[indiv]&!indiv))
    }
    if (length(unique(sibs))!=0){
      relationship[unique(sibs)] <- 2
      for (i in 1:length(unique(sibs))){
        nep <- c(nep,which(fid==individ.id[unique(sibs)[i]]|mid==individ.id[unique(sibs)[i]]))
      }
      if (sum(nep)!=0)
      relationship[unique(nep)] <- 13
    }  
  }
  

  #identify spouse, son or daughter
  if(sum(indiv)!=0){
    if (gender[indiv]==0){
      relationship[mid==individ.id[indiv]] <- 3
      child <- which(mid==individ.id[indiv])
      if (sum(child)!=0){
        spouse.id <- unique(fid[child])
        if (sum(spouse.id)!=0){
          for (i in 1:length(spouse.id)){
             relationship[individ.id==spouse.id[i]] <- 14
           }
        }
      } 
    }else {
      relationship[fid==individ.id[indiv]] <- 3
      child <- which(fid==individ.id[indiv])
      if (sum(child)!=0){
        spouse.id <- unique(mid[child])
        if (sum(spouse.id)!=0){
          for ( i in 1:length(spouse.id)){
            relationship[individ.id==spouse.id[i]] <- 14
          }
        }
      } 
    }
  }
      
  current.fid <- fid[indiv]
  current.mid <- mid[indiv]
  #Paternal side identify grandparents,aunts and uncles
  indiv <- individ.id==current.fid
  if(sum(indiv)!=0){
    if (fid[indiv]!=0){
      relationship[individ.id==fid[indiv]] <- 5
      relationship[fid==fid[indiv]&!indiv] <- 6 
    }
    if (mid[indiv]!=0){
      relationship[individ.id==mid[indiv]] <- 5
      relationship[mid==mid[indiv]&!indiv] <- 6
    }
  }
  #Maternal side identify grandparents, aunts and uncles
  indiv <- individ.id==current.mid
  if(sum(indiv)!=0){
    if (fid[indiv]!=0){
      relationship[individ.id==fid[indiv]] <- 7
      relationship[fid==fid[indiv]&!indiv] <- 8 
    }
    if (mid[indiv]!=0){
      relationship[individ.id==mid[indiv]] <- 7
      relationship[mid==mid[indiv]&!indiv] <- 8
    }
  }

  #Identify spouse, brother or sister in law
  if (sum(spouse.id %in% individ.id)>0){
 	spouse.id <- spouse.id[spouse.id>0]
      for (i in 1:length(spouse.id)){
       indiv <- individ.id==spouse.id[i]
       if (fid[indiv]!=0){
         relationship[fid==fid[indiv]&!indiv] <- 15
       }
       if (mid[indiv]!=0){
         relationship[mid==mid[indiv]&!indiv] <- 15
       }
      }
  }
  #Identify brother or sister's spouse
  if (sum(nep)!=0)
  potent.spouse.id <- unique(c(fid[nep],mid[nep]))
  if (sum(potent.spouse.id)!=0){
    for ( i in 1:length(potent.spouse.id)){
      indiv <- individ.id==potent.spouse.id[i]
      if (sum(indiv)!=0){
        if (relationship[indiv]==0){
          relationship[indiv] <- 15
        }
      }
    }
  }
  
  return(relationship)
}
  
